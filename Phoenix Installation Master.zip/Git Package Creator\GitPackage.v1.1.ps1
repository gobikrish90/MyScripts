﻿# =========================================================================
# INITIALIZATION & SETUP
# =========================================================================
$drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root
$repoSubPath = "OneDrive\OneDrive - ProPhoenix Corporation\Documents\GitHub"
$basePath = $null

Write-Host "--> Detecting repository across local drives..." -ForegroundColor Cyan
foreach ($drive in $drives) {
    $checkPath = Join-Path $drive "$repoSubPath\MyScripts"
    if (Test-Path $checkPath) {
        $basePath = $checkPath
        Write-Host "Repository located on drive: $drive" -ForegroundColor Green
        break
    }
}

if (-not $basePath) {
    Write-Host "Error: Could not locate the MyScripts repository." -ForegroundColor Red
    exit
}

Set-Location $basePath
if (-not (Test-Path ".git")) {
    Write-Host "Error: The folder $basePath is not a Git repository." -ForegroundColor Red
    exit
}

# Core Variables
$mainZipFileName = "Phoenix Installation Master.zip"
$mainZipPath = Join-Path $basePath $mainZipFileName
$tempStaging = Join-Path $env:TEMP "PhoenixStagingArea"

$excludedFolders = @(
    "AutoPrecompiler", "Installation Master", "License Comparision Tool",
    "Manual Fix Update", "New Server Installation Scripts_old",
    "New Server Installation_Refined", "Parameter Backup",
    "Pre-requisite Script", "Useful Scripts"
)

# Pre-calculate GitHub Details for URL Generation
$remoteUrl = git config --get remote.origin.url
$branch = git branch --show-current
$owner = ""
$repo = ""

if ($remoteUrl -match "github\.com[:/]([^/]+)/([^/]+?)(?:\.git)?$") {
    $owner = $matches[1]
    $repo = $matches[2]
} else {
    Write-Host "Warning: Could not parse GitHub URL. URL Injection will fail." -ForegroundColor Red
}

$safeMainZipName = $mainZipFileName -replace ' ', '%20'
$mainDownloadUrl = "https://github.com/$owner/$repo/raw/$branch/$safeMainZipName"


# =========================================================================
# PHASE 1: CREATE MAIN ZIP & FIRST GIT PUSH
# =========================================================================
Write-Host "`n[PHASE 1] Packaging Main Installation Master..." -ForegroundColor Cyan

if (Test-Path $tempStaging) { Remove-Item -Path $tempStaging -Recurse -Force }
New-Item -ItemType Directory -Path $tempStaging | Out-Null

$folders = Get-ChildItem -Path $basePath -Directory | Where-Object { 
    $_.Name -notmatch 'Hub' -and $_.Name -notmatch 'Gateway' -and $excludedFolders -notcontains $_.Name 
}

foreach ($folder in $folders) {
    $targetStagingFolder = Join-Path $tempStaging $folder.Name
    New-Item -ItemType Directory -Path $targetStagingFolder | Out-Null

    if ($folder.Name -eq "Dashboard Scripts") {
        Write-Host "  -> Copying ALL contents: [$($folder.Name)]" -ForegroundColor DarkGray
        $files = Get-ChildItem -Path $folder.FullName -File -Recurse | Where-Object { $_.FullName -notmatch 'Hub' -and $_.FullName -notmatch 'Gateway' }
        foreach ($file in $files) {
            $destPath = $file.FullName.Replace($folder.FullName, $targetStagingFolder)
            $destDir = Split-Path $destPath
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            Copy-Item -Path $file.FullName -Destination $destPath -Force
        }
    }
    else {
        $latestFile = Get-ChildItem -Path $folder.FullName -File | Where-Object { $_.Name -notmatch 'Hub' -and $_.Name -notmatch 'Gateway' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($latestFile) {
            Write-Host "  -> Copying LATEST file:  [$($folder.Name)]" -ForegroundColor DarkGray
            Copy-Item -Path $latestFile.FullName -Destination $targetStagingFolder -Force
        }
    }
}

Write-Host "  -> Compressing $mainZipFileName..." -ForegroundColor Yellow
if (Test-Path $mainZipPath) { Remove-Item $mainZipPath -Force }
Compress-Archive -Path "$tempStaging\*" -DestinationPath $mainZipPath -Force
Remove-Item -Path $tempStaging -Recurse -Force

# Phase 1 Git Commit
Write-Host "`n--> Committing Main Zip to Git..." -ForegroundColor Cyan
git add $mainZipFileName 2>&1 | Out-Null
git commit -m "Phase 1: Generate and update Main $mainZipFileName" 2>&1 | Out-Null
Write-Host "  -> Pushing Main Zip to remote..." -ForegroundColor Yellow
git push 2>&1 | Out-Null

Write-Host "`n=================================================" -ForegroundColor Magenta
Write-Host " PHASE 1 COMPLETE: Main Payload Live" -ForegroundColor Magenta
Write-Host " Live URL: $mainDownloadUrl" -ForegroundColor Cyan
Write-Host "=================================================" -ForegroundColor Magenta


# =========================================================================
# PHASE 2: INJECT URL, COMPILE STANDALONE TOOL & SECOND GIT PUSH
# =========================================================================
Write-Host "`n[PHASE 2] Processing Standalone Installation Master Tool..." -ForegroundColor Cyan

$imFolder = Join-Path $basePath "Installation Master"
$iconPath = Join-Path $imFolder "ProPhoenix_Logo.ico"

$latestIMScript = Get-ChildItem -Path $imFolder -Filter "*.ps1" | 
                  Where-Object { $_.Name -notmatch 'Hub' -and $_.Name -notmatch 'Gateway' } | 
                  Sort-Object LastWriteTime -Descending | Select-Object -First 1

if ($latestIMScript) {
    $imBaseName = $latestIMScript.BaseName
    $exeOutput = Join-Path $imFolder "$imBaseName.exe"
    $batOutput = Join-Path $imFolder "$imBaseName.bat"
    $imZipFileName = "$imBaseName.zip"
    $imZipPath = Join-Path $basePath $imZipFileName

    # --- INJECT THE URL INTO THE SCRIPT ---
    Write-Host "  -> Injecting new Live URL into $($latestIMScript.Name)..." -ForegroundColor Yellow
    $scriptContent = Get-Content -Path $latestIMScript.FullName -Raw
    # Regex finds: $Url_GitHub = "ANY_OLD_URL" and replaces it with the new live URL
    $scriptContent = [regex]::Replace($scriptContent, '(?i)(\$Url_GitHub\s*=\s*["'']).*?(["''])', "`${1}$mainDownloadUrl`${2}")
    Set-Content -Path $latestIMScript.FullName -Value $scriptContent -Force

    # Convert to EXE
    Write-Host "  -> Compiling to EXE..." -ForegroundColor Yellow
    Invoke-PS2EXE -InputFile $latestIMScript.FullName -OutputFile $exeOutput -IconFile $iconPath -RequireAdmin -Title "Installation Master DashBoard" -Description "Installation Master DashBoard" | Out-Null

    # Convert to BAT
    Write-Host "  -> Creating BAT wrapper..." -ForegroundColor Yellow
    $batHeader = "<# :`r`n@echo off`r`npowershell -NoProfile -ExecutionPolicy Bypass -Command `"iex ((Get-Content '%~f0' -Raw))`"`r`nexit /b`r`n#>`r`n"
    $finalBatContent = $batHeader + ($scriptContent -replace "(?<!\r)\n", "`r`n")
    Set-Content -Path $batOutput -Value $finalBatContent -Force

    # Compress Standalone Tool
    Write-Host "  -> Compressing standalone package into $imZipFileName..." -ForegroundColor Yellow
    if (Test-Path $imZipPath) { Remove-Item $imZipPath -Force }
    $filesToZip = @($latestIMScript.FullName, $exeOutput, $batOutput)
    if (Test-Path $iconPath) { $filesToZip += $iconPath }
    Compress-Archive -Path $filesToZip -DestinationPath $imZipPath -Force

    # Phase 2 Git Commit
    Write-Host "`n--> Committing Standalone Tool to Git..." -ForegroundColor Cyan
    git add $latestIMScript.FullName 2>&1 | Out-Null
    git add $imZipFileName 2>&1 | Out-Null
    git commit -m "Phase 2: Inject URL, compile $imBaseName, and generate ZIP" 2>&1 | Out-Null
    Write-Host "  -> Pushing Standalone Tool to remote..." -ForegroundColor Yellow
    git push 2>&1 | Out-Null

    $safeImZipName = $imZipFileName -replace ' ', '%20'
    $imDownloadUrl = "https://github.com/$owner/$repo/raw/$branch/$safeImZipName"

    Write-Host "`n=================================================" -ForegroundColor Magenta
    Write-Host " PHASE 2 COMPLETE: Standalone Tool Live" -ForegroundColor Magenta
    Write-Host " Live URL: $imDownloadUrl" -ForegroundColor Cyan
    Write-Host "=================================================" -ForegroundColor Magenta
}
else {
    Write-Host "  -> Error: Could not find a valid .ps1 file in Installation Master folder." -ForegroundColor Red
}

Write-Host "`nSUCCESS: Entire 2-Stage CI/CD pipeline finished successfully!" -ForegroundColor Green