﻿#Requires -RunAsAdministrator
# ======================================================================
#  ProPhoenix DB Utility Dashboard v10.9 (Ultimate Unified Build)
# ======================================================================

# --- AUTO-ELEVATE TO ADMINISTRATOR ---
$principal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# Load Core Presentation Frameworks
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Data

# --- GLOBAL SETTINGS & PATHING ---
function Get-OptimalDrivePath {
    param([string]$FolderName = "RMS_Master_Backups")
    $drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Free -gt 0 } | Sort-Object Free -Descending
    if (-not $drives) { return "C:\$FolderName" }
    $targetPath = Join-Path $drives[0].Root $FolderName
    if (-not (Test-Path $targetPath)) { New-Item -ItemType Directory -Path $targetPath -Force | Out-Null }
    return $targetPath
}

$Script:SetupPath = "C:\pnxtemp\dbsynctool"
$Script:CurrentDir = if ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { (Get-Location).Path }
$Script:SessionLogDir = Join-Path $Script:SetupPath "SessionLogs"
if (!(Test-Path $Script:SessionLogDir)) { New-Item -ItemType Directory -Force -Path $Script:SessionLogDir | Out-Null }
$Script:SessionLogFile = Join-Path $Script:SessionLogDir "StatusReport_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
$Script:CredFile  = Join-Path $Script:SetupPath "SavedCreds.xml"
$Script:XmlTarget = Join-Path $Script:SetupPath "PnxAutoNewDBSyn.xml"
$Script:DefaultBackup = Get-OptimalDrivePath

$Script:BgImage = Join-Path $Script:CurrentDir "background.png"
if (-not (Test-Path $Script:BgImage)) { $Script:BgImage = Join-Path $Script:CurrentDir "background.jpg" }
if (-not (Test-Path $Script:BgImage)) { $Script:BgImage = Join-Path $Script:SetupPath "background.png" }
if (-not (Test-Path $Script:BgImage)) { $Script:BgImage = Join-Path $Script:SetupPath "background.jpg" }

$Script:TargetParams = @(13, 16, 22, 29, 36, 39, 40, 190, 203, 204, 205, 206, 207, 220, 221, 222, 231, 630, 1914, 2658)
$Script:TargetJobs = @("WDAAppDataExporter", "ReportWriterStaticDataExporter", "CADStaticDataExtractor", "Hot Sheet", "FireLiveDataExporter", "PhoenixBOTQAUploader", "KPICleaner", "FireRMSDataExporter")
$Script:TargetMap = @{}

# ======================================================================
#  WPF XAML DEFINITION 
# ======================================================================
$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="ProPhoenix DB Dashboard" Height="1000" Width="1400" 
        WindowStartupLocation="CenterScreen" Background="Transparent" WindowStyle="None" AllowsTransparency="True" 
        FontFamily="Segoe UI" TextOptions.TextFormattingMode="Display" TextOptions.TextRenderingMode="ClearType">
    
    <Window.Resources>
        <SolidColorBrush x:Key="BgDark" Color="#121214"/>
        <SolidColorBrush x:Key="BgPanel" Color="#1C1C1F"/>
        <SolidColorBrush x:Key="BgInput" Color="#2A2A2E"/>
        <SolidColorBrush x:Key="TextPrimary" Color="#FFFFFF"/> 
        <SolidColorBrush x:Key="TextMuted" Color="#B0B0B8"/>
        
        <SolidColorBrush x:Key="BtnPrimary" Color="#00629A"/>   
        <SolidColorBrush x:Key="BtnSuccess" Color="#1E7145"/>   
        <SolidColorBrush x:Key="BtnWarning" Color="#B85D19"/>   
        <SolidColorBrush x:Key="BtnDanger" Color="#A4262C"/>    
        <SolidColorBrush x:Key="BtnSecondary" Color="#3E3E42"/> 
        <SolidColorBrush x:Key="BtnPurple" Color="#5C2D91"/>    

        <Storyboard x:Key="OpenDrawer">
            <DoubleAnimation Storyboard.TargetName="SideDrawer" Storyboard.TargetProperty="(UIElement.RenderTransform).(TranslateTransform.X)" To="0" Duration="0:0:0.35">
                <DoubleAnimation.EasingFunction><CubicEase EasingMode="EaseOut"/></DoubleAnimation.EasingFunction>
            </DoubleAnimation>
            <ObjectAnimationUsingKeyFrames Storyboard.TargetName="DrawerOverlay" Storyboard.TargetProperty="Visibility">
                <DiscreteObjectKeyFrame KeyTime="0:0:0" Value="{x:Static Visibility.Visible}"/>
            </ObjectAnimationUsingKeyFrames>
            <DoubleAnimation Storyboard.TargetName="DrawerOverlay" Storyboard.TargetProperty="Opacity" To="0.6" Duration="0:0:0.35"/>
        </Storyboard>
        
        <Storyboard x:Key="CloseDrawer">
            <DoubleAnimation Storyboard.TargetName="SideDrawer" Storyboard.TargetProperty="(UIElement.RenderTransform).(TranslateTransform.X)" To="420" Duration="0:0:0.3">
                <DoubleAnimation.EasingFunction><CubicEase EasingMode="EaseIn"/></DoubleAnimation.EasingFunction>
            </DoubleAnimation>
            <DoubleAnimation Storyboard.TargetName="DrawerOverlay" Storyboard.TargetProperty="Opacity" To="0" Duration="0:0:0.3"/>
            <ObjectAnimationUsingKeyFrames Storyboard.TargetName="DrawerOverlay" Storyboard.TargetProperty="Visibility">
                <DiscreteObjectKeyFrame KeyTime="0:0:0.3" Value="{x:Static Visibility.Collapsed}"/>
            </ObjectAnimationUsingKeyFrames>
        </Storyboard>

        <Style TargetType="Button" x:Key="ModernBtn">
            <Setter Property="Foreground" Value="#FFFFFF"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="border" Background="{TemplateBinding Background}" CornerRadius="4">
                            <Grid>
                                <ContentPresenter x:Name="content" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                                <Path x:Name="spinner" Width="18" Height="18" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5" Data="M9,0 a9,9 0 1,1 -8.99,9" Stroke="White" StrokeThickness="2" StrokeDashArray="14,14">
                                    <Path.RenderTransform><RotateTransform x:Name="SpinnerRotation"/></Path.RenderTransform>
                                    <Path.Triggers>
                                        <EventTrigger RoutedEvent="FrameworkElement.Loaded">
                                            <BeginStoryboard><Storyboard><DoubleAnimation Storyboard.TargetName="SpinnerRotation" Storyboard.TargetProperty="Angle" From="0" To="360" Duration="0:0:1" RepeatBehavior="Forever"/></Storyboard></BeginStoryboard>
                                        </EventTrigger>
                                    </Path.Triggers>
                                </Path>
                            </Grid>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="border" Property="Opacity" Value="0.85"/></Trigger>
                            <Trigger Property="IsPressed" Value="True"><Setter TargetName="border" Property="Opacity" Value="0.6"/></Trigger>
                            <Trigger Property="Tag" Value="Loading">
                                <Setter TargetName="content" Property="Visibility" Value="Collapsed"/>
                                <Setter TargetName="spinner" Property="Visibility" Value="Visible"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style TargetType="TextBox" x:Key="ModernInput">
            <Setter Property="Background" Value="{StaticResource BgInput}"/>
            <Setter Property="Foreground" Value="{StaticResource TextPrimary}"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Padding" Value="10,0,10,0"/>
            <Setter Property="VerticalContentAlignment" Value="Center"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="TextBox">
                        <Border Background="{TemplateBinding Background}" CornerRadius="4">
                            <Grid>
                                <TextBlock x:Name="watermark" Text="{TemplateBinding Tag}" Foreground="#777777" VerticalAlignment="Center" Margin="10,0,0,0" Visibility="Hidden" IsHitTestVisible="False"/>
                                <ScrollViewer x:Name="PART_ContentHost" VerticalAlignment="Center"/>
                            </Grid>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="Text" Value=""><Setter TargetName="watermark" Property="Visibility" Value="Visible"/></Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style TargetType="CheckBox" x:Key="ModernCheck">
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="CheckBox">
                        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
                            <Border x:Name="box" Width="18" Height="18" Background="{StaticResource BgInput}" BorderBrush="#555" BorderThickness="1" CornerRadius="3" Margin="0,0,10,0">
                                <Path x:Name="check" Data="M3,9 L7,13 L14,4" Stroke="#00FF7F" StrokeThickness="2" Stretch="None" HorizontalAlignment="Center" VerticalAlignment="Center" Visibility="Collapsed"/>
                            </Border>
                            <ContentPresenter VerticalAlignment="Center"/>
                        </StackPanel>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsChecked" Value="True">
                                <Setter TargetName="check" Property="Visibility" Value="Visible"/>
                                <Setter TargetName="box" Property="BorderBrush" Value="#00FF7F"/>
                            </Trigger>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="box" Property="BorderBrush" Value="#00B4D8"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style TargetType="ToggleButton" x:Key="ModernToggle">
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="ToggleButton">
                        <Border x:Name="border" Background="{StaticResource BtnSecondary}" CornerRadius="4">
                            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" VerticalAlignment="Center">
                                <Ellipse x:Name="dot" Width="8" Height="8" Fill="#777777" Margin="0,0,8,0"/>
                                <ContentPresenter/>
                            </StackPanel>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsChecked" Value="True">
                                <Setter TargetName="border" Property="Background" Value="{StaticResource BtnPrimary}"/>
                                <Setter TargetName="dot" Property="Fill" Value="#00FF7F"/>
                                <Setter TargetName="dot" Property="Effect"><Setter.Value><DropShadowEffect Color="#00FF7F" BlurRadius="8" ShadowDepth="0"/></Setter.Value></Setter>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <ControlTemplate x:Key="SolidComboToggle" TargetType="ToggleButton">
            <Border Background="{StaticResource BgInput}" CornerRadius="4">
                <TextBlock Text="▼" Foreground="{StaticResource TextMuted}" HorizontalAlignment="Right" VerticalAlignment="Center" Margin="0,0,10,0" FontSize="10"/>
            </Border>
        </ControlTemplate>
        
        <Style TargetType="ComboBox" x:Key="SolidCombo">
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="ComboBox">
                        <Grid>
                            <ToggleButton Template="{StaticResource SolidComboToggle}" IsChecked="{Binding IsDropDownOpen, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}"/>
                            <TextBlock x:Name="watermark" Text="{TemplateBinding Tag}" Foreground="#777777" Margin="10,0,25,0" VerticalAlignment="Center" IsHitTestVisible="False" Visibility="Collapsed"/>
                            <ContentPresenter Margin="10,0,25,0" VerticalAlignment="Center" IsHitTestVisible="False" Content="{TemplateBinding SelectionBoxItem}" ContentTemplate="{TemplateBinding SelectionBoxItemTemplate}"/>
                            <Popup IsOpen="{TemplateBinding IsDropDownOpen}" Placement="Bottom" AllowsTransparency="True">
                                <Border Background="{StaticResource BgPanel}" BorderThickness="1" BorderBrush="#333" CornerRadius="4" MinWidth="{Binding ActualWidth, RelativeSource={RelativeSource TemplatedParent}}">
                                    <ScrollViewer Margin="0,5"><ItemsPresenter/></ScrollViewer>
                                </Border>
                            </Popup>
                        </Grid>
                        <ControlTemplate.Triggers>
                            <Trigger Property="SelectedIndex" Value="-1"><Setter TargetName="watermark" Property="Visibility" Value="Visible"/></Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style TargetType="ComboBoxItem">
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="Padding" Value="10,8"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="ComboBoxItem">
                        <Border x:Name="Bd" Background="Transparent" Padding="{TemplateBinding Padding}"><ContentPresenter/></Border>
                        <ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Background" Value="{StaticResource BtnPrimary}"/></Trigger></ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Grid ClipToBounds="True">
        <Border x:Name="MainBorder" Background="{StaticResource BgDark}" CornerRadius="8" BorderBrush="#333" BorderThickness="1" Margin="25">
            <Border.Effect><DropShadowEffect Color="Black" BlurRadius="25" Opacity="0.5" Direction="270" ShadowDepth="5"/></Border.Effect>
            <Grid>
                <Grid.RowDefinitions>
                    <RowDefinition Height="40"/>
                    <RowDefinition Height="90"/>
                    <RowDefinition Height="70"/>
                    <RowDefinition Height="130"/>
                    <RowDefinition Height="*"/> 
                    <RowDefinition Height="30"/>
                </Grid.RowDefinitions>

                <Grid x:Name="TitleBar" Grid.Row="0" Background="Transparent">
                    <TextBlock Text="ProPhoenix Utility Dashboard" Foreground="{StaticResource TextMuted}" VerticalAlignment="Center" Margin="20,0,0,0" FontSize="13"/>
                    <Button x:Name="btnClose" Content="✕" Width="40" Background="Transparent" Foreground="{StaticResource TextMuted}" HorizontalAlignment="Right" BorderThickness="0" FontSize="16" Cursor="Hand">
                        <Button.Style><Style TargetType="Button"><Style.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="White"/><Setter Property="Background" Value="#C42B1C"/></Trigger></Style.Triggers></Style></Button.Style>
                    </Button>
                </Grid>

                <Grid Grid.Row="1" Margin="20,0,20,0">
                    <TextBlock Text="DB Synchronization Center" FontSize="30" Foreground="{StaticResource TextPrimary}" FontWeight="Light" VerticalAlignment="Center"/>
                    <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center">
                        <TextBlock Text="Utility Path:" Foreground="{StaticResource TextMuted}" VerticalAlignment="Center" Margin="0,0,10,0"/>
                        <TextBox x:Name="txtPath" Width="300" Style="{StaticResource ModernInput}" Height="34" Margin="0,0,10,0" Tag="Path to DB Sync Folder..."/>
                        <Button x:Name="btnBrowse" Content="Browse" Width="80" Height="34" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}"/>
                        <StackPanel Margin="20,0,0,0" VerticalAlignment="Center">
                            <TextBlock x:Name="lblVer" Text="DB Ver: --" Foreground="{StaticResource TextMuted}" TextAlignment="Right"/>
                            <TextBlock x:Name="lblCBVer" Text="CB Ver: --" Foreground="{StaticResource TextMuted}" TextAlignment="Right" Margin="0,5,0,0"/>
                        </StackPanel>
                    </StackPanel>
                </Grid>

                <Grid Grid.Row="2" Margin="20,10,20,0">
                    <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                    <StackPanel Grid.Column="0" Orientation="Horizontal">
                        <Button x:Name="btnCreateDB" Content="Create New DB" Width="150" Height="40" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,10,0"/>
                        <Button x:Name="btnInstall" Content="Install Utility" Width="150" Height="40" Background="{StaticResource BtnSuccess}" Style="{StaticResource ModernBtn}" Margin="0,0,10,0"/>
                        <Button x:Name="btnUninstall" Content="Uninstall Utility" Width="150" Height="40" Background="{StaticResource BtnDanger}" Style="{StaticResource ModernBtn}" Margin="0,0,10,0"/>
                        <Button x:Name="btnSqlMem" Content="SQL Memory Mgmt" Width="160" Height="40" Background="{StaticResource BtnPurple}" Style="{StaticResource ModernBtn}"/>
                    </StackPanel>
                    <Button x:Name="btnOtherActivities" Grid.Column="1" Content="Other Activities ≡" Width="160" Height="40" Background="{StaticResource BtnSecondary}" Style="{StaticResource ModernBtn}" HorizontalAlignment="Right"/>
                </Grid>

                <Border Grid.Row="3" Background="#AA1C1C1F" CornerRadius="6" Margin="20,10,20,10" Padding="15">
                    <StackPanel>
                        <TextBlock Text="SQL CONNECTION CONFIGURATION" Foreground="#00B4D8" FontSize="12" FontWeight="Bold" Margin="0,0,0,10"/>
                        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
                            <TextBox x:Name="txtS" Width="180" Height="34" Style="{StaticResource ModernInput}" Margin="0,0,10,0" Tag="Server IP / Hostname"/>
                            <TextBox x:Name="txtU" Width="100" Height="34" Style="{StaticResource ModernInput}" Text="sa" Margin="0,0,10,0" Tag="Username"/>
                            
                            <Grid Width="170" Height="34" Margin="0,0,10,0">
                                <PasswordBox x:Name="txtP" Background="{StaticResource BgInput}" Foreground="{StaticResource TextPrimary}" FontSize="14" BorderThickness="0" Padding="10,0,10,0" VerticalContentAlignment="Center"/>
                                <TextBlock x:Name="lblPwdPlaceholder" Text="Password" Foreground="#777777" VerticalAlignment="Center" Margin="10,0,0,0" IsHitTestVisible="False"/>
                            </Grid>

                            <ComboBox x:Name="cmbEnv" Width="90" Height="34" Margin="0,0,10,0" SelectedIndex="-1" Style="{StaticResource SolidCombo}" Tag="ENV">
                                <ComboBoxItem Content="LIVE"/><ComboBoxItem Content="TEST"/><ComboBoxItem Content="ALL"/>
                            </ComboBox>

                            <ComboBox x:Name="cmbSyncType" Width="190" Height="34" Margin="0,0,15,0" SelectedIndex="1" Style="{StaticResource SolidCombo}" Tag="Sync Mode...">
                                <ComboBoxItem Content="1 - Make a database"/><ComboBoxItem Content="2 - Update/Upgrade"/><ComboBoxItem Content="3 - Batch Update"/>
                            </ComboBox>

                            <Rectangle Width="2" Fill="#444444" Margin="0,6,15,6" RadiusX="1" RadiusY="1"/>
                            <ToggleButton x:Name="chkAutoSync" Content="Auto Sync" Width="90" Height="34" Style="{StaticResource ModernToggle}" Margin="0,0,15,0" IsChecked="True"/>
                            
                            <Button x:Name="btnCon" Content="CONNECT" Width="130" Height="34" Background="{StaticResource BtnDanger}" Style="{StaticResource ModernBtn}"/>
                        </StackPanel>
                    </StackPanel>
                </Border>

                <Grid Grid.Row="4" Margin="20,0,20,10">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="3.5*"/>
                        <ColumnDefinition Width="1"/> 
                        <ColumnDefinition Width="6.5*"/>
                    </Grid.ColumnDefinitions>

                    <Border Grid.Column="0" Background="#AA1C1C1F" CornerRadius="6" Margin="0,0,10,0" Padding="15">
                        <Grid>
                            <Grid.RowDefinitions>
                                <RowDefinition Height="Auto"/>
                                <RowDefinition Height="Auto"/>
                                <RowDefinition Height="*"/>
                            </Grid.RowDefinitions>
                            
                            <Grid Grid.Row="0" Margin="0,0,0,15">
                                <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                                <TextBlock Grid.Column="0" Text="DETECTED TARGETS" Foreground="#00B4D8" FontSize="12" FontWeight="Bold" VerticalAlignment="Center"/>
                                <Button x:Name="btnRefresh" Grid.Column="1" Content="↻ Refresh" Width="80" Height="28" Background="{StaticResource BtnSecondary}" Style="{StaticResource ModernBtn}" Margin="0,0,8,0"/>
                                <ToggleButton x:Name="chkAll" Grid.Column="2" Content="Select All" Width="90" Height="28" Style="{StaticResource ModernToggle}"/>
                            </Grid>

                            <Grid Grid.Row="1" Margin="0,5,0,10" Background="#2A2A2E">
                                <Grid.ColumnDefinitions>
                                    <ColumnDefinition Width="45"/>
                                    <ColumnDefinition Width="100"/>
                                    <ColumnDefinition Width="*"/>
                                </Grid.ColumnDefinitions>
                                <TextBlock Grid.Column="1" Text="TYPE" Foreground="#D0D0D0" FontWeight="Bold" FontSize="12" VerticalAlignment="Center" Margin="0,4"/>
                                <TextBlock Grid.Column="2" Text="DATABASE NAME" Foreground="#D0D0D0" FontWeight="Bold" FontSize="12" VerticalAlignment="Center" Margin="0,4"/>
                            </Grid>

                            <ListBox x:Name="listDBs" Grid.Row="2" Background="Transparent" Foreground="{StaticResource TextPrimary}" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled">
                                <ListBox.ItemTemplate>
                                    <DataTemplate>
                                        <Grid Height="28" Margin="0,2">
                                            <Grid.ColumnDefinitions>
                                                <ColumnDefinition Width="45"/>
                                                <ColumnDefinition Width="100"/>
                                                <ColumnDefinition Width="*"/>
                                            </Grid.ColumnDefinitions>
                                            <CheckBox Grid.Column="0" IsChecked="{Binding IsChecked, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}" VerticalAlignment="Center" HorizontalAlignment="Center" Style="{StaticResource ModernCheck}"/>
                                            <TextBlock Grid.Column="1" Text="{Binding Type}" VerticalAlignment="Center" Foreground="#00B4D8" FontSize="13"/>
                                            <TextBlock Grid.Column="2" Text="{Binding DBName}" VerticalAlignment="Center" Foreground="White" FontSize="13"/>
                                        </Grid>
                                    </DataTemplate>
                                </ListBox.ItemTemplate>
                            </ListBox>
                        </Grid>
                    </Border>

                    <Rectangle Grid.Column="1" Fill="#444444" Margin="0,15,0,15" RadiusX="1" RadiusY="1"/>

                    <Border Grid.Column="2" Background="#AA1C1C1F" CornerRadius="6" Margin="10,0,0,0" Padding="15">
                        <Grid>
                            <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
                            <Grid Grid.Row="0" Margin="0,0,0,15">
                                <TextBlock Text="ACTIVITY LOG" Foreground="#00FF7F" FontSize="12" FontWeight="Bold" VerticalAlignment="Center"/>
                                <Button x:Name="btnClear" Content="Clear Log" HorizontalAlignment="Right" Width="90" Height="28" Background="{StaticResource BtnSecondary}" Style="{StaticResource ModernBtn}"/>
                            </Grid>
                            <RichTextBox x:Name="txtLog" Grid.Row="1" Background="#AA0C0C0E" Foreground="#E0E0E0" FontFamily="Consolas" FontSize="14" BorderThickness="0" IsReadOnly="True" VerticalScrollBarVisibility="Auto">
                                <FlowDocument x:Name="logDoc" PagePadding="10"/>
                            </RichTextBox>
                        </Grid>
                    </Border>
                </Grid>

                <Border Grid.Row="5" Background="#AA1C1C1F" CornerRadius="0,0,8,8">
                    <TextBlock x:Name="lblStat" Text="Ready." Foreground="{StaticResource TextMuted}" VerticalAlignment="Center" Margin="20,0,0,0" FontSize="12"/>
                </Border>
            </Grid>
        </Border>

        <Border x:Name="DrawerOverlay" Background="Black" Opacity="0" Visibility="Collapsed" Panel.ZIndex="10"/>

        <Border x:Name="SideDrawer" Width="350" HorizontalAlignment="Right" Background="{StaticResource BgPanel}" BorderThickness="0" Panel.ZIndex="20" Margin="25" CornerRadius="0,8,8,0">
            <Border.Effect><DropShadowEffect Color="Black" BlurRadius="25" Opacity="0.8" Direction="180" ShadowDepth="10"/></Border.Effect>
            <Border.RenderTransform><TranslateTransform X="420"/></Border.RenderTransform>
            <Grid>
                <Grid.RowDefinitions><RowDefinition Height="60"/><RowDefinition Height="*"/></Grid.RowDefinitions>
                <TextBlock Text="OTHER ACTIVITIES" Foreground="#00B4D8" FontSize="16" FontWeight="Bold" VerticalAlignment="Center" Margin="25,0,0,0"/>
                <Button x:Name="btnCloseDrawer" Content="✕" Width="40" Height="40" Background="Transparent" Foreground="{StaticResource TextMuted}" HorizontalAlignment="Right" BorderThickness="0" FontSize="18" Cursor="Hand" Margin="0,0,10,0">
                    <Button.Style><Style TargetType="Button"><Style.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="White"/><Setter Property="Background" Value="#C42B1C"/></Trigger></Style.Triggers></Style></Button.Style>
                </Button>
                
                <ScrollViewer Grid.Row="1" Margin="20,10,20,20" VerticalScrollBarVisibility="Auto">
                    <StackPanel>
                        <Button x:Name="btnSync" Content="START DB SYNC" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                        <Button x:Name="btnCopyDB" Content="LIVE TO TRAIN/TEST" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                        <Button x:Name="btnVer" Content="CHECK VERSION" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,30"/>
                        
                        <Button x:Name="btnBackup" Content="BACKUP JOBS &amp; PARAMS" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                        <Button x:Name="btnRestore" Content="RESTORE JOBS &amp; PARAMS" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                        <Button x:Name="btnDeleteDB" Content="DELETE DATABASE" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,30"/>
                        
                        <Button x:Name="btnCodebook" Content="SYNC CODEBOOK (FIRE)" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                        <Button x:Name="btnOverrideCat" Content="OVERRIDE DB CATEGORY" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                        <Button x:Name="btnBackupDB" Content="BACKUP DB (SQL)" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                        <Button x:Name="btnRestoreDB" Content="RESTORE DB (SQL)" Height="45" Background="{StaticResource BtnPrimary}" Style="{StaticResource ModernBtn}" Margin="0,0,0,12"/>
                    </StackPanel>
                </ScrollViewer>
            </Grid>
        </Border>
    </Grid>
</Window>
"@

# Instantiate & Parse Document Model
$reader = (New-Object System.Xml.XmlNodeReader ([xml]$xaml))
$Script:form = [Windows.Markup.XamlReader]::Load($reader)

# Map Elements to Automation Global Context Variables
$Script:MainBorder = $Script:form.FindName("MainBorder")
$Script:txtPath = $Script:form.FindName("txtPath")
$Script:btnBrowse = $Script:form.FindName("btnBrowse")
$Script:lblVer = $Script:form.FindName("lblVer")
$Script:lblCBVer = $Script:form.FindName("lblCBVer")
$Script:btnCreateDB = $Script:form.FindName("btnCreateDB")
$Script:btnInstall = $Script:form.FindName("btnInstall")
$Script:btnUninstall = $Script:form.FindName("btnUninstall")
$Script:btnSqlMem = $Script:form.FindName("btnSqlMem")
$Script:txtS = $Script:form.FindName("txtS")
$Script:txtU = $Script:form.FindName("txtU")
$Script:txtP = $Script:form.FindName("txtP")
$Script:cmbEnv = $Script:form.FindName("cmbEnv")
$Script:cmbSyncType = $Script:form.FindName("cmbSyncType")
$Script:chkAutoSync = $Script:form.FindName("chkAutoSync")
$Script:btnCon = $Script:form.FindName("btnCon")
$Script:lblPwdPlaceholder = $Script:form.FindName("lblPwdPlaceholder")
$Script:listDBs = $Script:form.FindName("listDBs")
$Script:chkAll = $Script:form.FindName("chkAll")
$Script:btnRefresh = $Script:form.FindName("btnRefresh")
$Script:txtLog = $Script:form.FindName("txtLog")
$Script:logDoc = $Script:form.FindName("logDoc")
$Script:btnClear = $Script:form.FindName("btnClear")
$Script:btnOtherActivities = $Script:form.FindName("btnOtherActivities")
$Script:btnCloseDrawer = $Script:form.FindName("btnCloseDrawer")
$Script:DrawerOverlay = $Script:form.FindName("DrawerOverlay")
$Script:btnSync = $Script:form.FindName("btnSync")
$Script:btnCopyDB = $Script:form.FindName("btnCopyDB")
$Script:btnBackup = $Script:form.FindName("btnBackup")
$Script:btnRestore = $Script:form.FindName("btnRestore")
$Script:btnCodebook = $Script:form.FindName("btnCodebook")
$Script:btnOverrideCat = $Script:form.FindName("btnOverrideCat")
$Script:btnBackupDB = $Script:form.FindName("btnBackupDB")
$Script:btnDeleteDB = $Script:form.FindName("btnDeleteDB")
$Script:btnVer = $Script:form.FindName("btnVer")
$Script:btnRestoreDB = $Script:form.FindName("btnRestoreDB")
$Script:lblStat = $Script:form.FindName("lblStat")
$TitleBar = $Script:form.FindName("TitleBar")
$btnClose = $Script:form.FindName("btnClose")

$Script:txtS.Text = $env:COMPUTERNAME

# Inject Background Image smoothly if exists
try {
    if (Test-Path $Script:BgImage) {
        $uri = New-Object System.Uri($Script:BgImage, [System.UriKind]::Absolute)
        $imgSrc = New-Object System.Windows.Media.Imaging.BitmapImage($uri)
        $imgBrush = New-Object System.Windows.Media.ImageBrush($imgSrc)
        $imgBrush.Stretch = [System.Windows.Media.Stretch]::UniformToFill
        $Script:MainBorder.Background = $imgBrush
    }
} catch {}

# ======================================================================
#  WPF CORE INTERFACE EVENT BINDINGS
# ======================================================================
$TitleBar.Add_MouseLeftButtonDown({ $Script:form.DragMove() })
$btnClose.Add_Click({ $Script:form.Close() })
$Script:form.Add_KeyDown({ param($s, $e) if ($e.Key -eq 'Enter') { $Script:form.Close() } })

$Script:txtP.Add_PasswordChanged({
    if ($Script:txtP.Password.Length -gt 0) { $Script:form.FindName("lblPwdPlaceholder").Visibility = "Hidden" } 
    else { $Script:form.FindName("lblPwdPlaceholder").Visibility = "Visible" }
})

$Script:btnOtherActivities.Add_Click({ $Script:form.FindResource("OpenDrawer").Begin() })
$Script:btnCloseDrawer.Add_Click({ $Script:form.FindResource("CloseDrawer").Begin() })
$Script:DrawerOverlay.Add_MouseLeftButtonDown({ $Script:form.FindResource("CloseDrawer").Begin() })

$Script:chkAll.Add_Click({
    $state = $Script:chkAll.IsChecked
    foreach ($item in $Script:listDBs.Items) { $item.IsChecked = $state }
    $Script:listDBs.Items.Refresh()
})

$Script:btnClear.Add_Click({ $Script:logDoc.Blocks.Clear() })

# ======================================================================
#  UNIFIED BACKEND ENGINE & CORE INTERFACE GRAFTS
# ======================================================================

function Show-CustomAlert($Title, $Message) {
    $alertXaml = @"
    <Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="$Title" Height="180" Width="400" WindowStartupLocation="CenterScreen" Background="#1C1C1F" WindowStyle="None" BorderBrush="#444" BorderThickness="1" FontFamily="Segoe UI" Topmost="True">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="60"/>
            </Grid.RowDefinitions>
            <TextBlock Text="$Title" Foreground="#00B4D8" FontSize="15" FontWeight="Bold" Margin="20,20,20,5"/>
            <TextBlock Grid.Row="1" Text="$Message" Foreground="#E0E0E0" FontSize="14" Margin="20,5,20,15" TextWrapping="Wrap"/>
            <Border Grid.Row="2" Background="#2A2A2E">
                <Button Name="btnOk" Content="OK" Background="#00629A" Foreground="White" FontWeight="Bold" Width="100" Height="34" Margin="0,0,20,0" HorizontalAlignment="Right" Cursor="Hand" BorderThickness="0">
                    <Button.Template><ControlTemplate TargetType="Button"><Border Background="{TemplateBinding Background}" CornerRadius="4"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border></ControlTemplate></Button.Template>
                </Button>
            </Border>
        </Grid>
    </Window>
"@
    $win = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader ([xml]$alertXaml)))
    $btnOk = $win.FindName("btnOk")
    $btnOk.Add_Click({ $win.DialogResult = $true })
    [void]$win.ShowDialog()
}

function Show-DBSelectBox($Title) {
    $dbList = @()
    foreach ($item in $Script:listDBs.Items) { $dbList += $item.Key }
    if ($dbList.Count -eq 0) { Show-CustomAlert "No Databases" "Please connect to SQL and detect targets first."; return $null }

    $xaml = @"
    <Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="$Title" Height="210" Width="400" WindowStartupLocation="CenterScreen" Background="#1C1C1F" WindowStyle="ToolWindow" FontFamily="Segoe UI">
        <StackPanel Margin="20">
            <TextBlock Text="Select a Target Database:" Foreground="#00B4D8" FontSize="14" FontWeight="Bold" Margin="0,0,0,10"/>
            <ComboBox Name="cmbSelect" Background="#2A2A2E" Foreground="Black" FontSize="14" Padding="5" Height="30" Margin="0,0,0,15"/>
            <Button Name="btnOk" Content="PROCEED" Background="#00629A" Foreground="White" FontWeight="Bold" Height="36" Cursor="Hand" BorderThickness="0">
                <Button.Template><ControlTemplate TargetType="Button"><Border Background="{TemplateBinding Background}" CornerRadius="4"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border></ControlTemplate></Button.Template>
            </Button>
        </StackPanel>
    </Window>
"@
    $win = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader ([xml]$xaml)))
    $cmb = $win.FindName("cmbSelect")
    foreach ($db in $dbList) { [void]$cmb.Items.Add($db) }
    $cmb.SelectedIndex = 0
    $btnOk = $win.FindName("btnOk")
    $res = $null
    $btnOk.Add_Click({ $script:res = $cmb.SelectedItem; $win.DialogResult = $true })
    if ($win.ShowDialog()) { return $script:res }
    return $null
}

# --- GLOBAL SQL CONNECTION STRING BUILDER ---
function Get-SqlCS {
    param($DBName="master", $Timeout=15)
    $b = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
    $b.DataSource = $Script:txtS.Text
    $b.UserID = $Script:txtU.Text
    $b.Password = $Script:txtP.Password
    $b.InitialCatalog = $DBName
    $b.ConnectTimeout = $Timeout
    return $b.ConnectionString
}

function Set-Loading($btn, $isLoading) {
    if ($isLoading) { $btn.Tag = "Loading" } else { $btn.Tag = $null }
}

# --- GLOBAL ASYNC ENGINE ---
$Script:AsyncTimer = New-Object System.Windows.Threading.DispatcherTimer
$Script:AsyncTimer.Interval = [TimeSpan]::FromMilliseconds(50)
$Script:AsyncTimer.Add_Tick({
    $Script:AsyncTimer.Stop()
    try { 
        if ($Script:ActiveAction) { & $Script:ActiveAction } 
    } 
    catch { Log "❌ Error: $($_.Exception.Message)" "Red" } 
    finally { 
        if ($Script:ActiveBtn) { Set-Loading $Script:ActiveBtn $false }
        Toggle $true
        $Script:form.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render) 
    }
})

function Run-Async {
    param($Btn, [scriptblock]$Action)
    $Script:ActiveBtn = $Btn
    $Script:ActiveAction = $Action
    Set-Loading $Btn $true
    Toggle $false
    $Script:form.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
    $Script:AsyncTimer.Start()
}

function Get-SelectedKeys {
    $keys = @()
    foreach ($item in $Script:listDBs.Items) { if ($item.IsChecked) { $keys += $item.Key } }
    return $keys
}

function Add-DBToList($dbName, $dbKey, $type) {
    $item = [PSCustomObject]@{ Key = $dbKey; DBName = $dbName; Type = $type; IsChecked = $Script:chkAutoSync.IsChecked }
    [void]$Script:listDBs.Items.Add($item)
}

function Toggle($s) { 
    $Script:btnCon.IsEnabled=$s; $Script:btnSync.IsEnabled=$s; $Script:btnBackup.IsEnabled=$s; 
    $Script:btnRestore.IsEnabled=$s; $Script:btnVer.IsEnabled=$s; $Script:btnCreateDB.IsEnabled=$s; 
    $Script:btnCopyDB.IsEnabled=$s; $Script:btnDeleteDB.IsEnabled=$s; $Script:btnSqlMem.IsEnabled=$s;
    $Script:btnInstall.IsEnabled=$s; $Script:btnUninstall.IsEnabled=$s; $Script:btnCodebook.IsEnabled=$s;
    $Script:btnBackupDB.IsEnabled=$s; $Script:btnRestoreDB.IsEnabled=$s; $Script:btnOverrideCat.IsEnabled=$s;
}

function Log($msg, $color="White") {
    $mappedColor = switch ($color) {
        "Lime" { "#4CAF50" }      
        "Cyan" { "#00B4D8" }      
        "Red" { "#D13438" }       
        "Yellow" { "#D7BA7D" }    
        "Orange" { "#CE9178" }    
        "Gray" { "#808080" }
        "DarkGray" { "#555555" }
        Default { "#FFFFFF" }
    }
    
    $Script:form.Dispatcher.Invoke([Action]{
        $para = New-Object System.Windows.Documents.Paragraph
        $para.Margin = New-Object System.Windows.Thickness(0,0,0,2)
        $runTS = New-Object System.Windows.Documents.Run("[$(Get-Date -Format 'HH:mm:ss')] ")
        $runTS.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.ColorConverter]::ConvertFromString("#777777")))
        $runMsg = New-Object System.Windows.Documents.Run($msg)
        $runMsg.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.ColorConverter]::ConvertFromString($mappedColor)))
        $para.Inlines.Add($runTS); $para.Inlines.Add($runMsg)
        $Script:logDoc.Blocks.Add($para); $Script:txtLog.ScrollToEnd()
    })
    try { Add-Content -Path $Script:SessionLogFile -Value "[$(Get-Date -Format 'HH:mm:ss')] $msg" } catch {}
}

function Save-Creds {
    try {
        $pw = $Script:txtP.Password | ConvertTo-SecureString -AsPlainText -Force
        [PSCustomObject]@{ Server=$Script:txtS.Text; User=$Script:txtU.Text; Password=$pw } | Export-Clixml -Path $Script:CredFile -Force
    } catch {}
}

function Load-Creds {
    if (Test-Path $Script:CredFile) {
        try {
            $c = Import-Clixml $Script:CredFile
            $Script:txtS.Text=$c.Server
            $Script:txtU.Text=$c.User
            $Script:txtP.Password=[System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($c.Password))
        } catch {}
    }
}

function Scan-Server {
    param($Target)
    $TargetClean = $Target -replace "\\",""; $Script:IsRemote = -not ($TargetClean -match "localhost|127\.0\.0\.1|\." -or $env:COMPUTERNAME -match "^$TargetClean$" -or $TargetClean -match "^$env:COMPUTERNAME$")
    $FoundPath = $null; $Result = [PSCustomObject]@{ Valid=$false; Version="Not Found"; Path=$null; InstallPath=$null; CBValid=$false; CBVersion="Not Found"; CBInstallPath=$null }
    $CommonPaths = @("ProPhoenix\Server Application Manager\AppReg_Main.xml", "Program Files (x86)\ProPhoenix\Server Application Manager\AppReg_Main.xml", "Program Files\ProPhoenix\Server Application Manager\AppReg_Main.xml")
    if ($Script:IsRemote) { foreach ($drive in @("C$","D$","E$")) { foreach ($sub in $CommonPaths) { $p = "\\$TargetClean\$drive\$sub"; if (Test-Path $p -ErrorAction SilentlyContinue) { $FoundPath = $p; break } }; if ($FoundPath) { break } } } else { foreach ($d in (Get-PSDrive -PSProvider FileSystem).Root) { foreach ($sub in $CommonPaths) { $p = Join-Path $d $sub; if (Test-Path $p -ErrorAction SilentlyContinue) { $FoundPath = $p; break } }; if ($FoundPath) { break } } }
    if ($FoundPath) { $Result.Path = $FoundPath; try { [xml]$x = Get-Content $FoundPath -ErrorAction Stop; if ($x.PhoenixApplications.AppReg) { foreach ($app in $x.PhoenixApplications.AppReg) { if ($app.AppPath -like "*Database Utility*" -and $app.AppPath -notlike "*CodeBook*" -and $app.AppPath -notlike "*CRM*") { $v = if ($app.CurrentVersion) { $app.CurrentVersion } else { $app.Version }; $Result.Version = if ([string]::IsNullOrWhiteSpace($v)) { "0.0.0.0" } else { $v }; $Result.InstallPath = $app.AppPath; $Result.Valid = $true }; if ($app.AppPath -like "*CodeBook*") { $v = if ($app.CurrentVersion) { $app.CurrentVersion } else { $app.Version }; $Result.CBVersion = if ([string]::IsNullOrWhiteSpace($v)) { "0.0.0.0" } else { $v }; $Result.CBInstallPath = $app.AppPath; $Result.CBValid = $true } } } } catch { $Result.Err = "Read Error" } }
    
    $Script:form.Dispatcher.Invoke([Action]{
        if ($Result.Valid) { $Script:DBSyncRoot = Join-Path $Result.InstallPath "DB Sync"; $Script:txtPath.Text = $Script:DBSyncRoot; $Script:lblVer.Text = "DB Ver: $($Result.Version)"; $Script:lblVer.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.ColorConverter]::ConvertFromString("#00FF7F"))); Log "  ✔ Found Main Utility: $($Result.Version)" "Lime"; $Script:AppMgrPath = Join-Path (Split-Path $Result.Path -Parent) "PnxAppMgr.exe" } 
        else { $Script:lblVer.Text = "DB Ver: Not Found"; $Script:lblVer.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.ColorConverter]::ConvertFromString("#FF4C4C"))); $Script:DBSyncRoot = $null }
        if ($Result.CBValid) { $Script:CodebookRoot = Join-Path $Result.CBInstallPath "DB Sync"; Log "  ✔ Found Codebook Utility: $($Result.CBVersion)" "Lime"; $Script:lblCBVer.Text = "CB Ver: $($Result.CBVersion)"; $Script:lblCBVer.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.ColorConverter]::ConvertFromString("#00FF7F"))) } 
        else { $Script:CodebookRoot = $null; $Script:lblCBVer.Text = "CB Ver: Not Found"; $Script:lblCBVer.Foreground = (New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.ColorConverter]::ConvertFromString("#FF4C4C"))) }
    })
}

function Show-SyncErrorAlert { param($DBName, $LogLines) $errForm = New-Object System.Windows.Forms.Form; $errForm.Text = "🚨 SYNC FAILURE MONITOR : $DBName"; $errForm.Size = New-Object System.Drawing.Size(700, 450); $errForm.StartPosition = "CenterScreen"; $errForm.BackColor = [System.Drawing.Color]::FromArgb(30, 10, 10); $errForm.ForeColor = [System.Drawing.Color]::WhiteSmoke; $errForm.TopMost = $true; $lblTitle = New-Object System.Windows.Forms.Label; $lblTitle.Text = "CRITICAL ERROR DETECTED ON: $DBName"; $lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold); $lblTitle.ForeColor = [System.Drawing.Color]::Salmon; $lblTitle.Dock = "Top"; $lblTitle.TextAlign = "MiddleCenter"; $lblTitle.Height = 40; $errForm.Controls.Add($lblTitle); $txtErr = New-Object System.Windows.Forms.RichTextBox; $txtErr.Dock = "Fill"; $txtErr.BackColor = [System.Drawing.Color]::FromArgb(20, 20, 20); $txtErr.ForeColor = [System.Drawing.Color]::LightCoral; $txtErr.Font = New-Object System.Drawing.Font("Consolas", 10); $txtErr.ReadOnly = $true; $txtErr.Text = ($LogLines -join "`r`n"); $errForm.Controls.Add($txtErr); $btnOk = New-Object System.Windows.Forms.Button; $btnOk.Text = "ACKNOWLEDGE ERROR"; $btnOk.Dock = "Bottom"; $btnOk.Height = 45; $btnOk.BackColor = [System.Drawing.Color]::Crimson; $btnOk.ForeColor = [System.Drawing.Color]::White; $btnOk.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold); $btnOk.FlatStyle = "Flat"; $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK; $errForm.Controls.Add($btnOk); [void]$errForm.ShowDialog() }
function Get-SyncErrorDetails { param($WorkDir) try { $logDirs = @($WorkDir, "$WorkDir\Logs", "$WorkDir\Log"); $latestLog = Get-ChildItem -Path $logDirs -File -Include DBToolLog*.txt, sync_*.txt, *.log, *.txt -Exclude "PnxAutoNewDBSyn.xml" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1; if ($latestLog -and ($latestLog.LastWriteTime -ge (Get-Date).AddMinutes(-5))) { return Get-Content $latestLog.FullName -Tail 25 -ErrorAction SilentlyContinue }; return @("No recent crash logs found in $WorkDir.", "Please check Windows Event Viewer or SQL Logs.") } catch { return @("Error parsing log directory.") } }
function Get-DBJurisIDs { param($DBName) $jList = @(); try { $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS $DBName 5)); $CN.Open(); $cmd = $CN.CreateCommand(); $cmd.CommandText = "SELECT DISTINCT JurisID FROM Juris WITH(NOLOCK) ORDER BY JurisID"; $rdr = $cmd.ExecuteReader(); while($rdr.Read()){ $jList += $rdr.GetValue(0).ToString() }; $rdr.Close(); $CN.Close() } catch { Log "  ⚠ Could not fetch JurisIDs from $DBName." "Orange" }; if ($jList.Count -eq 0) { $jList += "1000" }; return $jList }
function Show-JurisSelector { param($T, $P, $Options) $f = New-Object System.Windows.Forms.Form; $f.Text = $T; $f.Size = New-Object System.Drawing.Size(350, 150); $f.StartPosition = "CenterParent"; $f.BackColor = [System.Drawing.Color]::FromArgb(28, 28, 35); $f.ForeColor = [System.Drawing.Color]::White; $l = New-Object System.Windows.Forms.Label; $l.Text = $P; $l.Location = "10,10"; $l.AutoSize = $true; $f.Controls.Add($l); $cb = New-Object System.Windows.Forms.ComboBox; $cb.Location = "10,35"; $cb.Width = 310; foreach($o in $Options){ [void]$cb.Items.Add($o) }; if($cb.Items.Count -gt 0){ $cb.SelectedIndex = 0 }; $f.Controls.Add($cb); $b = New-Object System.Windows.Forms.Button; $b.Text = "OK"; $b.DialogResult = [System.Windows.Forms.DialogResult]::OK; $b.Location = "120,70"; $f.Controls.Add($b); $f.AcceptButton = $b; if($f.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){ return $cb.Text } return $null }
function Show-CopyDialog { $d = New-Object System.Windows.Forms.Form; $d.Text = "Select Copy Type"; $d.Size = New-Object System.Drawing.Size(300, 150); $d.StartPosition = "CenterParent"; $d.BackColor = [System.Drawing.Color]::FromArgb(28, 28, 35); $d.ForeColor = [System.Drawing.Color]::White; $l = New-Object System.Windows.Forms.Label; $l.Text = "Select Target Type:"; $l.Location = "20,20"; $l.AutoSize = $true; $d.Controls.Add($l); $cb = New-Object System.Windows.Forms.ComboBox; $cb.Items.AddRange(@("Train (Tr)", "Test (Test)")); $cb.SelectedIndex = 0; $cb.Location = "20,50"; $cb.Width = 240; $d.Controls.Add($cb); $b = New-Object System.Windows.Forms.Button; $b.Text = "PROCEED"; $b.DialogResult = [System.Windows.Forms.DialogResult]::OK; $b.Location = "80,80"; $d.Controls.Add($b); $d.AcceptButton = $b; if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $cb.SelectedItem }; return $null }
function Show-NewDBDialog { $dbForm=New-Object System.Windows.Forms.Form; $dbForm.Text="Create DB"; $dbForm.Size="400,380"; $dbForm.StartPosition="CenterParent"; $dbForm.BackColor = [System.Drawing.Color]::FromArgb(28, 28, 35); $dbForm.ForeColor = [System.Drawing.Color]::White; $lblC=New-Object System.Windows.Forms.Label; $lblC.Text="Category:"; $lblC.Location="20,30"; $dbForm.Controls.Add($lblC); $cmbCat=New-Object System.Windows.Forms.ComboBox; $cmbCat.Items.AddRange(@("Police","Fire","Phoenix Master","IA","Police CSP","Fire CSP")); $cmbCat.SelectedIndex=0; $cmbCat.Location="120,27"; $cmbCat.Width=240; $dbForm.Controls.Add($cmbCat); function Add-Field($lbl,$y,$def){ $l=New-Object System.Windows.Forms.Label; $l.Text=$lbl; $l.Location="20,$y"; $dbForm.Controls.Add($l); $t=New-Object System.Windows.Forms.TextBox; $t.Text=$def; $t.Location="120,$($y-3)"; $t.Width=240; $dbForm.Controls.Add($t); return $t }; $inDB=Add-Field "Database" 70 "PhoenixPolice"; $inJID=Add-Field "JurisID" 110 "1000"; $inSt=Add-Field "State" 150 "MA"; $inN=Add-Field "Name" 190 "ProPhoenix"; $inA=Add-Field "Alias" 230 "PNX"; $btn=New-Object System.Windows.Forms.Button; $btn.Text="CREATE"; $btn.DialogResult=[System.Windows.Forms.DialogResult]::OK; $btn.Location="120,280"; $dbForm.Controls.Add($btn); $dbForm.AcceptButton=$btn; if($dbForm.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){ return @{DB=$inDB.Text; JID=$inJID.Text; St=$inSt.Text; Nm=$inN.Text; Al=$inA.Text; Cat=$cmbCat.SelectedItem } } return $null }
function Show-InputBox { param($T, $P, $D) $f = New-Object System.Windows.Forms.Form; $f.Text = $T; $f.Size = New-Object System.Drawing.Size(350, 150); $f.StartPosition = "CenterParent"; $f.BackColor = [System.Drawing.Color]::FromArgb(28, 28, 35); $f.ForeColor = [System.Drawing.Color]::White; $l = New-Object System.Windows.Forms.Label; $l.Text = $P; $l.Location = "10,10"; $l.AutoSize = $true; $f.Controls.Add($l); $t = New-Object System.Windows.Forms.TextBox; $t.Text = $D; $t.Location = "10,35"; $t.Width = 310; $f.Controls.Add($t); $b = New-Object System.Windows.Forms.Button; $b.Text = "OK"; $b.DialogResult = "OK"; $b.Location = "120,70"; $f.Controls.Add($b); $f.AcceptButton = $b; if($f.ShowDialog() -eq "OK"){ return $t.Text } return $null }

function Invoke-CleanAndKill { param($dbTarget, $killMainDbSessions) try { $killCN = New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 15)); $killCN.Open(); $killCmd = $killCN.CreateCommand(); if ($killMainDbSessions) { $killCmd.CommandText = "IF DB_ID('$dbTarget') IS NOT NULL BEGIN DECLARE @k1 varchar(8000) = ''; SELECT @k1 = @k1 + 'kill ' + CONVERT(varchar(5), session_id) + ';' FROM sys.dm_exec_sessions WHERE database_id = db_id('$dbTarget'); EXEC(@k1); END"; $killCmd.ExecuteNonQuery() | Out-Null }; $tempDbName = "$dbTarget" + "PnxDBSync"; $killCmd.CommandText = "IF DB_ID('$tempDbName') IS NOT NULL BEGIN DECLARE @k2 varchar(8000) = ''; SELECT @k2 = @k2 + 'kill ' + CONVERT(varchar(5), session_id) + ';' FROM sys.dm_exec_sessions WHERE database_id = db_id('$tempDbName'); EXEC(@k2); EXEC('ALTER DATABASE [$tempDbName] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$tempDbName];'); END"; $killCmd.ExecuteNonQuery() | Out-Null; $killCN.Close() } catch {} }

function Execute-CodebookSync { param($RawItems) try { if(-not $Script:CodebookRoot -or -not (Test-Path $Script:CodebookRoot)) { Show-CustomAlert "Missing Utility" "Codebook Utility is not installed or detected on this server."; return }; $fireTargets = @(); foreach($i in $RawItems) { if ($Script:TargetMap[$i].Folder -match "Fire") { $fireTargets += $Script:TargetMap[$i].DB } }; if ($fireTargets.Count -eq 0) { Show-CustomAlert "Invalid Target" "No Fire databases selected! Codebook sync only applies to Fire DBs."; return }; Log "▶ INITIATING CODEBOOK SYNC (FIRE ONLY)..." "Red"; $cbExePath = Get-ChildItem -Path $Script:CodebookRoot -Filter "PnxDBSync.exe" -Recurse | Select-Object -First 1; if (-not $cbExePath) { Log "   ❌ Could not find PnxDBSync.exe inside Codebook folder." "Red"; return }; $cbWd = $cbExePath.DirectoryName; $XmlPath = Join-Path $cbWd "PnxAutoNewDBSyn.xml"; $syncMode = $Script:form.Dispatcher.Invoke([Func[string]]{return $Script:cmbSyncType.Text}).Substring(0,1); $isMulti = ($Script:form.Dispatcher.Invoke([Func[string]]{return $Script:cmbSyncType.Text}) -match "Batch" -or $Script:form.Dispatcher.Invoke([Func[string]]{return $Script:cmbSyncType.Text}) -match "3"); $wshell = New-Object -ComObject wscript.shell; if ($isMulti) { $dbList = $fireTargets -join ";"; Log "  > Grouping Fire DBs for Codebook: $dbList" "White"; foreach($D in $fireTargets) { Invoke-CleanAndKill $D $true }; Start-Sleep -Seconds 2; if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; $XmlString = @"
<?xml version="1.0" encoding="utf-8" ?>
<PnxPakager><SourceServer><IPAddress>$($Script:txtS.Text)</IPAddress><DBName>$dbList</DBName><UserName>$($Script:txtU.Text)</UserName><Password>$($Script:txtP.Password)</Password><JurisID>1000</JurisID><State>MA</State><JurisName>ProPhoenix</JurisName><JurisAlias>PNX</JurisAlias><SyncType>3</SyncType></SourceServer></PnxPakager>
"@
[System.IO.File]::WriteAllText($XmlPath, $XmlString, (New-Object System.Text.UTF8Encoding($false))); $SyncProc = Start-Process $cbExePath.FullName -WorkingDirectory $cbWd -WindowStyle Normal -PassThru; $stopwatch = [System.Diagnostics.Stopwatch]::StartNew(); $promptHandled = $false; while (-not $SyncProc.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250; if (-not $promptHandled -and $stopwatch.Elapsed.TotalSeconds -gt 3 -and $stopwatch.Elapsed.TotalSeconds -lt 20) { try { if ($wshell.AppActivate($SyncProc.Id)) { Start-Sleep -Milliseconds 100; $wshell.SendKeys("Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("%Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("{ENTER}"); $promptHandled = $true; Log "   > Auto-Answered Codebook Prompt." "DarkGray" } } catch {} } }; $stopwatch.Stop(); if ($SyncProc.ExitCode -eq 0) { Log "   ✔ Codebook Batch Sync Completed" "Lime" } else { Log "   ❌ Codebook Batch Process Failed! (Exit Code: $($SyncProc.ExitCode))" "Red"; Show-SyncErrorAlert -DBName "CODEBOOK BATCH" -LogLines (Get-SyncErrorDetails -WorkDir $cbWd) }; if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; foreach($D in $fireTargets) { Invoke-CleanAndKill $D $true } } else { foreach ($D in $fireTargets) { Log "  > Syncing Codebook for: $D" "White"; $killMain = if ($syncMode -eq "1") { $false } else { $true }; Invoke-CleanAndKill $D $killMain; Start-Sleep -Seconds 2; if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; $XmlString = @"
<?xml version="1.0" encoding="utf-8" ?>
<PnxPakager><SourceServer><IPAddress>$($Script:txtS.Text)</IPAddress><DBName>$D</DBName><UserName>$($Script:txtU.Text)</UserName><Password>$($Script:txtP.Password)</Password><JurisID>1000</JurisID><State>MA</State><JurisName>ProPhoenix</JurisName><JurisAlias>PNX</JurisAlias><SyncType>$syncMode</SyncType></SourceServer></PnxPakager>
"@
[System.IO.File]::WriteAllText($XmlPath, $XmlString, (New-Object System.Text.UTF8Encoding($false))); $SyncProc = Start-Process $cbExePath.FullName -WorkingDirectory $cbWd -WindowStyle Normal -PassThru; $stopwatch = [System.Diagnostics.Stopwatch]::StartNew(); $promptHandled = $false; while (-not $SyncProc.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250; if (-not $promptHandled -and $stopwatch.Elapsed.TotalSeconds -gt 3 -and $stopwatch.Elapsed.TotalSeconds -lt 20) { try { if ($wshell.AppActivate($SyncProc.Id)) { Start-Sleep -Milliseconds 100; $wshell.SendKeys("Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("%Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("{ENTER}"); $promptHandled = $true; Log "   > Auto-Answered Codebook Prompt." "DarkGray" } } catch {} } }; $stopwatch.Stop(); if ($SyncProc.ExitCode -eq 0) { Log "   ✔ Codebook Sync Completed for $D" "Lime" } else { Log "   ❌ Codebook Sync Failed for $D (Exit Code: $($SyncProc.ExitCode))" "Red"; Show-SyncErrorAlert -DBName "CODEBOOK: $D" -LogLines (Get-SyncErrorDetails -WorkDir $cbWd) }; if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; Invoke-CleanAndKill $D $killMain } } } catch { Log "❌ Codebook Error: $($_.Exception.Message)" "Red" } }

function Execute-DBSync { param($RawItems) try { if ($RawItems.Count -eq 0) { return }; $safeItems = @(); foreach ($i in $RawItems) { $safeItems += $i }; $FailedDBs = @(); $syncMode = $Script:form.Dispatcher.Invoke([Func[string]]{return $Script:cmbSyncType.Text}).Substring(0,1); $isMulti = ($Script:form.Dispatcher.Invoke([Func[string]]{return $Script:cmbSyncType.Text}) -match "Batch" -or $Script:form.Dispatcher.Invoke([Func[string]]{return $Script:cmbSyncType.Text}) -match "3"); $wshell = New-Object -ComObject wscript.shell; if ($isMulti) { Log "▶ BATCH SYNC INITIATED (SyncType 3)" "Cyan"; $groupedDBs = @{}; foreach ($i in $safeItems) { $I = $Script:TargetMap[$i]; $D = $I.DB; $F = $I.Folder; if ($F -eq "None") { Log "   ! Skipped $($D): No Utility Folder Mapped" "Orange"; continue }; if (-not $groupedDBs.ContainsKey($F)) { $groupedDBs[$F] = @() }; $groupedDBs[$F] += $D }; $safeKeys = @(); foreach ($k in $groupedDBs.Keys) { $safeKeys += $k }; $sortedFolders = $safeKeys | Sort-Object { if ($_ -eq 'Phoenix Master') { 0 } else { 1 } }; foreach ($F in $sortedFolders) { $dbList = $groupedDBs[$F] -join ";"; $WD = "$($Script:DBSyncRoot)\$F"; $XmlPath = "$WD\PnxAutoNewDBSyn.xml"; Log "▶ Processing Group [$F]" "Yellow"; [System.Windows.Forms.Application]::DoEvents(); Log "  Targets: $dbList" "White"; if (!(Test-Path "$WD\PnxDBSync.exe")) { Log "   ! Skipped: Missing EXE in $WD" "Orange"; continue }; foreach ($D in $groupedDBs[$F]) { Invoke-CleanAndKill $D $true }; Start-Sleep -Seconds 2; if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; $XmlString = @"
<?xml version="1.0" encoding="utf-8" ?>
<PnxPakager><SourceServer><IPAddress>$($Script:txtS.Text)</IPAddress><DBName>$dbList</DBName><UserName>$($Script:txtU.Text)</UserName><Password>$($Script:txtP.Password)</Password><JurisID>1000</JurisID><State>MA</State><JurisName>ProPhoenix</JurisName><JurisAlias>PNX</JurisAlias><SyncType>3</SyncType></SourceServer></PnxPakager>
"@
[System.IO.File]::WriteAllText($XmlPath, $XmlString, (New-Object System.Text.UTF8Encoding($false))); $SyncProc = Start-Process "$WD\PnxDBSync.exe" -WorkingDirectory $WD -WindowStyle Normal -PassThru; $stopwatch = [System.Diagnostics.Stopwatch]::StartNew(); $promptHandled = $false; while (-not $SyncProc.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250; if (-not $promptHandled -and $stopwatch.Elapsed.TotalSeconds -gt 3 -and $stopwatch.Elapsed.TotalSeconds -lt 20) { try { if ($wshell.AppActivate($SyncProc.Id)) { Start-Sleep -Milliseconds 100; $wshell.SendKeys("Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("%Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("{ENTER}"); $promptHandled = $true; Log "   > Auto-Answered Upgrade Prompt." "DarkGray" } } catch {} } }; $stopwatch.Stop(); if ($SyncProc.ExitCode -eq 0) { Log "   ✔ Batch Sync Completed Successfully" "Lime" } else { $FailedDBs += "Group: $F ($dbList)"; Log "   ❌ Batch Sync Process Failed! (Exit Code: $($SyncProc.ExitCode))" "Red"; Show-SyncErrorAlert -DBName "BATCH GROUP: $F" -LogLines (Get-SyncErrorDetails -WorkDir $WD) }; if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; foreach ($D in $groupedDBs[$F]) { Invoke-CleanAndKill $D $true } } } else { $sortedItems = $safeItems | Sort-Object { if ($Script:TargetMap[$_].Folder -eq 'Phoenix Master') { 0 } else { 1 } }; foreach ($i in $sortedItems) { $I = $Script:TargetMap[$i]; $D = $I.DB; $F = $I.Folder; $XmlPath = "$($Script:DBSyncRoot)\$F\PnxAutoNewDBSyn.xml"; Log "▶ EXECUTING SYNC: $($D) (SyncType $syncMode)" "Cyan"; [System.Windows.Forms.Application]::DoEvents(); try { if ($F -eq "None") { Log "   ! Skipped $($D): No Utility Folder Mapped" "Orange"; continue }; $WD = "$($Script:DBSyncRoot)\$F"; if (!(Test-Path "$WD\PnxDBSync.exe")) { Log "   ! Skipped: Missing EXE in $WD" "Orange"; continue }; $killMain = if ($syncMode -eq "1") { $false } else { $true }; Invoke-CleanAndKill $D $killMain; Start-Sleep -Seconds 2; if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; $XmlString = @"
<?xml version="1.0" encoding="utf-8" ?>
<PnxPakager><SourceServer><IPAddress>$($Script:txtS.Text)</IPAddress><DBName>$D</DBName><UserName>$($Script:txtU.Text)</UserName><Password>$($Script:txtP.Password)</Password><JurisID>1000</JurisID><State>MA</State><JurisName>ProPhoenix</JurisName><JurisAlias>PNX</JurisAlias><SyncType>$syncMode</SyncType></SourceServer></PnxPakager>
"@
[System.IO.File]::WriteAllText($XmlPath, $XmlString, (New-Object System.Text.UTF8Encoding($false))); $SyncProc = Start-Process "$WD\PnxDBSync.exe" -WorkingDirectory $WD -WindowStyle Normal -PassThru; $stopwatch = [System.Diagnostics.Stopwatch]::StartNew(); $promptHandled = $false; while (-not $SyncProc.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250; if (-not $promptHandled -and $stopwatch.Elapsed.TotalSeconds -gt 3 -and $stopwatch.Elapsed.TotalSeconds -lt 20) { try { if ($wshell.AppActivate($SyncProc.Id)) { Start-Sleep -Milliseconds 100; $wshell.SendKeys("Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("%Y"); Start-Sleep -Milliseconds 50; $wshell.SendKeys("{ENTER}"); $promptHandled = $true; Log "   > Auto-Answered Upgrade Prompt." "DarkGray" } } catch {} } }; $stopwatch.Stop(); if ($SyncProc.ExitCode -eq 0) { if ($syncMode -eq "1") { Log "   ✔ Sync Completed Successfully (Note: Make DB skips existing DBs)" "Lime" } else { Log "   ✔ Sync Completed Successfully" "Lime" } } else { $FailedDBs += $D; Log "   ❌ Sync Process Failed! (Exit Code: $($SyncProc.ExitCode))" "Red"; Show-SyncErrorAlert -DBName $D -LogLines (Get-SyncErrorDetails -WorkDir $WD) } } catch { Log "   ❌ Exception during execution: $($_.Exception.Message)" "Red"; $FailedDBs += $D } finally { if (Test-Path $XmlPath) { Remove-Item $XmlPath -Force -ErrorAction SilentlyContinue }; Invoke-CleanAndKill $D $killMain } } }; if ($FailedDBs.Count -gt 0) { $msg = "The following databases encountered hard crashes during sync:`n`n" + ($FailedDBs -join "`n"); Show-CustomAlert "Sync Errors" $msg } else { Log "✔ All databases processed successfully." "Lime" } } catch { Log "❌ CRITICAL PIPELINE ERROR: $($_.Exception.Message)" "Red" } }

function Apply-EnterpriseConfig { param($TargetDB, $SourceFile, $TargetJuris) $Content = Get-Content $SourceFile; $restoreParams = @{}; $restoreJobs = @(); $currentMode = "NONE"; $currentJob = $null; foreach ($line in $Content) { $l = $line.Trim(); if ($l -eq "" -or $l.StartsWith("#")) { continue }; if ($l.ToUpper() -eq "[PARAMETERS]") { $currentMode = "PARAMS"; continue }; if ($l -match "^\[JOB:(.+)\]$") { $currentMode = "JOB"; if ($currentJob -ne $null) { $restoreJobs += $currentJob }; $currentJob = @{ Name = $Matches[1]; Type = $null; Params = @(); Notifies = @() }; continue }; if ($currentMode -eq "PARAMS") { $parts = $l -split "=", 2; if ($parts.Count -eq 2) { $restoreParams[$parts[0].Trim()] = $parts[1].Trim() } } elseif ($currentMode -eq "JOB" -and $currentJob -ne $null) { $parts = $l -split "=", 2; if ($parts.Count -eq 2) { $k = $parts[0].Trim(); $v = $parts[1].Trim(); if ($k -eq "JobType") { $currentJob.Type = $v } elseif ($k -match "^Param:(.+)$") { $currentJob.Params += @{ Name = $Matches[1]; Value = $v } } elseif ($k -eq "NotifyPath") { $currentJob.Notifies += $v } } } }; if ($currentJob -ne $null) { $restoreJobs += $currentJob }; try { $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS $TargetDB 15)); $CN.Open(); $pUpdated = 0; $pInserted = 0; $pSkipped = 0; foreach ($paramID in $restoreParams.Keys) { $paramVal = $restoreParams[$paramID].Replace("'", "''"); $upsertQuery = "SET NOCOUNT ON; DECLARE @tID INT = $paramID; DECLARE @tVal NVARCHAR(MAX) = '$paramVal'; DECLARE @sysJurisID INT = $TargetJuris; IF EXISTS (SELECT 1 FROM Parameter WHERE CAST(ParamID AS INT) = @tID AND JurisID = @sysJurisID) BEGIN UPDATE Parameter SET ParamValue = @tVal WHERE CAST(ParamID AS INT) = @tID AND JurisID = @sysJurisID; SELECT 'Updated' AS Action; END ELSE BEGIN IF OBJECT_ID('dbo.ParameterName', 'U') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.ParameterName WHERE CAST(ParamID AS INT) = @tID) BEGIN SELECT 'Skipped_FK' AS Action; END ELSE BEGIN DECLARE @nextSLNo BIGINT; SELECT @nextSLNo = ISNULL(MAX(CAST(SLNo AS BIGINT)), 0) + 1 FROM Parameter WITH (UPDLOCK, HOLDLOCK); INSERT INTO Parameter (SLNo, ParamID, ParamValue, JurisID) VALUES (@nextSLNo, @tID, @tVal, @sysJurisID); SELECT 'Inserted' AS Action; END END"; $cmd = $CN.CreateCommand(); $cmd.CommandText = $upsertQuery; try { $res = $cmd.ExecuteScalar(); if ($res -eq 'Updated') { $pUpdated++ } elseif ($res -eq 'Inserted') { $pInserted++ } elseif ($res -eq 'Skipped_FK') { $pSkipped++ } } catch { } }; Log "   ✔ Params: $pUpdated Updated | $pInserted Inserted | $pSkipped Skipped" "Lime"; $jRestored = 0; foreach ($job in $restoreJobs) { $jName = $job.Name.Replace("'", "''"); $jType = if ([string]::IsNullOrWhiteSpace($job.Type)) { "JobType" } else { "'$($job.Type.Replace("'", "''"))'" }; $jobQuery = "DECLARE @jID BIGINT; SELECT TOP 1 @jID = JobID FROM KPIjobs WHERE JobName = '$jName'; IF @jID IS NOT NULL BEGIN UPDATE KPIjobs SET IsInactive = 0, StartDttm = GETDATE(), EndDttm = '2099-12-31', NextExDttm = GETDATE(), JobType = $jType WHERE JobID = @jID; DELETE FROM KPIjobsparam WHERE JobID = @jID; DELETE FROM KPIJobsNotify WHERE JobID = @jID; SELECT @jID AS FoundJobID; END"; $cmd = $CN.CreateCommand(); $cmd.CommandText = $jobQuery; $returnedJobID = $cmd.ExecuteScalar(); if ($returnedJobID) { if ($job.Params) { foreach ($jp in $job.Params) { $pName = $jp.Name.Replace("'", "''"); $pVal = $jp.Value.Replace("'", "''"); $cmd.CommandText = "INSERT INTO KPIjobsparam(JobID, SeqNo, ParamName, ParamValue) VALUES ($returnedJobID, (SELECT ISNULL(MAX(SeqNo),0)+1 FROM KPIjobsparam WHERE JobID = $returnedJobID), '$pName', '$pVal')"; $cmd.ExecuteNonQuery() | Out-Null } }; if ($job.Notifies) { foreach ($folder in $job.Notifies) { $fSafe = $folder.Replace("'", "''"); $cmd.CommandText = "INSERT INTO KPIJobsNotify SELECT $returnedJobID, (SELECT ISNULL(MAX(SeqNo),0)+1 FROM KPIJobsNotify WHERE JobID = j.JobID), NULL, NULL, '$fSafe', 1, NULL, NULL, NULL, NULL FROM KPIJobs j WHERE JobID = $returnedJobID"; $cmd.ExecuteNonQuery() | Out-Null } }; $jRestored++ } }; Log "   ✔ Jobs: $jRestored Configured Successfully" "Lime"; $CN.Close() } catch { Log "   ❌ Config Apply Failed: $($_.Exception.Message)" "Red" } }

function Invoke-AppMgr { param($Mode) $hasAppMgr = $false; if (-not [string]::IsNullOrWhiteSpace($Script:AppMgrPath)) { if (Test-Path $Script:AppMgrPath) { $hasAppMgr = $true } }; if (-not $hasAppMgr) { if (-not [string]::IsNullOrWhiteSpace($Script:txtPath.Text) -and (Test-Path $Script:txtPath.Text)) { $Script:AppMgrPath = Join-Path (Split-Path $Script:txtPath.Text -Parent) "PnxAppMgr.exe" }; if (-not [string]::IsNullOrWhiteSpace($Script:AppMgrPath) -and (Test-Path $Script:AppMgrPath)) { $hasAppMgr = $true }; if (-not $hasAppMgr) { Show-CustomAlert "Notice" "Please locate PnxAppMgr.exe"; $f=New-Object System.Windows.Forms.OpenFileDialog; $f.Filter="PnxAppMgr.exe|PnxAppMgr.exe"; if($f.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){$Script:AppMgrPath=$f.FileName}else{return} } }; $Bat = Join-Path $env:TEMP "PnxAction.bat"; $Dir = Split-Path $Script:AppMgrPath -Parent; $BatContent = "@echo off`ncd /d `"$Dir`"`n"; if ($Mode -eq "INSTALL") { $BatContent += "`"$($Script:AppMgrPath)`" INSTALL `"DBUtility`"`n"; $ans = [System.Windows.Forms.MessageBox]::Show("Do you also want to install the Codebook Utility (DatabaseUtilityCodebook)?", "Install Codebook?", 4, 32); if ($ans -eq 6) { $BatContent += "`"$($Script:AppMgrPath)`" INSTALL `"DatabaseUtilityCodebook`"`n" } } elseif ($Mode -eq "UNINSTALL") { $BatContent += "`"$($Script:AppMgrPath)`" UNINSTALL `"DBUtility`"`n"; $ans = [System.Windows.Forms.MessageBox]::Show("Do you also want to uninstall the Codebook Utility?", "Uninstall Codebook?", 4, 32); if ($ans -eq 6) { $BatContent += "`"$($Script:AppMgrPath)`" UNINSTALL `"DatabaseUtilityCodebook`"`n" } }; $BatContent += "pause"; Set-Content $Bat $BatContent; Start-Process $Bat -Verb RunAs }

# --- CORE INTERFACE CONTROL HANDLERS MAP ---
$Script:btnBrowse.Add_Click({ $fbd = New-Object System.Windows.Forms.FolderBrowserDialog; $fbd.Description = "Select DB Sync Folder"; if ($fbd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $Script:txtPath.Text=$fbd.SelectedPath; $Script:DBSyncRoot=$fbd.SelectedPath; Log "Path Set Manually." "Gray" } })

$Script:btnSync.Add_Click({ 
    try { $s=Get-SelectedKeys; if($s.Count -eq 0){ Show-CustomAlert "Selection Required" "Please select at least one database to Sync!"; return }; Toggle $false; $Script:form.FindResource("CloseDrawer").Begin(); Run-Async $Script:btnSync { Execute-DBSync $s } } 
    catch { Log "❌ Error: $($_.Exception.Message)" "Red" } 
})

$Script:btnCodebook.Add_Click({ 
    try { $s=Get-SelectedKeys; if($s.Count -eq 0){ Show-CustomAlert "Selection Required" "Please select at least one Fire database!"; return }; Toggle $false; $Script:form.FindResource("CloseDrawer").Begin(); Run-Async $Script:btnCodebook { Execute-CodebookSync $s } } 
    catch { Log "❌ Error: $($_.Exception.Message)" "Red" } 
})

$Script:btnVer.Add_Click({ 
    try { 
        $s=Get-SelectedKeys; if($s.Count -eq 0){ $picked = Show-DBSelectBox "Check Version"; if ($picked) { $s = @($picked) } else { return } }; 
        Toggle $false; $Script:form.FindResource("CloseDrawer").Begin(); 
        Run-Async $Script:btnVer { 
            Log "▶ CHECKING VERSIONS..." "Cyan"; Scan-Server $Script:txtS.Text; 
            $cn=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 15)); $cn.Open(); 
            foreach($i in $s){ 
                $D=$Script:TargetMap[$i].DB; $cmd=$cn.CreateCommand(); 
                $cmd.CommandText="SELECT TOP 1 Version FROM [$D].dbo.KPIDBVersion ORDER BY ApplyDate DESC"; 
                try{ 
                    $v=$cmd.ExecuteScalar(); if ([string]::IsNullOrWhiteSpace($v)) { $v = "Unknown" }
                    Log "  $D : $v" "White"; 
                    $Script:form.Dispatcher.Invoke([Action]{ 
                        for ($idx = 0; $idx -lt $Script:listDBs.Items.Count; $idx++) { 
                            if ($Script:listDBs.Items[$idx].Key -eq $i) { 
                                $oldObj = $Script:listDBs.Items[$idx]; 
                                $cleanName = $oldObj.DBName -replace " - Ver:.*",""; 
                                $newText = "$cleanName - Ver: $v"; 
                                $newObj = [PSCustomObject]@{ Key = $oldObj.Key; DBName = $newText; Type = $oldObj.Type; IsChecked = $oldObj.IsChecked }; 
                                $Script:listDBs.Items[$idx] = $newObj; break 
                            } 
                        }; 
                        $Script:listDBs.Items.Refresh() 
                    }) 
                }catch{Log "  $D : Error" "Red"} 
            }; $cn.Close() 
        } 
    } catch {} 
})

$Script:btnBackupDB.Add_Click({ 
    try { 
        $s=Get-SelectedKeys; if($s.Count -eq 0){ Show-CustomAlert "Selection Required" "Please select at least one database to Backup!"; return }; 
        $fbd = New-Object System.Windows.Forms.FolderBrowserDialog; $fbd.SelectedPath = $Script:DefaultBackup; if($fbd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){ return }; 
        Toggle $false; $Script:form.FindResource("CloseDrawer").Begin(); 
        Run-Async $Script:btnBackupDB { 
            Log "▶ NATIVE SQL BACKUP..." "Cyan"; 
            $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 30)); $CN.FireInfoMessageEventOnUserErrors = $true; $CN.add_InfoMessage({ param($sender, $e) if ($e.Message -match "percent") { Log "   > $($e.Message)" "DarkGray" } }); $CN.Open(); 
            $Cmd=$CN.CreateCommand(); $Cmd.CommandTimeout = 0; 
            foreach ($item in $s) { 
                $DB = $Script:TargetMap[$item].DB; $BakFile = Join-Path $fbd.SelectedPath "$DB`_ManualBackup_$(Get-Date -Format 'yyyyMMdd_HHmm').bak"; Log "  > Backing up $DB..." "White"; [System.Windows.Forms.Application]::DoEvents(); $Cmd.CommandText="BACKUP DATABASE [$DB] TO DISK='$BakFile' WITH INIT, COMPRESSION, STATS=10"; 
                try { $Cmd.ExecuteNonQuery()|Out-Null; Log "  ✔ Backup Complete" "Lime" } catch { Log "  ❌ Failed" "Red" } 
            }; $CN.Close() 
        } 
    } catch {} 
})

$Script:btnRestoreDB.Add_Click({ 
    try { 
        $s=Get-SelectedKeys; if($s.Count -ne 1){ Show-CustomAlert "Selection Limit" "Select exactly ONE database to restore into."; return }; 
        $TargetDB = $Script:TargetMap[$s[0]].DB; $f = New-Object System.Windows.Forms.OpenFileDialog; $f.Filter = "SQL Backup|*.bak"; $f.InitialDirectory = $Script:DefaultBackup; if ($f.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }; 
        $BakFile = $f.FileName; if([System.Windows.Forms.MessageBox]::Show("Overwrite [$TargetDB]?", "Confirm", 4, 16) -ne 6){ return }; 
        Toggle $false; $Script:form.FindResource("CloseDrawer").Begin(); 
        Run-Async $Script:btnRestoreDB { 
            Log "▶ RESTORING [$TargetDB]..." "Red"; 
            $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 30)); $CN.FireInfoMessageEventOnUserErrors = $true; $CN.add_InfoMessage({ param($sender, $e) if ($e.Message -match "percent") { Log "   > $($e.Message)" "DarkGray" } }); $CN.Open(); $Cmd=$CN.CreateCommand(); $Cmd.CommandTimeout = 0; Log "  > Dropping sessions..." "Orange"; [System.Windows.Forms.Application]::DoEvents(); try { $CmdDrop = New-Object System.Data.SqlClient.SqlCommand("IF EXISTS(SELECT 1 FROM sys.databases WHERE name='$TargetDB') BEGIN DECLARE @kill varchar(8000) = ''; SELECT @kill = @kill + 'kill ' + CONVERT(varchar(5), session_id) + ';' FROM sys.dm_exec_sessions WHERE database_id = db_id('$TargetDB'); EXEC(@kill); ALTER DATABASE [$TargetDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; END", $CN); $CmdDrop.CommandTimeout = 0; $CmdDrop.ExecuteNonQuery()|Out-Null } catch {}; 
            $Cmd.CommandText="RESTORE FILELISTONLY FROM DISK='$BakFile'"; $Rdr=$Cmd.ExecuteReader(); $Files=@(); while($Rdr.Read()){$Files+=@{L=$Rdr["LogicalName"];P=$Rdr["PhysicalName"];T=$Rdr["Type"]}}; $Rdr.Close(); $MoveStr = ""; foreach($f in $Files){ $Ext=[System.IO.Path]::GetExtension($f.P); $Dir=[System.IO.Path]::GetDirectoryName($f.P); $NewName = "$TargetDB"; if ($f.T -eq "L") { $NewName += "_log" }; $NewName += $Ext; $MoveStr += "MOVE '$($f.L)' TO '$(Join-Path $Dir $NewName)', " }; Log "  > Restoring..." "White"; [System.Windows.Forms.Application]::DoEvents(); $Cmd.CommandText="RESTORE DATABASE [$TargetDB] FROM DISK='$BakFile' WITH RECOVERY, REPLACE, STATS=10, $($MoveStr.TrimEnd(', '))"; $Cmd.ExecuteNonQuery()|Out-Null; $Cmd.CommandText = "ALTER DATABASE [$TargetDB] SET MULTI_USER"; $Cmd.ExecuteNonQuery()|Out-Null; $CN.Close(); Log "  ✔ Restore Complete." "Lime"; $Script:form.Dispatcher.Invoke([Action]{Invoke-ConnectionEngine}) 
        } 
    } catch { Log "  ❌ Error: $($_.Exception.Message)" "Red" } 
})

$Script:btnDeleteDB.Add_Click({ 
    try {
        $s = Get-SelectedKeys
        if($s.Count -eq 0){ Show-CustomAlert "Selection Required" "Select at least one database to delete."; return }
        $Targets = @()
        foreach($i in $s){ $Targets += $Script:TargetMap[$i].DB }
        $Names = $Targets -join ", "
        if([System.Windows.Forms.MessageBox]::Show("You are about to PERMANENTLY DELETE $($s.Count) database(s):`n$Names`n`nThis is irreversible. Proceed?", "CRITICAL WARNING", 4, 16) -ne 6){ return }

        Toggle $false
        $Script:form.FindResource("CloseDrawer").Begin()
        Run-Async $Script:btnDeleteDB {
            Log "▶ INITIATING DATABASE DELETION..." "Red"
            $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 30)); $CN.Open()

            foreach ($DB in $Targets) {
                Log "  > Dropping Database: [$DB]..." "Orange"
                $Script:form.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background)
                try { 
                    $Cmd = $CN.CreateCommand(); $Cmd.CommandTimeout = 0; 
                    $Cmd.CommandText = "IF EXISTS (SELECT 1 FROM sys.databases WHERE name = '$DB') BEGIN ALTER DATABASE [$DB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$DB]; END"; 
                    $Cmd.ExecuteNonQuery() | Out-Null
                    Log "  ✔ Successfully Deleted: $DB" "Lime" 
                } catch { Log "  ❌ Failed to delete [$DB]: $($_.Exception.Message)" "Red" }
            }
            $CN.Close()
            Log "✔ Deletion process finished." "Lime"
            $Script:form.Dispatcher.Invoke([Action]{Invoke-ConnectionEngine})
        }
    } catch { Log "❌ CRITICAL ERROR: $($_.Exception.Message)" "Red" } 
})

$Script:btnSqlMem.Add_Click({
    try {
        Toggle $false
        Run-Async $Script:btnSqlMem {
            Log "▶ ANALYZING SQL SERVER MEMORY..." "Cyan"
            $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 15)); $CN.Open(); $Cmd=$CN.CreateCommand()
            try { $Cmd.CommandText = "EXEC sp_configure 'show advanced options', 1; RECONFIGURE WITH OVERRIDE;"; $Cmd.ExecuteNonQuery() | Out-Null } catch { }
            $Cmd.CommandText = "SELECT CAST(value_in_use AS INT) FROM sys.configurations WHERE name = 'max server memory (MB)'"
            $MaxMemRaw = $Cmd.ExecuteScalar()
            $MaxMem = if ($MaxMemRaw -is [int] -or $MaxMemRaw -is [long]) { [int]$MaxMemRaw } else { 0 }
            try {
                $Cmd.CommandText = "SELECT CAST((physical_memory_in_use_kb / 1024) AS INT) FROM sys.dm_os_process_memory"
                $InUseMemRaw = $Cmd.ExecuteScalar()
                $InUseMem = if ($InUseMemRaw -ne $null -and $InUseMemRaw -isnot [System.DBNull]) { [int]$InUseMemRaw } else { 0 }
                $Cmd.CommandText = "SELECT CAST((total_physical_memory_kb / 1024) AS INT) FROM sys.dm_os_sys_memory"
                $TotalOSMemRaw = $Cmd.ExecuteScalar()
                $TotalOSMem = if ($TotalOSMemRaw -ne $null -and $TotalOSMemRaw -isnot [System.DBNull]) { [int]$TotalOSMemRaw } else { 0 }
            } catch { $InUseMem = "Unknown"; $TotalOSMem = "Unknown" }

            $MinMemoryMB = 1024
            $NewMaxInt = [math]::Round($TotalOSMem * 0.75)
            if ($NewMaxInt -lt $MinMemoryMB) { $NewMaxInt = $MinMemoryMB }

            Log "  > OS Total Memory: $TotalOSMem MB" "White"
            Log "  > SQL Configured Limit: $MaxMem MB" "White"
            Log "  > SQL Currently Using: $InUseMem MB" "Orange"
            Log "  > Optimal 75% Target: $NewMaxInt MB" "Yellow"

            if ($MaxMem -eq $NewMaxInt) {
                Log "  ✔ SKIPPED: Already optimal." "Lime"
            } else {
                Log "  [ACTION]   Updating SQL Server Configuration silently..." "Cyan"
                $Script:form.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background)
                $updateQuery = "EXEC sys.sp_configure N'show advanced options', N'1'; RECONFIGURE WITH OVERRIDE; EXEC sys.sp_configure N'min server memory (MB)', $MinMemoryMB; EXEC sys.sp_configure N'max server memory (MB)', $NewMaxInt; RECONFIGURE WITH OVERRIDE; DBCC FREEPROCCACHE; DBCC DROPCLEANBUFFERS;"
                $cmd.CommandText = $updateQuery
                $cmd.ExecuteNonQuery() | Out-Null
                Log "  ✔ SUCCESS: Memory seamlessly clamped to 75% ($NewMaxInt MB)." "Lime"
            }
            try { $Cmd.CommandText = "EXEC sp_configure 'show advanced options', 0; RECONFIGURE WITH OVERRIDE;"; $Cmd.ExecuteNonQuery() | Out-Null } catch { }
            $CN.Close()
        }
    } catch { Log "❌ Memory Task Failed: $($_.Exception.Message)" "Red" }
})

$Script:btnBackup.Add_Click({ 
    try { 
        $s=Get-SelectedKeys; if($s.Count -eq 0){ Show-CustomAlert "Selection Required" "Select Database(s) to Backup Params!"; return }; 
        $FirstDB = $Script:TargetMap[$s[0]].DB; $availableJuris = Get-DBJurisIDs -DBName $FirstDB; $inputJuris = Show-JurisSelector -T "Source JurisID" -P "Select or Enter JurisID for Backup (DB: $FirstDB):" -Options $availableJuris; if ([string]::IsNullOrWhiteSpace($inputJuris) -or -not ($inputJuris -match '^\d+$')) { return }; 
        $fbd = New-Object System.Windows.Forms.FolderBrowserDialog; $fbd.SelectedPath = $Script:DefaultBackup; if($fbd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){ return }; 
        Toggle $false; $Script:form.FindResource("CloseDrawer").Begin(); 
        Run-Async $Script:btnBackup { 
            Log "▶ BACKING UP JURIS $inputJuris..."; $TS=Get-Date -Format "yyyyMMdd_HHmm"; 
            foreach ($item in $s) { 
                $DB = $Script:TargetMap[$item].DB; Log "  > Config for $DB..."; $BackupLines = @("# ProPhoenix Database Configuration Backup", "# Database: $DB", "# Timestamp: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')", ""); 
                $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS $DB 15)); $CN.Open(); $cmd = $CN.CreateCommand(); $cmd.CommandText = "SET NOCOUNT ON; SELECT ParamID, CAST(ParamValue AS NVARCHAR(MAX)) AS ParamValue FROM Parameter WHERE ParamID IN ($($Script:TargetParams -join ',')) AND JurisID=$inputJuris"; $reader = $cmd.ExecuteReader(); $BackupLines += "[PARAMETERS]"; $paramCount = 0; 
                while ($reader.Read()) { $v1 = $reader.GetValue(1); $pVal = if ($v1 -is [System.DBNull] -or $null -eq $v1) { "" } else { $v1.ToString() }; $BackupLines += "$($reader.GetValue(0))=$pVal"; $paramCount++ }; $reader.Close(); Log "   + $paramCount Params Exported" "Lime"; $BackupLines += ""; 
                $cmd.CommandText = "SELECT JobID, JobName, JobType FROM KPIjobs WHERE JobName IN ('$($Script:TargetJobs -join "','")')"; $jobReader = $cmd.ExecuteReader(); $tempJobs = @(); 
                while ($jobReader.Read()) { $v1 = $jobReader.GetValue(1); $jName = if ($v1 -is [System.DBNull]) { "Unknown" } else { $v1.ToString() }; $v2 = $jobReader.GetValue(2); $jType = if ($v2 -is [System.DBNull]) { "" } else { $v2.ToString() }; $tempJobs += @{ ID = $jobReader.GetValue(0); Name = $jName; Type = $jType } }; $jobReader.Close(); 
                foreach ($job in $tempJobs) { $BackupLines += "[JOB:$($job.Name)]"; if ($job.Type -ne "") { $BackupLines += "JobType=$($job.Type)" }; $cmd.CommandText = "SELECT ParamName, ParamValue FROM KPIjobsparam WHERE JobID = $($job.ID)"; $pReader = $cmd.ExecuteReader(); 
                while ($pReader.Read()) { $v0 = $pReader.GetValue(0); $jpName = if ($v0 -is [System.DBNull]) { "" } else { $v0.ToString() }; $v1 = $pReader.GetValue(1); $jpVal = if ($v1 -is [System.DBNull]) { "" } else { $v1.ToString() }; $BackupLines += "Param:$jpName=$jpVal" }; $pReader.Close(); $cmd.CommandText = "SELECT * FROM KPIJobsNotify WHERE JobID = $($job.ID)"; $nReader = $cmd.ExecuteReader(); 
                while ($nReader.Read()) { $v4 = $nReader.GetValue(4); if ($v4 -isnot [System.DBNull] -and $null -ne $v4) { $BackupLines += "NotifyPath=$($v4.ToString())" } }; $nReader.Close(); $BackupLines += "" }; 
                Log "   + $($tempJobs.Count) KPI Jobs Exported" "Lime"; [IO.File]::WriteAllLines((Join-Path $fbd.SelectedPath "$($DB)_ConfigBackup_$TS.txt"), $BackupLines, [System.Text.Encoding]::UTF8); $CN.Close() 
            }; Log "✔ Full Backup Complete." "Cyan" 
        } 
    } catch {} 
})

$Script:btnRestore.Add_Click({ 
    try { 
        $s=Get-SelectedKeys; if($s.Count -eq 0){ Show-CustomAlert "Selection Required" "Select Database(s) to Restore Params into!"; return }; 
        $FirstDB = $Script:TargetMap[$s[0]].DB; $availableJuris = Get-DBJurisIDs -DBName $FirstDB; $inputJuris = Show-JurisSelector -T "Target JurisID" -P "Select or Enter Target JurisID (DB: $FirstDB):" -Options $availableJuris; if ([string]::IsNullOrWhiteSpace($inputJuris) -or -not ($inputJuris -match '^\d+$')) { return }; 
        $f=New-Object System.Windows.Forms.OpenFileDialog; $f.Filter="Text Backup (*.txt)|*.txt"; $f.InitialDirectory=$Script:DefaultBackup; if($f.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){return}; $SourceFile=$f.FileName; 
        if([System.Windows.Forms.MessageBox]::Show("RESTORE to Juris $inputJuris?", "Confirm", 4, 48) -ne 6){ return }; 
        Toggle $false; $Script:form.FindResource("CloseDrawer").Begin(); 
        Run-Async $Script:btnRestore { 
            Log "▶ RESTORING TO JURIS $inputJuris..." "Orange"; foreach ($item in $s) { $DB=$Script:TargetMap[$item].DB; Log "  > Target: $DB"; Apply-EnterpriseConfig -TargetDB $DB -SourceFile $SourceFile -TargetJuris $inputJuris }; Log "✔ Complete." "Cyan" 
        } 
    } catch {} 
})

$Script:btnCopyDB.Add_Click({ 
    try { 
        $s=Get-SelectedKeys; if($s.Count -ne 1){ Show-CustomAlert "Selection Limit" "Select exactly ONE source database to copy."; return }
        $SourceDB = $Script:TargetMap[$s[0]].DB; $TypeSel = Show-CopyDialog; if($null -eq $TypeSel){ return }
        
        $Tag = if($TypeSel -match "Train"){"Tr"}else{"Test"}
        # Ensure it correctly defaults to _Tr or _Test at the end of the input box
        $DefName = if($SourceDB -match "^Phoenix") { $SourceDB.Replace("Phoenix", "Phoenix$Tag") } else { "$($SourceDB)_$Tag" }
        if (-not $DefName) { $DefName = "${SourceDB}_$Tag" }
        
        $TargetDB = Show-InputBox "Target Name" "Confirm Target Database Name:" $DefName; if ([string]::IsNullOrWhiteSpace($TargetDB)) { return }
        
        $CN=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 30)); $CN.Open(); $Cmd=$CN.CreateCommand(); $Cmd.CommandTimeout = 0; $Cmd.CommandText = "SELECT ISNULL(DB_ID('$TargetDB'), 0)"; $targetId = $Cmd.ExecuteScalar()
        if ([int]$targetId -gt 0) { if ([System.Windows.Forms.MessageBox]::Show("[$TargetDB] exists.`n`nBackup existing Params/Jobs?", "Backup", 4, 32) -eq 6) { $availableJuris = Get-DBJurisIDs -DBName $TargetDB; $selJ = Show-JurisSelector "Source JurisID" "JurisID to backup:" $availableJuris; if (![string]::IsNullOrWhiteSpace($selJ)) { $fbdBkp = New-Object System.Windows.Forms.FolderBrowserDialog; $fbdBkp.SelectedPath = $Script:DefaultBackup; if($fbdBkp.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){ Log "▶ BACKING UP [$TargetDB]..."; $TS=Get-Date -Format "yyyyMMdd_HHmm"; $BackupLines = @("# Database: $TargetDB (PRE-OVERWRITE)", ""); $CNTarget=New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS $TargetDB 15)); $CNTarget.Open(); $cmdTarget = $CNTarget.CreateCommand(); $cmdTarget.CommandText = "SET NOCOUNT ON; SELECT ParamID, CAST(ParamValue AS NVARCHAR(MAX)) FROM Parameter WHERE ParamID IN ($($Script:TargetParams -join ',')) AND JurisID=$selJ"; $reader = $cmdTarget.ExecuteReader(); $BackupLines += "[PARAMETERS]"; while ($reader.Read()) { $v1 = $reader.GetValue(1); $pVal = if ($v1 -is [System.DBNull] -or $null -eq $v1) { "" } else { $v1.ToString() }; $BackupLines += "$($reader.GetValue(0))=$pVal" }; $reader.Close(); Log "   + Exported Params" "Lime"; $BackupLines += ""; $cmdTarget.CommandText = "SELECT JobID, JobName, JobType FROM KPIjobs WHERE JobName IN ('$($Script:TargetJobs -join "','")')" ; $jobReader = $cmdTarget.ExecuteReader(); $tempJobs = @(); while ($jobReader.Read()) { $v1 = $jobReader.GetValue(1); $v2 = $jobReader.GetValue(2); $tempJobs += @{ ID = $jobReader.GetValue(0); Name = if ($v1 -is [System.DBNull]) { "Unknown" } else { $v1.ToString() }; Type = if ($v2 -is [System.DBNull]) { "" } else { $v2.ToString() } } }; $jobReader.Close(); foreach ($job in $tempJobs) { $BackupLines += "[JOB:$($job.Name)]"; if ($job.Type -ne "") { $BackupLines += "JobType=$($job.Type)" }; $cmdTarget.CommandText = "SELECT ParamName, ParamValue FROM KPIjobsparam WHERE JobID = $($job.ID)"; $pReader = $cmdTarget.ExecuteReader(); while ($pReader.Read()) { $v0 = $pReader.GetValue(0); $v1 = $pReader.GetValue(1); $jpName = if ($v0 -is [System.DBNull]) { "" } else { $v0.ToString() }; $jpVal = if ($v1 -is [System.DBNull]) { "" } else { $v1.ToString() }; $BackupLines += "Param:$jpName=$jpVal" }; $pReader.Close(); $cmdTarget.CommandText = "SELECT * FROM KPIJobsNotify WHERE JobID = $($job.ID)"; $nReader = $cmdTarget.ExecuteReader(); while ($nReader.Read()) { $v4 = $nReader.GetValue(4); if ($v4 -isnot [System.DBNull] -and $null -ne $v4) { $BackupLines += "NotifyPath=$($v4.ToString())" } }; $nReader.Close(); $BackupLines += "" }; [IO.File]::WriteAllLines((Join-Path $fbdBkp.SelectedPath "$($TargetDB)_PreCopyBackup_$TS.txt"), $BackupLines, [System.Text.Encoding]::UTF8); $CNTarget.Close() } } }; if ([System.Windows.Forms.MessageBox]::Show("DROP and REPLACE [$TargetDB]?", "Warning", 4, 16) -ne 6) { $CN.Close(); return } }
        
        $ansRest = [System.Windows.Forms.MessageBox]::Show("Apply config backup (.txt) after copy?", "Apply Config?", 4, 32); $ConfigFilePath = $null; $TargetJurisID = "1000"; if ($ansRest -eq 6) { $f = New-Object System.Windows.Forms.OpenFileDialog; $f.Filter = "Text Backup|*.txt"; $f.InitialDirectory = $Script:DefaultBackup; if ($f.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $ConfigFilePath = $f.FileName; $TargetJurisID = Show-InputBox "Target JurisID" "Enter JurisID:" "1000"; if ([string]::IsNullOrWhiteSpace($TargetJurisID)) { $CN.Close(); return } } }
        $Cmd.CommandText="SELECT ISNULL(CAST(SUM(size)*8/1024 AS VARCHAR), 'Unknown') FROM sys.master_files WHERE database_id=DB_ID('$SourceDB')"; $SizeMB = $Cmd.ExecuteScalar().ToString(); if([System.Windows.Forms.MessageBox]::Show("Proceed? ($SizeMB MB)", "Confirm", 4, 32) -ne 6){ $CN.Close(); return }
        $fbdSource = New-Object System.Windows.Forms.FolderBrowserDialog; $fbdSource.SelectedPath = $Script:DefaultBackup; if($fbdSource.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){ $CN.Close(); return }
        $BakFile = Join-Path $fbdSource.SelectedPath "$SourceDB`_Copy.bak"
        
        Toggle $false; $Script:form.FindResource("CloseDrawer").Begin()
        Run-Async $Script:btnCopyDB {
            $CN.FireInfoMessageEventOnUserErrors = $true; $CN.add_InfoMessage({ param($sender, $e) if ($e.Message -match "percent") { Log "   > $($e.Message)" "DarkGray" } })
            Log "▶ COPYING: $SourceDB -> $TargetDB..." "Cyan"; Log "  > Backing up Source..."; $Script:form.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background); $Cmd.CommandText="BACKUP DATABASE [$SourceDB] TO DISK='$BakFile' WITH COPY_ONLY, INIT, FORMAT, COMPRESSION, STATS=10"; $Cmd.ExecuteNonQuery()|Out-Null; Log "  > Overwriting Target..."; $Script:form.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background); try { $CmdKill = New-Object System.Data.SqlClient.SqlCommand("IF EXISTS(SELECT 1 FROM sys.databases WHERE name='$TargetDB') BEGIN ALTER DATABASE [$TargetDB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; END", $CN); $CmdKill.ExecuteNonQuery()|Out-Null } catch { }; $Cmd.CommandText="RESTORE FILELISTONLY FROM DISK='$BakFile'"; $Rdr=$Cmd.ExecuteReader(); $Files=@(); while($Rdr.Read()){$Files+=@{L=$Rdr["LogicalName"];P=$Rdr["PhysicalName"];T=$Rdr["Type"]}}; $Rdr.Close(); $MoveStr = ""; foreach($f in $Files){ $Ext=[System.IO.Path]::GetExtension($f.P); $Dir=[System.IO.Path]::GetDirectoryName($f.P); $NewName = "$TargetDB"; if ($f.T -eq "L") { $NewName += "_log" }; $NewName += $Ext; $MoveStr += "MOVE '$($f.L)' TO '$(Join-Path $Dir $NewName)', " }; $Cmd.CommandText="RESTORE DATABASE [$TargetDB] FROM DISK='$BakFile' WITH RECOVERY, REPLACE, STATS=10, $($MoveStr.TrimEnd(', '))"; $Cmd.ExecuteNonQuery()|Out-Null; $Cmd.CommandText = "ALTER DATABASE [$TargetDB] SET MULTI_USER"; $Cmd.ExecuteNonQuery()|Out-Null; Log "  ✔ Overwrite Complete." "Lime"; if (![string]::IsNullOrEmpty($ConfigFilePath)) { Log "▶ APPLYING CONFIG..." "Yellow"; Apply-EnterpriseConfig -TargetDB $TargetDB -SourceFile $ConfigFilePath -TargetJuris $TargetJurisID }; $CN.Close(); $Script:form.Dispatcher.Invoke([Action]{Invoke-ConnectionEngine})
        }
    } catch { Log "❌ Failed: $($_.Exception.Message)" "Red" }
})

$Script:btnCreateDB.Add_Click({ 
    if(!$Script:DBSyncRoot){ Show-CustomAlert "Configuration Required" "Utility path not found."; return }
    $d=Show-NewDBDialog; if(!$d){return}
    Toggle $false
    Run-Async $Script:btnCreateDB {
        Log "▶ CREATING NEW DATABASE..." "Cyan"
        $Folder=$d.Cat; $TargetDir=Join-Path $Script:DBSyncRoot $Folder; if(!(Test-Path $TargetDir)){$Folder=$Folder.Replace(" ","");$TargetDir=Join-Path $Script:DBSyncRoot $Folder}
        [xml]$x=Get-Content $Script:XmlTarget; $x.PnxPakager.SourceServer.IPAddress=$Script:txtS.Text; $x.PnxPakager.SourceServer.DBName=$d.DB; $x.PnxPakager.SourceServer.UserName=$Script:txtU.Text; $x.PnxPakager.SourceServer.Password=$Script:txtP.Password; $x.PnxPakager.SourceServer.JurisID=$d.JID; $x.PnxPakager.SourceServer.State=$d.St; $x.PnxPakager.SourceServer.JurisName=$d.Nm; $x.PnxPakager.SourceServer.JurisAlias=$d.Al; $x.PnxPakager.SourceServer.SyncType="1"; $x.Save("$TargetDir\PnxAutoNewDBSyn.xml")
        
        $proc = Start-Process "$TargetDir\PnxDBSync.exe" -WorkingDirectory $TargetDir -Verb RunAs -PassThru
        while (-not $proc.HasExited) {
            $Script:form.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background)
            Start-Sleep -Milliseconds 250
        }
        
        Log "  ✔ Created" "Lime"
        $Script:form.Dispatcher.Invoke([Action]{Invoke-ConnectionEngine})
    }
})

$Script:btnOverrideCat.Add_Click({
    try {
        $s = Get-SelectedKeys
        if ($s.Count -eq 0) { Show-CustomAlert "Selection Required" "Select at least one database to override category."; return }
        
        $Cats = @("Police", "Fire", "Phoenix Master", "IA", "Police DW", "Police CSP", "Fire CSP")
        $newCat = Show-JurisSelector -T "Override Category" -P "Select utility folder for selected DB(s):" -Options $Cats
        if ([string]::IsNullOrWhiteSpace($newCat)) { return }
        
        Toggle $false
        $Script:form.FindResource("CloseDrawer").Begin()
        Run-Async $Script:btnOverrideCat {
            Log "▶ OVERRIDING CATEGORY FOR $($s.Count) DATABASE(S)..." "Cyan"
            foreach ($k in $s) {
                $OldItem = $Script:TargetMap[$k]
                $DBName = $OldItem.DB
                
                $EnvPrefix = if ($k -match "^\[(.*?) -") { $Matches[1] } else { "LIVE" }
                $VerSuffix = if ($k -match "( - Ver:.*)") { $Matches[1] } else { "" }
                $NewKey = "[$EnvPrefix - $newCat] $DBName$VerSuffix"
                
                $Script:TargetMap.Remove($k)
                $Script:TargetMap[$NewKey] = @{ DB=$DBName; Folder=$newCat }
                
                $Script:form.Dispatcher.Invoke([Action]{
                    for ($i = 0; $i -lt $Script:listDBs.Items.Count; $i++) {
                        if ($Script:listDBs.Items[$i].Key -eq $k) {
                            $oldObj = $Script:listDBs.Items[$i]
                            $newObj = [PSCustomObject]@{ Key = $NewKey; DBName = $oldObj.DBName; Type = $newCat; IsChecked = $oldObj.IsChecked }
                            $Script:listDBs.Items[$i] = $newObj
                            break
                        }
                    }
                })
                Log "  ✔ $DBName ➔ Mapped to '$newCat'" "Lime"
            }
            $Script:form.Dispatcher.Invoke([Action]{ $Script:listDBs.Items.Refresh() })
        }
    } catch { Log "❌ Error: $($_.Exception.Message)" "Red" }
})

$Script:btnInstall.Add_Click({ Invoke-AppMgr "INSTALL" })
$Script:btnUninstall.Add_Click({ Invoke-AppMgr "UNINSTALL" })

function Invoke-ConnectionEngine {
    if ([string]::IsNullOrWhiteSpace($Script:txtP.Password)) {
        $pw = Show-InputBox "Authentication Required" "Enter SQL Password for '$($Script:txtU.Text)':" ""
        if ([string]::IsNullOrWhiteSpace($pw)) { Log "❌ Connection aborted: Password required." "Red"; return }
        $Script:txtP.Password = $pw
    }

    $Script:form.Dispatcher.Invoke([Action]{
        $Script:btnCon.IsEnabled = $false
        $Script:SpinnerIcon.Visibility = "Visible"
        $Script:btnConText.Text = "CONNECTING..."
        $Script:listDBs.Items.Clear()
    }, [System.Windows.Threading.DispatcherPriority]::Render)
    
    Log "▶ INITIALIZING CONNECTION..." "Cyan"
    
    try {
        $cn = New-Object System.Data.SqlClient.SqlConnection((Get-SqlCS "master" 5))
        
        try {
            $cn.Open()
        } catch {
            if ($_.Exception.Message -match "Login failed") {
                Log "❌ Authentication Failed: Login failed for user '$($Script:txtU.Text)'." "Red"
                if (Test-Path $Script:CredFile) { Remove-Item $Script:CredFile -Force -ErrorAction SilentlyContinue }
                $Script:form.Dispatcher.Invoke([Action]{ $Script:txtP.Password = "" })
            } else {
                Log "❌ SQL Error: $($_.Exception.Message)" "Red"
            }
            throw "Connection aborted."
        }

        $da = New-Object System.Data.SqlClient.SqlDataAdapter("SELECT Name FROM sys.databases WHERE database_id>4 AND Name NOT IN ('master','model','msdb','tempdb','ReportServer') ORDER BY Name", $cn)
        $ds = New-Object System.Data.DataSet; $da.Fill($ds)|Out-Null; $cn.Close()
        Log "  ✔ SQL Connected Successfully." "Lime"
        $Script:form.Dispatcher.Invoke([Action]{ $Script:lblStat.Text = "Connected to $($Script:txtS.Text)" })
        Save-Creds
        
        $Script:form.Dispatcher.Invoke([Action]{
            $EnvMode = $Script:cmbEnv.Text
            foreach ($row in $ds.Tables[0].Rows) {
                $db = $row.Name; $Folder = $null; $Type = "Other"
                
                $IsTrain = ($db -match "Tr" -or $db -match "Train"); $IsTest = ($db -match "Test" -and -not $IsTrain); $IsMaster = ($db -match "Master")
                if ($EnvMode -eq "LIVE") { if ($IsTest) { continue } } elseif ($EnvMode -eq "TEST") { if (-not $IsTest -and -not $IsMaster) { continue } }
                
                $Folder = Get-ProPhoenixDBTargetFolder -DbName $db
                $Type = $Folder
                if ($Type -eq "None") { $Type = "Other" }

                $Cat = if ($IsTest) { "TEST" } elseif ($IsTrain) { "LIVE" } else { "LIVE" }
                if ($Script:DBSyncRoot -and (-not $Script:IsRemote) -and $Folder -ne "None") { $P1 = Join-Path $Script:DBSyncRoot $Folder; if (!(Test-Path $P1)) { $Folder = $Folder.Replace(" ", "") } }
                
                $Key = "[$Cat - $Type] $db"
                Add-DBToList $db $Key $Type
                $Script:TargetMap[$Key] = @{ DB=$db; Folder=$Folder }
            }
        })
        Scan-Server $Script:txtS.Text
        
        $Script:form.Dispatcher.Invoke([Action]{
            if ($Script:chkAutoSync.IsChecked -eq $true) {
                $s = Get-SelectedKeys
                if ($s.Count -gt 0) {
                    Log "▶ AUTO-UPDATE PIPELINE: MAIN UTILITY" "Yellow"
                    Execute-DBSync $s
                } else {
                    Log "   ! Auto Sync Skipped: No databases selected." "Orange"
                }
            }
        })
    } catch { } 
    finally { 
        $Script:form.Dispatcher.Invoke([Action]{
            $Script:SpinnerIcon.Visibility = "Collapsed"
            $Script:btnConText.Text = "CONNECT"
            $Script:btnCon.IsEnabled = $true
        })
    }
}

$Script:btnCon.Add_Click({ Invoke-ConnectionEngine })
$Script:btnRefresh.Add_Click({ Invoke-ConnectionEngine })

$Script:form.Add_Loaded({ Load-Creds })
$Script:form.ShowDialog() | Out-Null