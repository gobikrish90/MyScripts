﻿<#
.SYNOPSIS
    ProPhoenix Full Maintenance Generator (MASTER VERSION - FORMAT FIXED).
    - FIXED: PowerShell Here-String ("@) formatting corrected to prevent script collapse.
    - Session Recording: Auto-starts and captures frames; auto-stops on user exit.
    - Controlled Exit: Visible 'pause' used; clean 'exit /b' implementation.
    - Explicit Mappings: Ensures Police/Fire/IA/HelpDocs are included.
#>

$ErrorActionPreference = "Continue"

# --- 1. DEFINITIONS: HELPER SCRIPTS ---

# (A) Session Data Cleaner
$LogClearScriptContent = @"
Write-Host "========================================="
Write-Host "            SCRIPT STARTED               "
Write-Host "========================================="
`$proPhoenixBasePaths = Get-PSDrive -PSProvider FileSystem | ForEach-Object {
    "`$(`$_.Root)\Program Files\ProPhoenix"
} | Where-Object { Test-Path -Path `$_ }

Write-Host "`n[INFO] Searching for '_Instances' folders..."

# CLEAR SVR SESSION DATA
Write-Host "`n========================================="
Write-Host "      CLEARING SERVER SESSION DATA       "
Write-Host "========================================="
foreach (`$basePath in `$proPhoenixBasePaths) {
    `$cadServerPath = Join-Path -Path `$basePath -ChildPath "CAD Server\_Instances"
    if (Test-Path `$cadServerPath) {
        `$cadInstances = Get-ChildItem -Path `$cadServerPath -Directory
        foreach (`$inst in `$cadInstances) {
            `$sessionDataPath = Join-Path -Path `$inst.FullName -ChildPath "SvrSessionData"
            if (Test-Path `$sessionDataPath) {
                Write-Host "[INFO] Cleaning Session Data: `$sessionDataPath"
                `$filesDeleted = 0
                Get-ChildItem -Path `$sessionDataPath -File | ForEach-Object { 
                    Remove-Item -Path `$_.FullName -Force 
                    `$filesDeleted++
                }
                if (`$filesDeleted -gt 0) { Write-Host "  [SUCCESS] Removed `$filesDeleted session files." }
            }
        }
    }
}
Write-Host "`n========================================="
Write-Host "            SCRIPT COMPLETED             "
Write-Host "========================================="
"@

# (B) Instance Verification Script
$VerificationScriptContent = @"
param([string]`$LogPath)

function Log-Msg {
    param([string]`$Msg, [string]`$Color="White")
    Write-Host `$Msg -ForegroundColor `$Color
    if (`$LogPath -and (Test-Path (Split-Path `$LogPath))) {
        Add-Content -Path `$LogPath -Value `$Msg
    }
}

Log-Msg "[INFO] Starting DLL verification..." "Cyan"

`$prophoenixPaths = Get-PSDrive -PSProvider FileSystem | ForEach-Object {
    `$driveRoot = "`$(`$_.Root)Program Files\ProPhoenix"
    if (Test-Path `$driveRoot) { `$driveRoot }
}

if (-not `$prophoenixPaths) {
    Log-Msg "[ERROR] No ProPhoenix installation found." "Red"
    exit
}

`$excludedFolders = @("PhoenixHub", "Phoenix Gateway", "Payment Gateway", "FTP")
`$completedCount = 0; `$notCompletedCount = 0; `$totalChecked = 0

foreach (`$basePath in `$prophoenixPaths) {
    Log-Msg "`n[INFO] Scanning applications in: `$basePath" "Yellow"

    `$appFolders = Get-ChildItem -Path `$basePath -Directory -ErrorAction SilentlyContinue | 
                  Where-Object { `$excludedFolders -notcontains `$_.Name -and `$_.Name -notmatch "Hub|Gateway" }

    foreach (`$app in `$appFolders) {
        `$instancesPath = Join-Path `$app.FullName "_Instances"
        `$baseDlls = Get-ChildItem -Path `$app.FullName -Filter *.dll -File -ErrorAction SilentlyContinue

        if (Test-Path `$instancesPath) {
            `$instanceEnvs = Get-ChildItem -Path `$instancesPath -Directory -ErrorAction SilentlyContinue
            foreach (`$env in `$instanceEnvs) {
                `$instanceDlls = Get-ChildItem -Path `$env.FullName -Filter *.dll -File -ErrorAction SilentlyContinue
                `$status = "Completed"
                foreach (`$dll in `$baseDlls) {
                    `$match = `$instanceDlls | Where-Object { `$_.Name -eq `$dll.Name }
                    if (`$match) {
                        if ((`$match.LastWriteTime -lt `$dll.LastWriteTime) -or (`$match.Length -ne `$dll.Length)) {
                            `$status = "Not Completed"; break
                        }
                    } else { `$status = "Not Completed"; break }
                }
                `$totalChecked++
                if (`$status -eq "Completed") { `$completedCount++; Log-Msg ("[OK] " + `$app.Name + " -> " + `$env.Name + " : Completed") "Green" } 
                else { `$notCompletedCount++; Log-Msg ("[WARN] " + `$app.Name + " -> " + `$env.Name + " : Not Completed") "Red" }
            }
        } elseif (`$baseDlls.Count -gt 0) {
            `$totalChecked++; `$completedCount++; Log-Msg ("[OK] " + `$app.Name + " (Base) : Verified") "Green"
        }

        `$helpDocsPath = Join-Path `$app.FullName "UserDocs"
        if (Test-Path `$helpDocsPath) {
             `$hdFiles = Get-ChildItem -Path `$helpDocsPath -File -ErrorAction SilentlyContinue
             if (`$hdFiles.Count -gt 0) { `$totalChecked++; `$completedCount++; Log-Msg ("[OK] " + `$app.Name + " F1 Help Docs : Verified") "Green" }
        }
    }
}
Log-Msg "`n--------------------------------------" "White"
Log-Msg ("Total Verified : " + `$totalChecked) "White"
Log-Msg ("Completed      : " + `$completedCount) "Green"
Log-Msg ("Not Completed  : " + `$notCompletedCount) "Red"
Log-Msg "--------------------------------------" "White"
[Console]::ResetColor()
"@

# (C) Automated Session Recorder Script
$SessionRecorderScriptContent = @"
param([string]`$LogDir, [string]`$StatusFile)

`$ffmpegPath = "C:\pnxtemp\ffmpeg.exe"

# 1. Automatically download standalone FFmpeg if it doesn't exist
if (-not (Test-Path `$ffmpegPath)) {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri "https://github.com/eugeneware/ffmpeg-static/releases/download/b4.4/ffmpeg-windows-x64.exe" -OutFile `$ffmpegPath
    } catch {
        # Fallback logic if download fails
        exit
    }
}

# 2. Record the screen to an MKV video file
if (Test-Path `$ffmpegPath) {
    `$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    `$videoFile = Join-Path `$LogDir "SessionVideo_`$timestamp.mkv"
    `$proc = Start-Process -FilePath `$ffmpegPath -ArgumentList "-y -f gdigrab -framerate 10 -i desktop -c:v libx264 -preset ultrafast `"`$videoFile`"" -WindowStyle Hidden -PassThru
    while (Test-Path `$StatusFile) { Start-Sleep -Seconds 1 }
    Start-Sleep -Seconds 2
    Stop-Process -Id `$proc.Id -Force -ErrorAction SilentlyContinue
}
"@

# --- 2. CONFIGURATION ---
$ClientAppsDef = @{
    "CAD Client"     = "KPI.Phoenix.CADClient.exe"
    "WDA"            = "KPI.Phoenix.CADMobileClient.exe"
    "Phoenix WDA V2" = "Phoenix.WDAV2.Client.Shell.exe"
}

$ServiceProductList = @("JobServer", "TraCSServer", "VideoServer", "FingerPrintServer", "EmailWatcher", "CADServer", "CADNLBServer", "CAD2CADTellusServer", "E911Server", "ZetronServer", "ExternalInterface", "GPSServer", "NCICServer", "NCICStateServer", "FTPServer", "LocutionCADVoiceServer", "DeviceNotification", "StreamingNotification", "ReportService", "FolderWatcher", "DocsServer", "PhoenixTonerServer", "PhoenixAlertApp", "PhoenixTExt2Dispatch", "PHOENIXAIWATCHERSERVICE", "PHOENIXJOBSVRV2")

$ExplicitPathMap = @{
    "Police RMS" = "PoliceRMS"
    "Fire RMS" = "FireRMS"
    "Job Server" = "JobServer"
    "TraCS Server" = "TraCSServer"
    "Video Server" = "VideoServer"
    "Finger Print Server" = "FingerPrintServer"
    "Report Server" = "ReportServer"
    "Report Service" = "ReportService"
    "WebService" = "PhoenixWebService"
    "User Docs" = "HazmatGuide"
    "Fire WebService" = "FireWebService"
    "Provision Manager" = "ProvisionManager"
    "PnxFolderWatcher" = "FolderWatcher"
    "PhoenixIA" = "InternalAffair"
    "NIBRSInterface" = "NIBRS"
    "Phoenix Email Watcher" = "EmailWatcher"
    "Police RMS\UserDocs" = "PoliceF1HelpDocs"
    "Fire RMS\UserDocs" = "FireF1HelpDocs"
    "PhoenixIA\UserDocs" = "IAF1HelpDocs"
    "CAD Server" = "CADServer"
    "CAD NLB Message Server" = "CADNLBServer"
    "E911 Server" = "E911Server"
    "GPS Server" = "GPSServer"
    "CAD Zetron Server" = "ZetronServer"
    "Toner WI Server" = "TonerWIServer"
    "External Interface Server" = "ExternalInterface"
    "NCIC Server" = "NCICServer"
    "NCIC State Server" = "NCICStateServer"
    "KGIS PD WebService" = "KGISPDServer"
    "KGIS Central WebService" = "KGISCentralServer"
    "Locution CAD Voice Server" = "LocutionCADVoiceServer"
    "Phoenix Device Notification" = "DeviceNotification"
    "Device Notification Server" = "DeviceNotification"
    "WDA App webservice" = "PnxWDAAppWebService"
    "Fire Response CAD Webservice" = "PnxWDAAppWebService"
    "Streaming Notification" = "StreamingNotification"
    "Streaming Notification Server" = "StreamingNotification"
    "Alert App" = "PhoenixAlertApp"
    "Text2Dispatch" = "PhoenixTExt2Dispatch"
    "CADTxt2Dispatch" = "PhoenixTExt2Dispatch"
    "CADText2Dispatch" = "PhoenixTExt2Dispatch"
    "Txt2Dispatch" = "PhoenixTExt2Dispatch"
    "CAD2CAD Tellus Server" = "CAD2CADTellusServer"
    "Phoenix Report Writer API" = "ReportWriterAPI"
    "Citizen Services Link" = "CitizenServices"
    "Inmate Lookup" = "InmateLookup"
    "WIJIS" = "WIJIS"
    "SWISS" = "SWISS"
    "CJIN Integration Service" = "CJIN"
    "WIJIS NDEX WebService" = "NDEX"
    "FTP Server" = "FTPServer"
    "CRM" = "CRM"
    "Inmate Locator" = "InmateLocator"
    "FireCSPhoenixLink" = "FireCSPWCF"
    "CitizenServices" = "PoliceCSPWebAPI"
    "FireCitizenServices" = "FireCSPWebsite"
    "ADRCollectionRepositoryWS" = "ADRWebService"
    "WhatsNewWebService" = "WhatsNewWebService"
    "DocsServer" = "DocsServer"
    "Toner Server" = "PhoenixTonerServer"
    "Jail Cell Check App Service" = "JailCellCheck"
    "PhoenixScenePD" = "ScenePD"
    "PhoenixPDFService" = "PDFService"
    "Phoenix PDF Service" = "PDFService"
    "Database Utility" = "DBUtility"
    "FTP\CAD Client Stage" = "StageCADClient"
    "FTP\WDA Stage" = "StageWDA"
    "FTP\Print Server Stage" = "StagePrintClient"
    "FTP\Client Application Manager Stage" = "StageClientAppManager"
    "FTP\Finger Print Client Stage" = "StageFingerPrintClient"
    "FTP\ID Scanner Stage" = "StageIDScannerClient"
    "FTP\Station KIOSK RFID Client Stage" = "StageStationKIOSKRFIDClient"
    "FTP\RFID Client Stage" = "StageRFIDClient"
    "FTP\AVL Recorder Stage" = "StageAVLRecorder"
    "FTP\In Out Client Stage" = "StageInOutClient"
    "FTP\Zetron Client Stage" = "StageZetronClient"
    "FTP\Phoenix Dashboard Stage" = "StagePhoenixDashboard"
    "FTP\Mobile Inspection App Stage" = "StageMobileInspectionApp"
    "FTP\Phoenix WDA V2 Stage" = "StagePhoenixWDAV2"
    "Job Server V2" = "PHOENIXJOBSVRV2"
    "Phoenix AI Watcher" = "PHOENIXAIWATCHERSERVICE"
    "PNXDiagram" = "PNXDIAGRAM"
    "PNXDiagramAPI" = "PNXDIAGRAMAPI"
    "Phoenix Inspection API" = "INSPECTIONAPI"
    "Fire CSP Conversion" = "FIRECSPCONVERSION"
    "Phoenix Camera Server" = "CAMERASERVER"
    "Phoenix Pawn" = "PHOENIXPAWN"
    "CSPProcessQueueService" = "CSPProcessQueue"
    "CSP Conversion" = "CSPConversion"
    "PhoenixAIMugMatch" = "AIMugMatch"
    "Phoenix Employment Client" = "EmploymentClient"
    "Azure File Downloader" = "AzureFileDownloader"
    "CRM Database Utility" = "CRMDBUtility"
}

Clear-Host
Write-Host "==============================================" -ForegroundColor Yellow
Write-Host "   FULL MAINTENANCE INSTALL GENERATOR" -ForegroundColor Yellow
Write-Host "==============================================" -ForegroundColor Yellow

# --- 3. FIND INSTANCES ---
$FileName = "Appreg_main.xml"
$FoundFiles = @()
foreach ($d in (Get-PSDrive -PSProvider FileSystem)) {
    foreach ($folder in @("ProPhoenix\Server Application Manager", "Program Files\ProPhoenix\Server Application Manager", "Program Files (x86)\ProPhoenix\Server Application Manager")) {
        $full = Join-Path $d.Root $folder
        if (Test-Path (Join-Path $full $FileName)) { $FoundFiles += Join-Path $full $FileName }
    }
}

if ($FoundFiles.Count -eq 0) { Write-Error "No instances found."; Start-Sleep -Seconds 3; exit }

# --- 4. FIND CLIENT APPS ---
$ClientLaunchLogic = ""
foreach ($key in ($ClientAppsDef.Keys | Sort-Object)) {
    foreach ($d in (Get-PSDrive -PSProvider FileSystem)) {
        foreach ($root in @("ProPhoenix", "Program Files\ProPhoenix", "Program Files (x86)\ProPhoenix")) {
            $TryPath = Join-Path $d.Root $root | Join-Path -ChildPath $key | Join-Path -ChildPath $ClientAppsDef[$key]
            if (Test-Path $TryPath) {
                $PSCommand = "`$path = '$TryPath'; `$desktop = [Environment]::GetFolderPath('Desktop'); `$public = [Environment]::GetFolderPath('CommonDesktopDirectory'); `$shell = New-Object -ComObject WScript.Shell; `$shortcut = Get-ChildItem -Path `$desktop, `$public -Filter '*.lnk' | Where-Object { `$shell.CreateShortcut(`$_.FullName).TargetPath -eq `$path } | Select-Object -First 1; if (`$shortcut) { Start-Process `$shortcut.FullName -Verb RunAs; } else { Start-Process `$path -Verb RunAs; }"
                $PSCommandFlat = $PSCommand -replace "`r`n", " " -replace "\s+", " "
                $ClientLaunchLogic += "%PSExe% -WindowStyle Hidden -Command `"$PSCommandFlat`"`r`n"
                break
            }
        }
    }
}

# --- 5. PROCESS LOOP ---
foreach ($FoundPath in $FoundFiles) {
    $AppMgrFolder = Split-Path $FoundPath -Parent
    $LogDir = Join-Path $AppMgrFolder "PnxLog\PrintLog"
    $PnxTempPath = Join-Path (Split-Path $AppMgrFolder -Parent) "PnxTemp"
    New-Item $PnxTempPath -Type Directory -Force | Out-Null
    
    # Write Helper Scripts
    Set-Content (Join-Path $PnxTempPath "LogClear.ps1") $LogClearScriptContent -Encoding ASCII
    Set-Content (Join-Path $PnxTempPath "InstanceVerification.ps1") $VerificationScriptContent -Encoding ASCII    
    Set-Content (Join-Path $PnxTempPath "SessionRecorder.ps1") $SessionRecorderScriptContent -Encoding ASCII
    
    # Parse Mappings 
    $InstallArgs = new-object System.Collections.Generic.List[string]
    $UpdateArgs  = new-object System.Collections.Generic.List[string]
    $InstallArgs.Add('"INSTALL"')
    $UpdateArgs.Add('"UPDATEINSTANCE"')
    
    [xml]$xmlData = Get-Content $FoundPath
    foreach ($app in $xmlData.PhoenixApplications.AppReg) {
        $Ver = $app.CurrentVersion
        $FPath = $app.AppPath.Replace("/", "\").Trim()
        
        if ($app.AppName -match "Hub|Gateway" -or $FPath -match "Hub|Gateway") { continue }

        if ($Ver -ne "0.0.0.0") {
            $BestID = $null; $BestLen = 0
            foreach ($k in $ExplicitPathMap.Keys) {
                if ($FPath.EndsWith($k, [System.StringComparison]::OrdinalIgnoreCase)) {
                    if ($k.Length -gt $BestLen) { $BestID = $ExplicitPathMap[$k]; $BestLen = $k.Length }
                }
            }
            if ($BestID) {
                $InstallArgs.Add("`"$BestID`"")
                if ($ServiceProductList -contains $BestID) { $UpdateArgs.Add("`"$BestID`"") }
            }
        }
    }

    # Generate PRIMARY Batch File
    $InstallLine = $InstallArgs -join " "
    $UpdateLine  = $UpdateArgs -join " "
    $OutputBatFile = Join-Path $PnxTempPath "Hotfix_Automation.bat"
    
    $InstallDrive = Split-Path $FoundPath -Qualifier
    $PathParts = $AppMgrFolder.Split('\')
    $CdBlock = "$InstallDrive`r`ncd ..\..\..\..\`r`n"
    for ($i = 1; $i -lt $PathParts.Count; $i++) { if ($PathParts[$i]) { $CdBlock += "cd `"$($PathParts[$i])`"`r`n" } }

    $UpdateCmd = ""
    if ($UpdateArgs.Count -gt 1) {
        $UpdateCmd = "`"%AppMgrExePath%\PnxAppMgr.exe`" $UpdateLine | %PSExe% -Command `"`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }`" 2>&1"
    }

    # IMPORTANT: Do not indent the closing "@ on the BatchContent variables.
    $BatchContent = @"
$CdBlock
@echo off
SET "AppMgrExePath=$AppMgrFolder"
SET "PSExe=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

:: --- LOGGING & RECORDING SETUP ---
SET "LOGDIR=$LogDir"
SET "LOGFILE=%LOGDIR%\Install_Log.txt"
SET "STATUSFILE=%LOGDIR%\record_status.txt"

echo RUNNING > "%STATUSFILE%"
start /B "" "%PSExe%" -ExecutionPolicy Bypass -WindowStyle Hidden -Command "& '%~dp0SessionRecorder.ps1' -LogDir '%LOGDIR%' -StatusFile '%STATUSFILE%'"

echo Logging Execution to: %LOGFILE%
echo --- Installation Started --- > "%LOGFILE%"

echo ===================================================
echo   STEP 0: UPDATING APPLICATION MANAGER
echo ===================================================
"%AppMgrExePath%\PnxAppMgr.exe" "UPDAPPMANAGER" | %PSExe% -Command "`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }" 2>&1

echo ===================================================
echo   STEP 1: STOPPING SERVICES AND PROCESSES
echo ===================================================
"%windir%\System32\iisreset.exe" /stop | %PSExe% -Command "`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }" 2>&1
taskkill /F /IM "KPI.Phoenix.CADClient.exe" /T 2>nul >> "%LOGFILE%" 2>&1
taskkill /F /IM "Phoenix.WDAV2.Client.Shell.exe" /T 2>nul >> "%LOGFILE%" 2>&1
%PSExe% -Command "Get-Service -Name 'Phoenix*' | Stop-Service -Force" >> "%LOGFILE%" 2>&1

echo ===================================================
echo   STEP 2: CLEANING LOGS AND SESSION DATA
echo ===================================================
%PSExe% -ExecutionPolicy Bypass -File "%~dp0LogClear.ps1" | %PSExe% -Command "`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }" 2>&1

echo ===================================================
echo   STEP 3: INSTALLATION
echo ===================================================
:loopSelf
%windir%\System32\tasklist.exe /fi "imagename eq PnxAppMgr.exe" |find ":" > nul
if "%ERRORLEVEL%"=="1" goto loopSelf

"%AppMgrExePath%\PnxAppMgr.exe" $InstallLine | %PSExe% -Command "`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }" 2>&1

echo ===================================================
echo   STEP 4: STARTING IIS AND UPDATING INSTANCES
echo ===================================================
"%windir%\System32\iisreset.exe" /start | %PSExe% -Command "`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }" 2>&1
$UpdateCmd

"%AppMgrExePath%\PnxAppMgr.exe" "SHOWINSTANCES" | %PSExe% -Command "`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }" 2>&1

echo ===================================================
echo   UNBLOCKING PROPHOENIX FILES
echo ===================================================
%PSExe% -Command "Get-ChildItem -Path 'C:\Program Files\ProPhoenix' -Recurse -File | Unblock-File" >> "%LOGFILE%" 2>&1

echo ===================================================
echo   STEP 4.5: STARTING PHOENIX SERVICES
echo ===================================================
%PSExe% -Command "Get-Service -Name 'Phoenix*' | Start-Service" >> "%LOGFILE%" 2>&1

echo ===================================================
echo   STEP 4.6: VERIFYING INSTANCE UPDATES
echo ===================================================
%PSExe% -ExecutionPolicy Bypass -Command "& '%~dp0InstanceVerification.ps1' -LogPath '%LOGFILE_PATH%'"

echo ===================================================
echo   STEP 5: LAUNCHING CLIENT APPLICATIONS
echo ===================================================
$ClientLaunchLogic

echo.
echo ===================================================
echo   INSTALLATION COMPLETE.
echo   PRESS ANY KEY TO STOP RECORDING AND CLOSE...
echo ===================================================
pause
if exist "%STATUSFILE%" del "%STATUSFILE%"
exit /b
::End of Script::
"@

    Set-Content $OutputBatFile $BatchContent -Encoding ASCII

    # --- 6. GENERATE SECONDARY BATCH FILE (INSTANCE UPDATE ONLY) ---
    $SecondaryBatDir = "C:\pnxtemp\Phoenix Installation Master\Phoenix Installation Master"
    if (-not (Test-Path $SecondaryBatDir)) { New-Item -ItemType Directory -Path $SecondaryBatDir -Force | Out-Null }

    Set-Content (Join-Path $SecondaryBatDir "InstanceVerification.ps1") $VerificationScriptContent -Encoding ASCII
    Set-Content (Join-Path $SecondaryBatDir "SessionRecorder.ps1") $SessionRecorderScriptContent -Encoding ASCII

    $SecondaryBatFile = Join-Path $SecondaryBatDir "Instance Update(BS).bat"

    # IMPORTANT: Do not indent the closing "@
    $SecondaryBatchContent = @"
$CdBlock
@echo off
SET "AppMgrExePath=$AppMgrFolder"
SET "PSExe=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

:: --- LOGGING & RECORDING SETUP ---
SET "LOGDIR=$LogDir"
SET "LOGFILE=%LOGDIR%\Install_Log.txt"
SET "STATUSFILE=%LOGDIR%\record_status.txt"

echo RUNNING > "%STATUSFILE%"
start /B "" "%PSExe%" -ExecutionPolicy Bypass -WindowStyle Hidden -Command "& '%~dp0SessionRecorder.ps1' -LogDir '%LOGDIR%' -StatusFile '%STATUSFILE%'"

echo --- Instance Update Started --- > "%LOGFILE%"

echo ===================================================
echo   STEP 1: STOPPING PHOENIX SERVICES
echo ===================================================
%PSExe% -Command "Get-Service -Name 'Phoenix*' | Stop-Service -Force" >> "%LOGFILE%" 2>&1

echo ===================================================
echo   STEP 2: UPDATING INSTANCES
echo ===================================================
$UpdateCmd

"%AppMgrExePath%\PnxAppMgr.exe" "SHOWINSTANCES" | %PSExe% -Command "`$input | ForEach-Object { Write-Host `$_; `$_ | Out-File -FilePath '%LOGFILE%' -Append -Encoding ASCII }" 2>&1

echo ===================================================
echo   UNBLOCKING PROPHOENIX FILES
echo ===================================================
%PSExe% -Command "Get-ChildItem -Path 'C:\Program Files\ProPhoenix' -Recurse -File | Unblock-File" >> "%LOGFILE%" 2>&1

echo ===================================================
echo   STEP 3: STARTING PHOENIX SERVICES
echo ===================================================
%PSExe% -Command "Get-Service -Name 'Phoenix*' | Start-Service" >> "%LOGFILE%" 2>&1

echo ===================================================
echo   STEP 4: VERIFYING INSTANCE UPDATES
echo ===================================================
%PSExe% -ExecutionPolicy Bypass -Command "& '%~dp0InstanceVerification.ps1' -LogPath '%LOGFILE_PATH%'"

echo.
echo ===================================================
echo   INSTANCE UPDATE COMPLETE.
echo   PRESS ANY KEY TO STOP RECORDING AND CLOSE...
echo ===================================================
pause
if exist "%STATUSFILE%" del "%STATUSFILE%"
exit /b
::End of Script::
"@

    Set-Content $SecondaryBatFile $SecondaryBatchContent -Encoding ASCII
}

# --- TAKE FINAL SCREENSHOT OF PS WINDOW ---
Start-Sleep -Seconds 1
try {
    Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing
    $screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $bmp = New-Object System.Drawing.Bitmap $screen.Width, $screen.Height
    $graphics = [System.Drawing.Graphics]::FromImage($bmp); $graphics.CopyFromScreen($screen.Location, [System.Drawing.Point]::Empty, $screen.Size)
    $bmp.Save((Join-Path $LogDir "Screenshot_PS_Analysis_$(Get-Date -Format 'yyyyMMdd_HHmmss').png"), [System.Drawing.Imaging.ImageFormat]::Png)
    $graphics.Dispose(); $bmp.Dispose()
} catch {}

# --- AUTO LAUNCH PRIMARY BATCH ---
if ($OutputBatFile -and (Test-Path $OutputBatFile)) {
    Start-Process -FilePath $OutputBatFile
}