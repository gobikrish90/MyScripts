﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

# ==========================================
# 1. HELPER FUNCTIONS & STYLING
# ==========================================
function Set-RoundedCorner($Control, $Radius) {
    if ($Control.Width -le 0 -or $Control.Height -le 0) { return }
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc(0, 0, $Radius, $Radius, 180, 90)
    $path.AddArc($Control.Width - $Radius, 0, $Radius, $Radius, 270, 90)
    $path.AddArc($Control.Width - $Radius, $Control.Height - $Radius, $Radius, $Radius, 0, 90)
    $path.AddArc(0, $Control.Height - $Radius, $Radius, $Radius, 90, 90)
    $path.CloseFigure()
    $Control.Region = New-Object System.Drawing.Region($path)
}

function Add-GroupBorder($Panel, $Color) {
    $paintBlock = {
        param($sender, $e)
        $g = $e.Graphics
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        
        $pen = New-Object System.Drawing.Pen($Color, 2) 
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $r = 15
        
        $w = $sender.Width - 3
        $h = $sender.Height - 3
        
        $path.AddArc(1, 1, $r, $r, 180, 90)
        $path.AddArc($w - $r, 1, $r, $r, 270, 90)
        $path.AddArc($w - $r, $h - $r, $r, $r, 0, 90)
        $path.AddArc(1, $h - $r, $r, $r, 90, 90)
        $path.CloseFigure()
        
        $g.DrawPath($pen, $path)
        $pen.Dispose()
        $path.Dispose()
    }.GetNewClosure() 

    $Panel.add_Paint($paintBlock)
}

function Show-Badge($TargetButton, $Text = "!") {
    if ($global:logContainer.Visible -and $TargetButton.Text -eq "Execution Logs") { return }
    if ($global:pnlFlowLogTerm.Visible -and $TargetButton.Text -eq "Terminal Logs") { return }

    $existing = $TargetButton.Controls | Where-Object { $_.Name -eq "NotificationBadge" }
    if ($existing) {
        $existing.Text = $Text
        $existing.Visible = $true
        return
    }

    $badge = New-Object System.Windows.Forms.Label
    $badge.Name = "NotificationBadge"
    $badge.Text = $Text
    $badge.Size = New-Object System.Drawing.Size(22, 22)
    
    $xPos = $TargetButton.Width - 35
    $yPos = ($TargetButton.Height - 22) / 2
    $badge.Location = New-Object System.Drawing.Point($xPos, $yPos)
    
    $badge.BackColor = [System.Drawing.Color]::Red
    $badge.ForeColor = [System.Drawing.Color]::White
    $badge.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $badge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $badge.Enabled = $false 
    
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddEllipse(0, 0, $badge.Width, $badge.Height)
    $badge.Region = New-Object System.Drawing.Region($path)
    
    $TargetButton.Controls.Add($badge)
    $badge.BringToFront()
}

function Hide-Badge($TargetButton) {
    $badge = $TargetButton.Controls | Where-Object { $_.Name -eq "NotificationBadge" }
    if ($badge) { $badge.Visible = $false }
}

# ==========================================
# 2. LOGGING & GLOBAL VARIABLES
# ==========================================
$workingDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$global:LogDir = Join-Path -Path $workingDir -ChildPath "Pnxlogs"
if (-Not (Test-Path $global:LogDir)) { New-Item -ItemType Directory -Path $global:LogDir -Force | Out-Null }
$global:CurrentLogFile = Join-Path -Path $global:LogDir -ChildPath "Dashboard_Log_$(Get-Date -f 'yyyy-MM-dd').txt"

function Write-LogToFile($Message) {
    $logEntry = "[{0:yyyy-MM-dd HH:mm:ss}] $Message" -f (Get-Date)
    Add-Content -Path $global:CurrentLogFile -Value $logEntry -ErrorAction SilentlyContinue
}

Write-LogToFile "=== Dashboard Session Started ==="

# Dark Mode Palette
$colorSidebarBg  = [System.Drawing.Color]::FromArgb(255, 20, 20, 25)
$colorMainBg     = [System.Drawing.Color]::FromArgb(255, 28, 28, 35)
$colorCardBg     = [System.Drawing.Color]::FromArgb(255, 35, 35, 45)
$colorRowBg      = [System.Drawing.Color]::FromArgb(255, 40, 40, 50)
$colorRowGlass   = [System.Drawing.Color]::FromArgb(130, 40, 40, 50) 
$colorConsoleBg  = [System.Drawing.Color]::FromArgb(255, 13, 13, 13)
$colorTextWhite  = [System.Drawing.Color]::FromArgb(255, 240, 240, 240)
$colorTextMuted  = [System.Drawing.Color]::FromArgb(255, 160, 160, 160)
$colorAccentRed  = [System.Drawing.Color]::FromArgb(255, 239, 68, 68)
$colorTabActive  = [System.Drawing.Color]::FromArgb(255, 65, 65, 80)
$colorTabDeact   = [System.Drawing.Color]::FromArgb(255, 30, 30, 40)
$colorRefreshBtn = [System.Drawing.Color]::FromArgb(255, 30, 100, 120) 
$colorGroupBorder = [System.Drawing.Color]::FromArgb(255, 70, 75, 90)
$colorLblDash    = [System.Drawing.Color]::FromArgb(255, 230, 160, 60) 
$colorBtnBorder  = [System.Drawing.Color]::FromArgb(255, 60, 60, 75) 

# --- GROUP-SPECIFIC COLOR THEMES ---
$colorLblGen  = [System.Drawing.Color]::FromArgb(255, 240, 100, 100)
$colorLblMenu = [System.Drawing.Color]::FromArgb(255, 80, 220, 150) 
$colorLblDiag = [System.Drawing.Color]::FromArgb(255, 100, 200, 255)
$colorLblSys  = [System.Drawing.Color]::FromArgb(255, 180, 130, 250)

$colorBtnGen  = [System.Drawing.Color]::FromArgb(255, 80, 35, 40)    
$colorBtnMenu = [System.Drawing.Color]::FromArgb(255, 25, 75, 55)    
$colorBtnDiag = [System.Drawing.Color]::FromArgb(255, 30, 70, 110)   
$colorBtnSys  = [System.Drawing.Color]::FromArgb(255, 55, 35, 80)    

# Flowchart & Terminal Colors
$colorFlowIdle    = [System.Drawing.Color]::FromArgb(255, 57, 66, 84)   
$colorFlowSuccess = [System.Drawing.Color]::FromArgb(255, 46, 204, 113) 
$colorFlowFail    = [System.Drawing.Color]::FromArgb(255, 235, 40, 40) 
$colorArrowIdle   = [System.Drawing.Color]::FromArgb(255, 100, 150, 200) 
$termGreen = [System.Drawing.Color]::FromArgb(255, 46, 204, 113) 
$termCyan  = [System.Drawing.Color]::Cyan
$termGray  = [System.Drawing.Color]::Gray
$termWhite = [System.Drawing.Color]::White

$global:ProgressPercentage = 0
$global:SplashProgressPercentage = 0
$global:FlowNodes = @() 

# Fonts
$fontMenu      = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Regular)
$fontMenuBold  = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$fontHeader    = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
$fontSubHeader = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Regular)
$fontTerminal  = New-Object System.Drawing.Font("Consolas", 9, [System.Drawing.FontStyle]::Regular)
$fontCleanBold = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Bold)
$fontCleanVal  = New-Object System.Drawing.Font("Consolas", 10, [System.Drawing.FontStyle]::Regular)
$fontRowText   = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold) 
$fontFlowNum   = New-Object System.Drawing.Font("Segoe UI", 20, [System.Drawing.FontStyle]::Bold)
$fontFlowText  = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)

# Watermarks
$logoPath = Join-Path -Path $workingDir -ChildPath "logo.png"
$global:fadedWatermark = $null
$global:splashWatermark = $null

if (Test-Path $logoPath) {
    try { 
        $origImg = [System.Drawing.Image]::FromFile($logoPath)
        
        $global:fadedWatermark = New-Object System.Drawing.Bitmap($origImg.Width, $origImg.Height)
        $g1 = [System.Drawing.Graphics]::FromImage($global:fadedWatermark)
        $matrix1 = New-Object System.Drawing.Imaging.ColorMatrix; $matrix1.Matrix33 = 0.25
        $attr1 = New-Object System.Drawing.Imaging.ImageAttributes
        $attr1.SetColorMatrix($matrix1, [System.Drawing.Imaging.ColorMatrixFlag]::Default, [System.Drawing.Imaging.ColorAdjustType]::Bitmap)
        $rect1 = New-Object System.Drawing.Rectangle(0, 0, $origImg.Width, $origImg.Height)
        $g1.DrawImage($origImg, $rect1, 0, 0, $origImg.Width, $origImg.Height, [System.Drawing.GraphicsUnit]::Pixel, $attr1)
        $g1.Dispose()

        $splashLogoSize = 460
        $global:splashWatermark = New-Object System.Drawing.Bitmap($splashLogoSize, $splashLogoSize)
        $g2 = [System.Drawing.Graphics]::FromImage($global:splashWatermark)
        $g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $matrix2 = New-Object System.Drawing.Imaging.ColorMatrix; $matrix2.Matrix33 = 0.75
        $attr2 = New-Object System.Drawing.Imaging.ImageAttributes
        $attr2.SetColorMatrix($matrix2, [System.Drawing.Imaging.ColorMatrixFlag]::Default, [System.Drawing.Imaging.ColorAdjustType]::Bitmap)
        $rect2 = New-Object System.Drawing.Rectangle(0, 0, $splashLogoSize, $splashLogoSize)
        $g2.DrawImage($origImg, $rect2, 0, 0, $origImg.Width, $origImg.Height, [System.Drawing.GraphicsUnit]::Pixel, $attr2)
        $g2.Dispose()
    } catch {}
}

# ==========================================
# 3. SPLASH SCREEN
# ==========================================
$splash = New-Object System.Windows.Forms.Form
$splash.Size = New-Object System.Drawing.Size(450, 450)
$splash.StartPosition = "CenterScreen"
$splash.BackColor = $colorMainBg
$splash.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
Set-RoundedCorner $splash 20

if ($global:splashWatermark) {
    $splash.BackgroundImage = $global:splashWatermark
    $splash.BackgroundImageLayout = [System.Windows.Forms.ImageLayout]::Center
}

$lblSplashTitle = New-Object System.Windows.Forms.Label
$lblSplashTitle.Text = "Phoenix New Server Installation Tool"
$lblSplashTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblSplashTitle.ForeColor = $colorTextWhite
$lblSplashTitle.AutoSize = $false
$lblSplashTitle.Size = New-Object System.Drawing.Size(450, 35)
$lblSplashTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblSplashTitle.Location = New-Object System.Drawing.Point(0, 30)
$lblSplashTitle.BackColor = [System.Drawing.Color]::Transparent
$splash.Controls.Add($lblSplashTitle)

$pnlSplashProgBg = New-Object System.Windows.Forms.Panel
$pnlSplashProgBg.Size = New-Object System.Drawing.Size(390, 25)
$pnlSplashProgBg.Location = New-Object System.Drawing.Point(30, 85)
$pnlSplashProgBg.BackColor = $colorRowBg
Set-RoundedCorner $pnlSplashProgBg 12
$splash.Controls.Add($pnlSplashProgBg)

$pnlSplashProgBg.add_Paint({
    param($sender, $e)
    $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $percent = $global:SplashProgressPercentage
    if ($percent -lt 0) { $percent = 0 }; if ($percent -gt 100) { $percent = 100 }
    $fillWidth = [int](($percent / 100) * $sender.Width)
    
    if ($fillWidth -gt 0) {
        $brushProgress = New-Object System.Drawing.SolidBrush($termGreen)
        $d = 25 
        if ($fillWidth -ge $d) {
            $path = New-Object System.Drawing.Drawing2D.GraphicsPath
            $path.AddArc(0, 0, $d, $d, 180, 90)
            $path.AddArc($fillWidth - $d, 0, $d, $d, 270, 90)
            $path.AddArc($fillWidth - $d, $sender.Height - $d, $d, $d, 0, 90)
            $path.AddArc(0, $sender.Height - $d, $d, $d, 90, 90)
            $path.CloseFigure()
            $g.FillPath($brushProgress, $path)
            $path.Dispose()
        } else {
            $g.FillRectangle($brushProgress, 0, 0, $fillWidth, $sender.Height)
        }
        $brushProgress.Dispose()
    }

    $text = "$percent%"; $font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $brushText = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $stringFormat = New-Object System.Drawing.StringFormat
    $stringFormat.Alignment = [System.Drawing.StringAlignment]::Center
    $stringFormat.LineAlignment = [System.Drawing.StringAlignment]::Center
    $rectF = New-Object System.Drawing.RectangleF(0, 0, $sender.Width, $sender.Height)
    $g.DrawString($text, $font, $brushText, $rectF, $stringFormat)
    $font.Dispose(); $brushText.Dispose(); $stringFormat.Dispose()
})

$splash.add_Paint({
    param($sender, $e)
    $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $glassBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(180, 20, 20, 25))
    $glassPath = New-Object System.Drawing.Drawing2D.GraphicsPath
    $glassPath.AddArc(30, 130, 20, 20, 180, 90)
    $glassPath.AddArc(390, 130, 20, 20, 270, 90)
    $glassPath.AddArc(390, 320, 20, 20, 0, 90)
    $glassPath.AddArc(30, 320, 20, 20, 90, 90)
    $glassPath.CloseFigure()
    $g.FillPath($glassBrush, $glassPath)
    $glassPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(40, 255, 255, 255), 1)
    $g.DrawPath($glassPen, $glassPath)
    $glassBrush.Dispose(); $glassPen.Dispose(); $glassPath.Dispose()
})

$lblSplashLog = New-Object System.Windows.Forms.Label
$lblSplashLog.Size = New-Object System.Drawing.Size(370, 190)
$lblSplashLog.Location = New-Object System.Drawing.Point(40, 140)
$lblSplashLog.BackColor = [System.Drawing.Color]::Transparent
$lblSplashLog.ForeColor = $termCyan
$lblSplashLog.Font = $fontTerminal
$splash.Controls.Add($lblSplashLog)

$global:SplashLogLines = @()
function Log-Splash($msg, $pct) {
    $global:SplashLogLines += "> $msg"
    if ($global:SplashLogLines.Count -gt 11) { $global:SplashLogLines = $global:SplashLogLines[-11..-1] }
    $lblSplashLog.Text = $global:SplashLogLines -join "`r`n"
    $global:SplashProgressPercentage = $pct
    $pnlSplashProgBg.Invalidate(); $splash.Invalidate() 
    [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 400 
}

$lblSplashCopyright = New-Object System.Windows.Forms.Label
$lblSplashCopyright.Text = "© 2026, ProPhoenix Corporation, All Rights Reserved"
$lblSplashCopyright.Font = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Regular)
$lblSplashCopyright.ForeColor = [System.Drawing.Color]::FromArgb(255, 120, 135, 150)
$lblSplashCopyright.AutoSize = $false
$lblSplashCopyright.Size = New-Object System.Drawing.Size(450, 20)
$lblSplashCopyright.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblSplashCopyright.Location = New-Object System.Drawing.Point(0, 420)
$lblSplashCopyright.BackColor = [System.Drawing.Color]::Transparent
$splash.Controls.Add($lblSplashCopyright)

$splash.Add_Shown({
    Log-Splash "Starting pre-requisite configuration..." 10
    try {
        Log-Splash "Unblocking all files in directory..." 30
        Get-ChildItem -Path $workingDir -Recurse -File | Unblock-File
        Log-Splash "Successfully unblocked files." 50
    } catch { Log-Splash "Warning: Could not unblock some files: $_" 50 }
    
    try {
        Log-Splash "Configuring Folder Permissions..." 60
        $acl = Get-Acl -Path $workingDir
        $inherit = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit, ObjectInherit"
        $prop = [System.Security.AccessControl.PropagationFlags]::None
        
        Log-Splash "Adding Full Control for NETWORK SERVICE..." 75
        $rule1 = New-Object System.Security.AccessControl.FileSystemAccessRule("NETWORK SERVICE", "FullControl", $inherit, $prop, "Allow")
        $acl.AddAccessRule($rule1)
        
        Log-Splash "Adding Full Control for IUSR..." 90
        $rule2 = New-Object System.Security.AccessControl.FileSystemAccessRule("IUSR", "FullControl", $inherit, $prop, "Allow")
        $acl.AddAccessRule($rule2)
        
        Set-Acl -Path $workingDir -AclObject $acl
        Log-Splash "Permissions applied successfully." 100
    } catch { Log-Splash "Warning: Could not apply permissions: $_" 100 }
    
    Log-Splash "Initialization complete. Launching dashboard..." 100
    Start-Sleep -Milliseconds 800 
    
    $splash.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $splash.Close()
})

$splashMarker = Join-Path -Path $global:LogDir -ChildPath ".splash_shown"

if (-not (Test-Path $splashMarker)) {
    if ($splash.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { 
        Write-LogToFile "Dashboard launch aborted."
        exit 
    }
    New-Item -Path $splashMarker -ItemType File -Force | Out-Null
} else {
    try {
        Get-ChildItem -Path $workingDir -Recurse -File | Unblock-File | Out-Null
        $acl = Get-Acl -Path $workingDir
        $inherit = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit, ObjectInherit"
        $prop = [System.Security.AccessControl.PropagationFlags]::None
        $rule1 = New-Object System.Security.AccessControl.FileSystemAccessRule("NETWORK SERVICE", "FullControl", $inherit, $prop, "Allow")
        $rule2 = New-Object System.Security.AccessControl.FileSystemAccessRule("IUSR", "FullControl", $inherit, $prop, "Allow")
        $acl.AddAccessRule($rule1); $acl.AddAccessRule($rule2)
        Set-Acl -Path $workingDir -AclObject $acl
    } catch {}
    $splash.Dispose()
}

# ==========================================
# 3.5 DASHBOARD UI PRELOADER
# ==========================================
$preloader = New-Object System.Windows.Forms.Form
$preloader.Size = New-Object System.Drawing.Size(350, 100)
$preloader.StartPosition = "CenterScreen"
$preloader.BackColor = $colorCardBg
$preloader.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
Set-RoundedCorner $preloader 15
Add-GroupBorder $preloader $termCyan

$lblPreTitle = New-Object System.Windows.Forms.Label
$lblPreTitle.Text = "Compiling Dashboard UI..."
$lblPreTitle.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblPreTitle.ForeColor = $colorTextWhite
$lblPreTitle.AutoSize = $false
$lblPreTitle.Size = New-Object System.Drawing.Size(350, 30)
$lblPreTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblPreTitle.Location = New-Object System.Drawing.Point(0, 25)
$preloader.Controls.Add($lblPreTitle)

$lblPreSub = New-Object System.Windows.Forms.Label
$lblPreSub.Text = "Please wait a few seconds."
$lblPreSub.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
$lblPreSub.ForeColor = $termCyan
$lblPreSub.AutoSize = $false
$lblPreSub.Size = New-Object System.Drawing.Size(350, 20)
$lblPreSub.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblPreSub.Location = New-Object System.Drawing.Point(0, 55)
$preloader.Controls.Add($lblPreSub)

$preloader.Show()
$preloader.Refresh()

# ==========================================
# 4. MAIN DASHBOARD UI
# ==========================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "New Installation Dashboard Panel"
$form.ClientSize = New-Object System.Drawing.Size(1240, 900)
$form.StartPosition = "CenterScreen"
$form.BackColor = $colorMainBg
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Sizable
$form.MaximizeBox = $true
$form.MinimizeBox = $true
$form.MinimumSize = New-Object System.Drawing.Size(1256, 939)

# --- Sidebar ---
$sidebar = New-Object System.Windows.Forms.Panel
$sidebar.Size = New-Object System.Drawing.Size(260, 900)
$sidebar.BackColor = $colorSidebarBg
$sidebar.Anchor = "Top, Bottom, Left"
$form.Controls.Add($sidebar)

$picLogo = New-Object System.Windows.Forms.PictureBox
$picLogo.Size = New-Object System.Drawing.Size(150, 150)
$picLogo.Location = New-Object System.Drawing.Point(55, 15)
$picLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom 
if (Test-Path $logoPath) { $picLogo.Image = [System.Drawing.Image]::FromFile($logoPath) }
$sidebar.Controls.Add($picLogo)

$lblTitle1 = New-Object System.Windows.Forms.Label
$lblTitle1.Text = "INSTALLATION"
$lblTitle1.Font = $fontHeader
$lblTitle1.ForeColor = $colorTextWhite
$lblTitle1.AutoSize = $false
$lblTitle1.Size = New-Object System.Drawing.Size(260, 30)
$lblTitle1.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblTitle1.Location = New-Object System.Drawing.Point(0, 180)
$sidebar.Controls.Add($lblTitle1)

$lblTitle2 = New-Object System.Windows.Forms.Label
$lblTitle2.Text = "DASHBOARD"
$lblTitle2.Font = $fontMenuBold
$lblTitle2.ForeColor = $colorLblDash 
$lblTitle2.AutoSize = $false
$lblTitle2.Size = New-Object System.Drawing.Size(260, 20)
$lblTitle2.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblTitle2.Location = New-Object System.Drawing.Point(0, 210)
$sidebar.Controls.Add($lblTitle2)

# --- Sidebar Groups ---
$pnlGroupGen = New-Object System.Windows.Forms.Panel
$pnlGroupGen.Size = New-Object System.Drawing.Size(240, 100) 
$pnlGroupGen.Location = New-Object System.Drawing.Point(10, 240)
Set-RoundedCorner $pnlGroupGen 15
Add-GroupBorder $pnlGroupGen $colorGroupBorder
$sidebar.Controls.Add($pnlGroupGen)

$lblGeneral = New-Object System.Windows.Forms.Label
$lblGeneral.Text = "General"
$lblGeneral.Font = $fontMenuBold; $lblGeneral.ForeColor = $colorLblGen 
$lblGeneral.AutoSize = $false; $lblGeneral.Size = New-Object System.Drawing.Size(240, 20)
$lblGeneral.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter; $lblGeneral.Location = New-Object System.Drawing.Point(0, 10) 
$pnlGroupGen.Controls.Add($lblGeneral)

$btnLoadZip = New-Object System.Windows.Forms.Button
$btnLoadZip.Text = "Reload Scripts"
$btnLoadZip.Font = $fontMenuBold; $btnLoadZip.BackColor = $colorBtnGen
$btnLoadZip.ForeColor = $colorTextWhite; $btnLoadZip.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnLoadZip.FlatAppearance.BorderSize = 0; $btnLoadZip.Size = New-Object System.Drawing.Size(220, 45) 
$btnLoadZip.Location = New-Object System.Drawing.Point(10, 40); $btnLoadZip.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnLoadZip 15
$pnlGroupGen.Controls.Add($btnLoadZip)

$pnlGroupMenu = New-Object System.Windows.Forms.Panel
$pnlGroupMenu.Size = New-Object System.Drawing.Size(240, 155)
$pnlGroupMenu.Location = New-Object System.Drawing.Point(10, 360)
Set-RoundedCorner $pnlGroupMenu 15
Add-GroupBorder $pnlGroupMenu $colorGroupBorder
$sidebar.Controls.Add($pnlGroupMenu)

$lblMenu = New-Object System.Windows.Forms.Label
$lblMenu.Text = "Main"
$lblMenu.Font = $fontMenuBold
$lblMenu.ForeColor = $colorLblMenu
$lblMenu.AutoSize = $false; $lblMenu.Size = New-Object System.Drawing.Size(240, 20)
$lblMenu.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblMenu.Location = New-Object System.Drawing.Point(0, 10)
$pnlGroupMenu.Controls.Add($lblMenu)

$btnDownloadMaster = New-Object System.Windows.Forms.Button
$btnDownloadMaster.Text = "Download Master File"
$btnDownloadMaster.Font = $fontMenuBold
$btnDownloadMaster.BackColor = $colorBtnMenu
$btnDownloadMaster.ForeColor = $colorTextWhite; $btnDownloadMaster.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnDownloadMaster.FlatAppearance.BorderSize = 0; $btnDownloadMaster.Size = New-Object System.Drawing.Size(220, 45)
$btnDownloadMaster.Location = New-Object System.Drawing.Point(10, 40); $btnDownloadMaster.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnDownloadMaster 15
$pnlGroupMenu.Controls.Add($btnDownloadMaster)

$btnCheckUpdate = New-Object System.Windows.Forms.Button
$btnCheckUpdate.Text = "Check for Update"
$btnCheckUpdate.Font = $fontMenuBold
$btnCheckUpdate.BackColor = $colorBtnMenu
$btnCheckUpdate.ForeColor = $colorTextWhite; $btnCheckUpdate.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnCheckUpdate.FlatAppearance.BorderSize = 0; $btnCheckUpdate.Size = New-Object System.Drawing.Size(220, 45)
$btnCheckUpdate.Location = New-Object System.Drawing.Point(10, 95); $btnCheckUpdate.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnCheckUpdate 15
$pnlGroupMenu.Controls.Add($btnCheckUpdate)

$pnlGroupDiag = New-Object System.Windows.Forms.Panel
$pnlGroupDiag.Size = New-Object System.Drawing.Size(240, 155)
$pnlGroupDiag.Location = New-Object System.Drawing.Point(10, 535)
Set-RoundedCorner $pnlGroupDiag 15
Add-GroupBorder $pnlGroupDiag $colorGroupBorder
$sidebar.Controls.Add($pnlGroupDiag)

$lblDiag = New-Object System.Windows.Forms.Label
$lblDiag.Text = "Diagnostics"
$lblDiag.Font = $fontMenuBold; $lblDiag.ForeColor = $colorLblDiag
$lblDiag.AutoSize = $false; $lblDiag.Size = New-Object System.Drawing.Size(240, 20)
$lblDiag.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter; $lblDiag.Location = New-Object System.Drawing.Point(0, 10)
$pnlGroupDiag.Controls.Add($lblDiag)

$btnCheckSftp = New-Object System.Windows.Forms.Button
$btnCheckSftp.Text = "Check SFTP Connection"
$btnCheckSftp.Font = $fontMenuBold; $btnCheckSftp.BackColor = $colorBtnDiag  
$btnCheckSftp.ForeColor = $colorTextWhite; $btnCheckSftp.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnCheckSftp.FlatAppearance.BorderSize = 0; $btnCheckSftp.Size = New-Object System.Drawing.Size(220, 45)
$btnCheckSftp.Location = New-Object System.Drawing.Point(10, 40); $btnCheckSftp.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnCheckSftp 15
$pnlGroupDiag.Controls.Add($btnCheckSftp)

$btnServerInfo = New-Object System.Windows.Forms.Button
$btnServerInfo.Text = "Server Information"
$btnServerInfo.Font = $fontMenuBold; $btnServerInfo.BackColor = $colorBtnDiag
$btnServerInfo.ForeColor = $colorTextWhite; $btnServerInfo.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnServerInfo.FlatAppearance.BorderSize = 0; $btnServerInfo.Size = New-Object System.Drawing.Size(220, 45)
$btnServerInfo.Location = New-Object System.Drawing.Point(10, 95); $btnServerInfo.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnServerInfo 15
$pnlGroupDiag.Controls.Add($btnServerInfo)

# ==========================================
# SYSTEM GROUP
# ==========================================
$pnlGroupSys = New-Object System.Windows.Forms.Panel
$pnlGroupSys.Size = New-Object System.Drawing.Size(240, 155) 
$pnlGroupSys.Location = New-Object System.Drawing.Point(10, 710)
Set-RoundedCorner $pnlGroupSys 15
Add-GroupBorder $pnlGroupSys $colorGroupBorder
$sidebar.Controls.Add($pnlGroupSys)

$lblSystem = New-Object System.Windows.Forms.Label
$lblSystem.Text = "System"
$lblSystem.Font = $fontMenuBold; $lblSystem.ForeColor = $colorLblSys 
$lblSystem.AutoSize = $false; $lblSystem.Size = New-Object System.Drawing.Size(240, 20)
$lblSystem.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter; $lblSystem.Location = New-Object System.Drawing.Point(0, 10)
$pnlGroupSys.Controls.Add($lblSystem)

$btnSwitchHotfix = New-Object System.Windows.Forms.Button
$btnSwitchHotfix.Text = "Switch to Hotfix dashboard"
$btnSwitchHotfix.Font = $fontMenuBold; $btnSwitchHotfix.BackColor = $colorBtnSys
$btnSwitchHotfix.ForeColor = $colorTextWhite; $btnSwitchHotfix.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnSwitchHotfix.FlatAppearance.BorderSize = 0; $btnSwitchHotfix.Size = New-Object System.Drawing.Size(220, 45)
$btnSwitchHotfix.Location = New-Object System.Drawing.Point(10, 40)
$btnSwitchHotfix.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnSwitchHotfix 15
$pnlGroupSys.Controls.Add($btnSwitchHotfix)

$btnExit = New-Object System.Windows.Forms.Button
$btnExit.Text = "Exit Dashboard"
$btnExit.Font = $fontMenuBold; $btnExit.BackColor = $colorBtnSys
$btnExit.ForeColor = $colorTextWhite; $btnExit.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnExit.FlatAppearance.BorderSize = 0; $btnExit.Size = New-Object System.Drawing.Size(220, 45)
$btnExit.Location = New-Object System.Drawing.Point(10, 95)
$btnExit.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnExit 15
$btnExit.Add_Click({ Write-LogToFile "Dashboard Closed."; $form.Close() })
$pnlGroupSys.Controls.Add($btnExit)

$lblVersion = New-Object System.Windows.Forms.Label
$lblVersion.Text = "Version: 6.0.1" 
$lblVersion.Font = $fontCleanBold
$lblVersion.ForeColor = $colorTextMuted
$lblVersion.AutoSize = $false
$lblVersion.Size = New-Object System.Drawing.Size(260, 20)
$lblVersion.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblVersion.Location = New-Object System.Drawing.Point(0, 850) 
$lblVersion.Anchor = "Bottom, Left" 
$sidebar.Controls.Add($lblVersion)

$lblSidebarCredit = New-Object System.Windows.Forms.Label
$lblSidebarCredit.Text = "Designed by Installation Team"
$lblSidebarCredit.Font = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Italic)
$lblSidebarCredit.ForeColor = [System.Drawing.Color]::FromArgb(255, 120, 120, 120) 
$lblSidebarCredit.AutoSize = $false
$lblSidebarCredit.Size = New-Object System.Drawing.Size(260, 20)
$lblSidebarCredit.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblSidebarCredit.Location = New-Object System.Drawing.Point(0, 870)
$lblSidebarCredit.Anchor = "Bottom, Left"
$sidebar.Controls.Add($lblSidebarCredit)

# --- Content Area ---
$contentPanel = New-Object System.Windows.Forms.Panel
$contentPanel.Location = New-Object System.Drawing.Point(260, 0)
$contentPanel.Size = New-Object System.Drawing.Size(980, 900)
$contentPanel.BackColor = $colorMainBg
$contentPanel.Anchor = "Top, Bottom, Left, Right"
$form.Controls.Add($contentPanel)

$sidebar.add_Paint({
    param($sender, $e)
    $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $w = $sender.Width; $h = $sender.Height
    $fadedWhite = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(25, 255, 255, 255))
    $thinPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(30, 255, 255, 255), 3)

    $g.FillEllipse($fadedWhite, -75, -75, 200, 200)
    $g.FillEllipse($fadedWhite, -20, -120, 180, 180)
    $g.FillEllipse($fadedWhite, -100, $h - 100, 250, 250)
    $g.DrawArc($thinPen, -120, $h - 120, 290, 290, 270, 90)

    $fadedWhite.Dispose(); $thinPen.Dispose()
})

$contentPanel.add_Paint({
    param($sender, $e)
    $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $w = $sender.Width; $h = $sender.Height
    $fadedGlow = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(20, 255, 255, 255))
    $fadedPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(35, 255, 255, 255), 25)
    $thinPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(25, 255, 255, 255), 5)

    $g.FillEllipse($fadedGlow, $w - 150, -150, 300, 300)
    $g.DrawArc($thinPen, $w - 180, -180, 360, 360, 90, 90)
    $g.FillEllipse($fadedGlow, $w - 200, $h - 100, 400, 200)
    $g.DrawArc($fadedPen, $w - 250, $h - 250, 400, 400, 135, 180) 
    $g.DrawArc($thinPen, $w - 280, $h - 280, 460, 460, 145, 160)

    $fadedGlow.Dispose(); $fadedPen.Dispose(); $thinPen.Dispose()
})

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "New Installation Dashboard Panel"
$lblTitle.Font = $fontHeader; $lblTitle.ForeColor = $colorTextWhite
$lblTitle.AutoSize = $true; $lblTitle.Location = New-Object System.Drawing.Point(30, 25)
$contentPanel.Controls.Add($lblTitle)

$lblSubTitle = New-Object System.Windows.Forms.Label
$lblSubTitle.Text = "Extract and execute your scripts seamlessly."
$lblSubTitle.Font = $fontSubHeader; $lblSubTitle.ForeColor = $colorTextMuted
$lblSubTitle.AutoSize = $true; $lblSubTitle.Location = New-Object System.Drawing.Point(33, 60)
$contentPanel.Controls.Add($lblSubTitle)

$toggleFullScreen = {
    if ($form.WindowState -eq 'Maximized') { $form.WindowState = 'Normal' }
    else { $form.WindowState = 'Maximized' }
}
$contentPanel.Add_DoubleClick($toggleFullScreen)
$lblTitle.Add_DoubleClick($toggleFullScreen)
$lblSubTitle.Add_DoubleClick($toggleFullScreen)

# ==========================================
# INFO BUTTON & SLIDE-DOWN OVERLAY
# ==========================================
$btnInfo = New-Object System.Windows.Forms.Button
$btnInfo.Text = "i"
$btnInfo.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$btnInfo.Size = New-Object System.Drawing.Size(30, 30)
$btnInfo.Location = New-Object System.Drawing.Point(920, 38) 
$btnInfo.BackColor = $colorCardBg
$btnInfo.ForeColor = $termCyan
$btnInfo.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnInfo.FlatAppearance.BorderSize = 1
$btnInfo.FlatAppearance.BorderColor = $colorGroupBorder
$btnInfo.Cursor = [System.Windows.Forms.Cursors]::Hand
$btnInfo.Anchor = "Top, Right" 
Set-RoundedCorner $btnInfo 15
$contentPanel.Controls.Add($btnInfo)

$global:targetInfoHeight = 450
$pnlInfoOverlay = New-Object System.Windows.Forms.Panel
$pnlInfoOverlay.Size = New-Object System.Drawing.Size(920, 0) 
$pnlInfoOverlay.Location = New-Object System.Drawing.Point(30, 85) 
$pnlInfoOverlay.BackColor = [System.Drawing.Color]::FromArgb(255, 22, 24, 32) 
$pnlInfoOverlay.Visible = $false
$pnlInfoOverlay.Anchor = "Top, Left, Right"
Set-RoundedCorner $pnlInfoOverlay 15

if (Test-Path $logoPath) {
    try { 
        $infoImg = [System.Drawing.Image]::FromFile($logoPath)
        $infoWatermark = New-Object System.Drawing.Bitmap($infoImg.Width, $infoImg.Height)
        $gInfo = [System.Drawing.Graphics]::FromImage($infoWatermark)
        $infoMatrix = New-Object System.Drawing.Imaging.ColorMatrix
        $infoMatrix.Matrix33 = 0.10
        $infoAttr = New-Object System.Drawing.Imaging.ImageAttributes
        $infoAttr.SetColorMatrix($infoMatrix, [System.Drawing.Imaging.ColorMatrixFlag]::Default, [System.Drawing.Imaging.ColorAdjustType]::Bitmap)
        $infoRect = New-Object System.Drawing.Rectangle(0, 0, $infoImg.Width, $infoImg.Height)
        $gInfo.DrawImage($infoImg, $infoRect, 0, 0, $infoImg.Width, $infoImg.Height, [System.Drawing.GraphicsUnit]::Pixel, $infoAttr)
        $gInfo.Dispose(); $infoImg.Dispose()
        $pnlInfoOverlay.BackgroundImage = $infoWatermark; $pnlInfoOverlay.BackgroundImageLayout = [System.Windows.Forms.ImageLayout]::Center
    } catch {}
}

$pnlInfoOverlay.add_Paint({
    param($sender, $e)
    if ($sender.Width -le 30 -or $sender.Height -le 30) { return }
    $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $pen = New-Object System.Drawing.Pen($termCyan, 2)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $r = 15; $w = $sender.Width - 3; $h = $sender.Height - 3
    $path.AddArc(1, 1, $r, $r, 180, 90); $path.AddArc($w - $r, 1, $r, $r, 270, 90)
    $path.AddArc($w - $r, $h - $r, $r, $r, 0, 90); $path.AddArc(1, $h - $r, $r, $r, 90, 90)
    $path.CloseFigure()
    $g.DrawPath($pen, $path); $pen.Dispose(); $path.Dispose()
})

$contentPanel.Controls.Add($pnlInfoOverlay)

$pnlHoverMenu = New-Object System.Windows.Forms.Panel
$pnlHoverMenu.Size = New-Object System.Drawing.Size(160, 80)
$pnlHoverMenu.Location = New-Object System.Drawing.Point(790, 75) 
$pnlHoverMenu.BackColor = $colorCardBg
$pnlHoverMenu.Visible = $false
$pnlHoverMenu.Anchor = "Top, Right"
Set-RoundedCorner $pnlHoverMenu 10
Add-GroupBorder $pnlHoverMenu $colorGroupBorder
$contentPanel.Controls.Add($pnlHoverMenu)

$btnDropHelp = New-Object System.Windows.Forms.Button
$btnDropHelp.Text = "HelpDocs"; $btnDropHelp.Size = New-Object System.Drawing.Size(150, 32)
$btnDropHelp.Location = New-Object System.Drawing.Point(5, 5)
$btnDropHelp.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnDropHelp.FlatAppearance.BorderSize = 0; $btnDropHelp.ForeColor = $termGreen
$btnDropHelp.BackColor = $colorCardBg; $btnDropHelp.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$btnDropHelp.Cursor = [System.Windows.Forms.Cursors]::Hand; $btnDropHelp.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$pnlHoverMenu.Controls.Add($btnDropHelp)

$btnDropAbout = New-Object System.Windows.Forms.Button
$btnDropAbout.Text = "About Dashboard"; $btnDropAbout.Size = New-Object System.Drawing.Size(150, 32)
$btnDropAbout.Location = New-Object System.Drawing.Point(5, 42)
$btnDropAbout.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnDropAbout.FlatAppearance.BorderSize = 0; $btnDropAbout.ForeColor = $termCyan
$btnDropAbout.BackColor = $colorCardBg; $btnDropAbout.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$btnDropAbout.Cursor = [System.Windows.Forms.Cursors]::Hand; $btnDropAbout.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$pnlHoverMenu.Controls.Add($btnDropAbout)

$btnDropHelp.Add_MouseEnter({ $btnDropHelp.BackColor = $colorRowBg })
$btnDropHelp.Add_MouseLeave({ $btnDropHelp.BackColor = $colorCardBg })
$btnDropAbout.Add_MouseEnter({ $btnDropAbout.BackColor = $colorRowBg })
$btnDropAbout.Add_MouseLeave({ $btnDropAbout.BackColor = $colorCardBg })

$hoverTimer = New-Object System.Windows.Forms.Timer; $hoverTimer.Interval = 200
$hoverTimer.Add_Tick({
    $mousePos = $contentPanel.PointToClient([System.Windows.Forms.Cursor]::Position)
    $btnBounds = $btnInfo.Bounds; $btnBounds.Inflate(15, 15)
    $menuBounds = $pnlHoverMenu.Bounds; $menuBounds.Inflate(15, 15)

    if (-not $btnBounds.Contains($mousePos) -and -not $menuBounds.Contains($mousePos)) {
        $pnlHoverMenu.Visible = $false
        $hoverTimer.Stop()
    }
})

$btnInfo.Add_MouseEnter({
    $pnlHoverMenu.Visible = $true; $pnlHoverMenu.BringToFront(); $hoverTimer.Start()
})

$lblInfoTitle = New-Object System.Windows.Forms.Label
$lblInfoTitle.Text = "Server Installation Dashboard - Specifications"
$lblInfoTitle.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
$lblInfoTitle.ForeColor = $termCyan
$lblInfoTitle.AutoSize = $true
$lblInfoTitle.Location = New-Object System.Drawing.Point(30, 30)
$lblInfoTitle.BackColor = [System.Drawing.Color]::Transparent
$pnlInfoOverlay.Controls.Add($lblInfoTitle)

$lblInfoDetails = New-Object System.Windows.Forms.Label
$lblInfoDetails.Size = New-Object System.Drawing.Size(840, 290)
$lblInfoDetails.Location = New-Object System.Drawing.Point(30, 80)
$lblInfoDetails.BackColor = [System.Drawing.Color]::Transparent
$lblInfoDetails.ForeColor = $colorTextWhite
$lblInfoDetails.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Regular)
$lblInfoDetails.Anchor = "Top, Bottom, Left, Right"
$lblInfoDetails.Text = 
"Version : 6.0.1`n`n" +
"DESCRIPTION:`n" +
"This utility provides a centralized, automated interface for deploying and provisioning new server environments. It safely bypasses execution policies in a controlled container, extracts required deployment scripts, and tracks progress via a visual flowchart.`n`n" +
"KEY FEATURES:`n" +
"• Automated Script Discovery: Scans for .ps1 and .bat files dynamically.`n" +
"• Diagnostic Tools: Built-in ProPhoenix SFTP Port verifications and external IP checks.`n" +
"• Process Flow Tracking: Maps execution sequence to ensure prerequisite tasks finish before proceeding.`n" +
"• Secure Execution: Designed to prompt for credentials rather than relying on hardcoded values in external scripts.`n`n" +
"SUPPORT:`n" +
"If you encounter script execution failures, check the 'Execution Logs' tab or review the raw log files in the \Pnxlogs directory."
$pnlInfoOverlay.Controls.Add($lblInfoDetails)

$btnCloseInfo = New-Object System.Windows.Forms.Button
$btnCloseInfo.Text = "Close Panel"; $btnCloseInfo.Size = New-Object System.Drawing.Size(150, 35)
$btnCloseInfo.Location = New-Object System.Drawing.Point(385, 390) 
$btnCloseInfo.Font = $fontMenuBold; $btnCloseInfo.BackColor = $colorAccentRed
$btnCloseInfo.ForeColor = $colorTextWhite; $btnCloseInfo.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnCloseInfo.FlatAppearance.BorderSize = 0; $btnCloseInfo.Cursor = [System.Windows.Forms.Cursors]::Hand
$btnCloseInfo.Anchor = "Bottom" 
Set-RoundedCorner $btnCloseInfo 10
$pnlInfoOverlay.Controls.Add($btnCloseInfo)

$lblCredit = New-Object System.Windows.Forms.Label
$lblCredit.Text = "Designed by Installation Team."
$lblCredit.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Italic)
$lblCredit.ForeColor = $colorTextMuted
$lblCredit.AutoSize = $true
$lblCredit.Location = New-Object System.Drawing.Point(720, 415) 
$lblCredit.BackColor = [System.Drawing.Color]::Transparent
$lblCredit.Anchor = "Bottom, Right"
$pnlInfoOverlay.Controls.Add($lblCredit)

$pnlInfoOverlay.Add_Resize({
    $btnCloseInfo.Left = ($pnlInfoOverlay.Width - $btnCloseInfo.Width) / 2
})

$global:isInfoOpen = $false
$global:infoTimer = New-Object System.Windows.Forms.Timer; $global:infoTimer.Interval = 10 

$global:infoTimer.Add_Tick({
    $step = 35 
    if ($global:isInfoOpen) {
        if ($pnlInfoOverlay.Height -lt $global:targetInfoHeight) { $pnlInfoOverlay.Height += $step } 
        else { $pnlInfoOverlay.Height = $global:targetInfoHeight; $global:infoTimer.Stop() }
    } else {
        if ($pnlInfoOverlay.Height -gt 0) { $pnlInfoOverlay.Height -= $step } 
        else { $pnlInfoOverlay.Height = 0; $pnlInfoOverlay.Visible = $false; $global:infoTimer.Stop() }
    }
})

$btnDropAbout.Add_Click({
    $pnlHoverMenu.Visible = $false
    if (-not $global:isInfoOpen) {
        $pnlInfoOverlay.BringToFront(); $pnlInfoOverlay.Visible = $true
        $global:isInfoOpen = $true; $global:infoTimer.Start()
    } else {
        $global:isInfoOpen = $false; $global:infoTimer.Start()
    }
})

$btnCloseInfo.Add_Click({ if ($global:isInfoOpen) { $global:isInfoOpen = $false; $global:infoTimer.Start() } })

$btnDropHelp.Add_Click({
    $pnlHoverMenu.Visible = $false
    $helpForm = New-Object System.Windows.Forms.Form
    $helpForm.Text = "Dashboard Documentation & Help"
    $helpForm.Size = New-Object System.Drawing.Size(750, 600)
    $helpForm.StartPosition = "CenterParent"
    $helpForm.BackColor = $colorMainBg
    $helpForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $helpForm.MaximizeBox = $false

    $helpTitle = New-Object System.Windows.Forms.Label
    $helpTitle.Text = "Phoenix Installation Dashboard - Help Guide"
    $helpTitle.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
    $helpTitle.ForeColor = $termCyan
    $helpTitle.AutoSize = $true
    $helpTitle.Location = New-Object System.Drawing.Point(25, 20)
    $helpForm.Controls.Add($helpTitle)

    $rtbHelp = New-Object System.Windows.Forms.RichTextBox
    $rtbHelp.Location = New-Object System.Drawing.Point(25, 70)
    $rtbHelp.Size = New-Object System.Drawing.Size(685, 460)
    $rtbHelp.BackColor = $colorCardBg
    $rtbHelp.ForeColor = $colorTextWhite
    $rtbHelp.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Regular)
    $rtbHelp.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $rtbHelp.ReadOnly = $true
    $rtbHelp.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical

    $rtbHelp.Text = @"
========================================================
PHOENIX DASHBOARD - USER MANUAL & FUNCTIONALITY GUIDE
========================================================

1. OVERVIEW
This dashboard automates the extraction, configuration, and execution of ProPhoenix server provisioning scripts. It ensures scripts are run in the correct mathematical order while safely bypassing Windows execution policies in a secure container.

2. MAIN TABS
• Available Scripts: Displays all .ps1 and .bat scripts extracted from the master file. Click 'Run' to execute a task. The UI prevents duplicate executions while a script is running.
• Execution Logs: Contains a live visual flowchart of your progress and raw terminal output to track success and failure codes.

3. SIDEBAR FUNCTIONS
• Reload Scripts: Manually rescans the directory. If a fresh master zip is detected, it will automatically clear the old scripts and extract the new ones.
• Download Master File: Pulls the latest pre-configured script package directly from the secure cloud repository and auto-loads it into the UI.
• Diagnostics (SFTP & Server Info): Verifies that your server can successfully reach ProPhoenix infrastructure (Port 25544) and fetches your Public IP.
• System Information: Generates a comprehensive HTML report of the server's current hardware and software footprint.

4. BATCH GENERATOR CAPABILITY
The Master Provisioning script is fully interactive. It will prompt you for your specific SQL credentials, Install Keys, and Instance names upfront. It then builds a customized .bat file saved to your working directory that you can execute immediately or save for later use.

5. TROUBLESHOOTING
• Scripts not appearing? Click 'Reload Scripts' or ensure the master ZIP is in the same folder as this dashboard.
• Batch script closed unexpectedly? Check the 'Terminal Logs' tab; the dashboard catches exit codes and logs errors even if the pop-up window closes.
• Need raw log files? Click 'View Log Files' in the Execution Logs tab to open the \Pnxlogs directory for historical troubleshooting.
"@

    $helpForm.Controls.Add($rtbHelp)
    $helpForm.ShowDialog() | Out-Null
})

$pnlTimerBadge = New-Object System.Windows.Forms.Panel
$pnlTimerBadge.Size = New-Object System.Drawing.Size(210, 55)
$pnlTimerBadge.Location = New-Object System.Drawing.Point(430, 25)
$pnlTimerBadge.BackColor = $colorCardBg
$pnlTimerBadge.Anchor = "Top, Right"
Set-RoundedCorner $pnlTimerBadge 8
$contentPanel.Controls.Add($pnlTimerBadge)

$lblStatusTitle = New-Object System.Windows.Forms.Label
$lblStatusTitle.Text = "SYSTEM STATUS"
$lblStatusTitle.Font = $fontCleanBold; $lblStatusTitle.ForeColor = $colorTextMuted
$lblStatusTitle.AutoSize = $true; $lblStatusTitle.Location = New-Object System.Drawing.Point(15, 9)
$pnlTimerBadge.Controls.Add($lblStatusTitle)

$lblStatusVal = New-Object System.Windows.Forms.Label
$lblStatusVal.Text = "ONLINE"
$lblStatusVal.Font = $fontCleanVal; $lblStatusVal.ForeColor = $termGreen
$lblStatusVal.AutoSize = $true; $lblStatusVal.Location = New-Object System.Drawing.Point(120, 7)
$pnlTimerBadge.Controls.Add($lblStatusVal)

$lblUptimeTitle = New-Object System.Windows.Forms.Label
$lblUptimeTitle.Text = "SESSION TIME"
$lblUptimeTitle.Font = $fontCleanBold; $lblUptimeTitle.ForeColor = $colorTextMuted
$lblUptimeTitle.AutoSize = $true; $lblUptimeTitle.Location = New-Object System.Drawing.Point(15, 30)
$pnlTimerBadge.Controls.Add($lblUptimeTitle)

$lblUptimeVal = New-Object System.Windows.Forms.Label
$lblUptimeVal.Text = "00:00:00"
$lblUptimeVal.Font = $fontCleanVal; $lblUptimeVal.ForeColor = $termCyan
$lblUptimeVal.AutoSize = $true; $lblUptimeVal.Location = New-Object System.Drawing.Point(120, 28)
$pnlTimerBadge.Controls.Add($lblUptimeVal)

$global:sessionStart = Get-Date
$uiTimer = New-Object System.Windows.Forms.Timer; $uiTimer.Interval = 1000 
$uiTimer.Add_Tick({
    $ts = (Get-Date) - $global:sessionStart
    $lblUptimeVal.Text = "{0:00}:{1:00}:{2:00}" -f $ts.Hours, $ts.Minutes, $ts.Seconds
})
$uiTimer.Start()

$sysHost = [System.Net.Dns]::GetHostName()
$activeIpConfig = Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null } | Select-Object -First 1
$sysIp = if ($activeIpConfig) { $activeIpConfig.IPv4Address.IPAddress } else { "Unknown" }

$pnlHostBadge = New-Object System.Windows.Forms.Panel
$pnlHostBadge.Size = New-Object System.Drawing.Size(260, 55)
$pnlHostBadge.Location = New-Object System.Drawing.Point(650, 25)
$pnlHostBadge.BackColor = $colorCardBg
$pnlHostBadge.Anchor = "Top, Right"
Set-RoundedCorner $pnlHostBadge 8
$contentPanel.Controls.Add($pnlHostBadge)

$lblHostNameLabel = New-Object System.Windows.Forms.Label
$lblHostNameLabel.Text = "HOSTNAME"
$lblHostNameLabel.Font = $fontCleanBold; $lblHostNameLabel.ForeColor = $colorTextMuted
$lblHostNameLabel.AutoSize = $true; $lblHostNameLabel.Location = New-Object System.Drawing.Point(15, 9)
$pnlHostBadge.Controls.Add($lblHostNameLabel)

$lblHostNameVal = New-Object System.Windows.Forms.Label
$lblHostNameVal.Text = $sysHost
$lblHostNameVal.Font = $fontCleanVal; $lblHostNameVal.ForeColor = $colorTextWhite
$lblHostNameVal.AutoSize = $true; $lblHostNameVal.Location = New-Object System.Drawing.Point(100, 7)
$pnlHostBadge.Controls.Add($lblHostNameVal)

$lblIpLabel = New-Object System.Windows.Forms.Label
$lblIpLabel.Text = "IP ADDRESS"
$lblIpLabel.Font = $fontCleanBold; $lblIpLabel.ForeColor = $colorTextMuted
$lblIpLabel.AutoSize = $true; $lblIpLabel.Location = New-Object System.Drawing.Point(15, 30)
$pnlHostBadge.Controls.Add($lblIpLabel)

$lblIpVal = New-Object System.Windows.Forms.Label
$lblIpVal.Text = $sysIp
$lblIpVal.Font = $fontCleanVal; $lblIpVal.ForeColor = $termCyan
$lblIpVal.AutoSize = $true; $lblIpVal.Location = New-Object System.Drawing.Point(100, 28)
$pnlHostBadge.Controls.Add($lblIpVal)

# --- Main Tabs ---
$tabContainer = New-Object System.Windows.Forms.Panel
$tabContainer.Size = New-Object System.Drawing.Size(920, 40)
$tabContainer.Location = New-Object System.Drawing.Point(30, 105)
$tabContainer.BackColor = $colorTabDeact
$tabContainer.Anchor = "Top, Left, Right"
Set-RoundedCorner $tabContainer 20
$contentPanel.Controls.Add($tabContainer)

$btnTab1 = New-Object System.Windows.Forms.Button
$btnTab1.Text = "Available Scripts"
$btnTab1.Size = New-Object System.Drawing.Size(460, 40)
$btnTab1.Location = New-Object System.Drawing.Point(0, 0)
$btnTab1.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnTab1.FlatAppearance.BorderSize = 1 
$btnTab1.FlatAppearance.BorderColor = $colorGroupBorder
$btnTab1.BackColor = $colorTabActive
$btnTab1.ForeColor = $colorTextWhite; $btnTab1.Font = $fontMenuBold
$btnTab1.Cursor = [System.Windows.Forms.Cursors]::Hand
$tabContainer.Controls.Add($btnTab1)

$global:btnTab2 = New-Object System.Windows.Forms.Button
$global:btnTab2.Text = "Execution Logs"
$global:btnTab2.Size = New-Object System.Drawing.Size(460, 40)
$global:btnTab2.Location = New-Object System.Drawing.Point(460, 0)
$global:btnTab2.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$global:btnTab2.FlatAppearance.BorderSize = 1 
$global:btnTab2.FlatAppearance.BorderColor = $colorGroupBorder
$global:btnTab2.BackColor = $colorTabDeact
$global:btnTab2.ForeColor = $colorTextMuted; $global:btnTab2.Font = $fontMenuBold
$global:btnTab2.Cursor = [System.Windows.Forms.Cursors]::Hand
$tabContainer.Controls.Add($global:btnTab2)

$tabContainer.Add_Resize({
    if ($tabContainer.Width -gt 0) {
        $btnTab1.Width = $tabContainer.Width / 2
        $global:btnTab2.Width = $tabContainer.Width / 2
        $global:btnTab2.Left = $btnTab1.Width
    }
})

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = "Status: Initializing..."
$lblStatus.Font = $fontSubHeader; $lblStatus.ForeColor = $colorAccentRed
$lblStatus.AutoSize = $true; $lblStatus.Location = New-Object System.Drawing.Point(33, 160)
$contentPanel.Controls.Add($lblStatus)

# --- Views Setup ---
$global:scriptContainer = New-Object System.Windows.Forms.FlowLayoutPanel
$global:scriptContainer.Location = New-Object System.Drawing.Point(30, 195)
$global:scriptContainer.Size = New-Object System.Drawing.Size(920, 620)
$global:scriptContainer.BackColor = $colorCardBg
$global:scriptContainer.AutoScroll = $true; $global:scriptContainer.FlowDirection = 'TopDown'
$global:scriptContainer.WrapContents = $false; $global:scriptContainer.Padding = New-Object System.Windows.Forms.Padding(10)
Set-RoundedCorner $global:scriptContainer 10
if ($global:fadedWatermark) {
    $global:scriptContainer.BackgroundImage = $global:fadedWatermark
    $global:scriptContainer.BackgroundImageLayout = [System.Windows.Forms.ImageLayout]::Center
}
$contentPanel.Controls.Add($global:scriptContainer)

# --- Additional Scripts Overlay ---
$global:pnlAddOverlay = New-Object System.Windows.Forms.Panel
$global:pnlAddOverlay.Location = $global:scriptContainer.Location
$global:pnlAddOverlay.Size = $global:scriptContainer.Size
$global:pnlAddOverlay.BackColor = $colorCardBg
$global:pnlAddOverlay.Visible = $false
Set-RoundedCorner $global:pnlAddOverlay 10
if ($global:fadedWatermark) {
    $global:pnlAddOverlay.BackgroundImage = $global:fadedWatermark
    $global:pnlAddOverlay.BackgroundImageLayout = [System.Windows.Forms.ImageLayout]::Center
}
$contentPanel.Controls.Add($global:pnlAddOverlay)

$lblAddTitle = New-Object System.Windows.Forms.Label
$lblAddTitle.Text = "Addition Scripts"
$lblAddTitle.Font = $fontHeader
$lblAddTitle.ForeColor = $termCyan
$lblAddTitle.AutoSize = $true
$lblAddTitle.Location = New-Object System.Drawing.Point(15, 15)
$lblAddTitle.BackColor = [System.Drawing.Color]::Transparent
$global:pnlAddOverlay.Controls.Add($lblAddTitle)

$btnCloseAdd = New-Object System.Windows.Forms.Button
$btnCloseAdd.Text = "✖ Close Addition Scripts"
$btnCloseAdd.Size = New-Object System.Drawing.Size(200, 30)
$btnCloseAdd.Location = New-Object System.Drawing.Point(($global:pnlAddOverlay.Width - 215), 15)
$btnCloseAdd.Anchor = "Top, Right"
$btnCloseAdd.Font = $fontSubHeader; $btnCloseAdd.BackColor = $colorAccentRed
$btnCloseAdd.ForeColor = $colorTextWhite; $btnCloseAdd.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnCloseAdd.FlatAppearance.BorderSize = 0; $btnCloseAdd.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnCloseAdd 5
$btnCloseAdd.Add_Click({
    $global:pnlAddOverlay.Visible = $false
    $global:scriptContainer.Visible = $true
})
$global:pnlAddOverlay.Controls.Add($btnCloseAdd)

$global:flpAdd = New-Object System.Windows.Forms.FlowLayoutPanel
$global:flpAdd.Location = New-Object System.Drawing.Point(10, 60)
$addWidth = $global:pnlAddOverlay.Width - 20
$addHeight = $global:pnlAddOverlay.Height - 70
$global:flpAdd.Size = New-Object System.Drawing.Size($addWidth, $addHeight)
$global:flpAdd.Anchor = "Top, Bottom, Left, Right"
$global:flpAdd.AutoScroll = $true; $global:flpAdd.FlowDirection = 'TopDown'
$global:flpAdd.WrapContents = $false; $global:flpAdd.BackColor = [System.Drawing.Color]::Transparent
$global:pnlAddOverlay.Controls.Add($global:flpAdd)

# --- Logs Container ---
$global:logContainer = New-Object System.Windows.Forms.Panel
$global:logContainer.Location = New-Object System.Drawing.Point(30, 195)
$global:logContainer.Size = New-Object System.Drawing.Size(920, 620)
$global:logContainer.BackColor = $colorCardBg
$global:logContainer.Visible = $false
Set-RoundedCorner $global:logContainer 10
$contentPanel.Controls.Add($global:logContainer)

$innerTabContainer = New-Object System.Windows.Forms.Panel
$innerTabContainer.Size = New-Object System.Drawing.Size(890, 35)
$innerTabContainer.Location = New-Object System.Drawing.Point(15, 15)
$innerTabContainer.BackColor = $colorTabDeact
$innerTabContainer.Anchor = "Top, Left, Right"
Set-RoundedCorner $innerTabContainer 15
$global:logContainer.Controls.Add($innerTabContainer)

$btnInnerTab1 = New-Object System.Windows.Forms.Button
$btnInnerTab1.Text = "Process Flowchart"
$btnInnerTab1.Size = New-Object System.Drawing.Size(445, 35)
$btnInnerTab1.Location = New-Object System.Drawing.Point(0, 0)
$btnInnerTab1.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnInnerTab1.FlatAppearance.BorderSize = 1 
$btnInnerTab1.FlatAppearance.BorderColor = $colorGroupBorder
$btnInnerTab1.BackColor = $colorTabActive
$btnInnerTab1.ForeColor = $colorTextWhite; $btnInnerTab1.Font = $fontMenuBold
$btnInnerTab1.Cursor = [System.Windows.Forms.Cursors]::Hand
$innerTabContainer.Controls.Add($btnInnerTab1)

$global:btnInnerTab2 = New-Object System.Windows.Forms.Button
$global:btnInnerTab2.Text = "Terminal Logs"
$global:btnInnerTab2.Size = New-Object System.Drawing.Size(445, 35)
$global:btnInnerTab2.Location = New-Object System.Drawing.Point(445, 0)
$global:btnInnerTab2.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$global:btnInnerTab2.FlatAppearance.BorderSize = 1 
$global:btnInnerTab2.FlatAppearance.BorderColor = $colorGroupBorder
$global:btnInnerTab2.BackColor = $colorTabDeact
$global:btnInnerTab2.ForeColor = $colorTextMuted; $global:btnInnerTab2.Font = $fontMenuBold
$global:btnInnerTab2.Cursor = [System.Windows.Forms.Cursors]::Hand
$innerTabContainer.Controls.Add($global:btnInnerTab2)

$innerTabContainer.Add_Resize({
    if ($innerTabContainer.Width -gt 0) {
        $btnInnerTab1.Width = $innerTabContainer.Width / 2
        $global:btnInnerTab2.Width = $innerTabContainer.Width / 2
        $global:btnInnerTab2.Left = $btnInnerTab1.Width
    }
})

$pnlFlowchart = New-Object System.Windows.Forms.Panel
$pnlFlowchart.Size = New-Object System.Drawing.Size(890, 460) 
$pnlFlowchart.Location = New-Object System.Drawing.Point(15, 65)
$pnlFlowchart.BackColor = $colorMainBg; $pnlFlowchart.AutoScroll = $true
$pnlFlowchart.Anchor = "Top, Bottom, Left, Right"
Set-RoundedCorner $pnlFlowchart 8
if ($global:fadedWatermark) {
    $pnlFlowchart.BackgroundImage = $global:fadedWatermark
    $pnlFlowchart.BackgroundImageLayout = [System.Windows.Forms.ImageLayout]::Center
}
$global:logContainer.Controls.Add($pnlFlowchart)

$pnlProgressBar = New-Object System.Windows.Forms.Panel
$pnlProgressBar.Size = New-Object System.Drawing.Size(890, 20)
$pnlProgressBar.Location = New-Object System.Drawing.Point(15, 535)
$pnlProgressBar.BackColor = $colorRowBg
$pnlProgressBar.Anchor = "Bottom, Left, Right"
Set-RoundedCorner $pnlProgressBar 10
$global:logContainer.Controls.Add($pnlProgressBar)

$global:pnlFlowLogTerm = New-Object System.Windows.Forms.Panel
$global:pnlFlowLogTerm.Size = New-Object System.Drawing.Size(890, 490) 
$global:pnlFlowLogTerm.Location = New-Object System.Drawing.Point(15, 65)
$global:pnlFlowLogTerm.BackColor = $colorConsoleBg; $global:pnlFlowLogTerm.Visible = $false
$global:pnlFlowLogTerm.Anchor = "Top, Bottom, Left, Right"
Set-RoundedCorner $global:pnlFlowLogTerm 8
$global:logContainer.Controls.Add($global:pnlFlowLogTerm)

$rtbFlowLog = New-Object System.Windows.Forms.RichTextBox
$rtbFlowLog.Location = New-Object System.Drawing.Point(15, 15)
$rtbFlowLog.Size = New-Object System.Drawing.Size(860, 460)
$rtbFlowLog.BackColor = $colorConsoleBg; $rtbFlowLog.ForeColor = $colorTextWhite
$rtbFlowLog.Font = $fontTerminal; $rtbFlowLog.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$rtbFlowLog.ReadOnly = $true; $rtbFlowLog.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical
$rtbFlowLog.Anchor = "Top, Bottom, Left, Right"
$global:pnlFlowLogTerm.Controls.Add($rtbFlowLog)

$btnViewLogs = New-Object System.Windows.Forms.Button
$btnViewLogs.Text = "View Log Files"; $btnViewLogs.Size = New-Object System.Drawing.Size(150, 30)
$btnViewLogs.Location = New-Object System.Drawing.Point(15, 575)
$btnViewLogs.Anchor = 'Bottom, Left'; $btnViewLogs.Font = $fontMenuBold
$btnViewLogs.BackColor = [System.Drawing.Color]::FromArgb(255, 50, 70, 95)
$btnViewLogs.ForeColor = $colorTextWhite; $btnViewLogs.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnViewLogs.FlatAppearance.BorderSize = 0; $btnViewLogs.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnViewLogs 8
$global:logContainer.Controls.Add($btnViewLogs)
$btnViewLogs.Add_Click({ Start-Process "explorer.exe" -ArgumentList $global:LogDir })

$btnRefreshLogs = New-Object System.Windows.Forms.Button
$btnRefreshLogs.Text = "Refresh Screen"; $btnRefreshLogs.Size = New-Object System.Drawing.Size(150, 30)
$btnRefreshLogs.Location = New-Object System.Drawing.Point(755, 575)
$btnRefreshLogs.Anchor = 'Bottom, Right'; $btnRefreshLogs.Font = $fontMenuBold
$btnRefreshLogs.BackColor = $colorRefreshBtn 
$btnRefreshLogs.ForeColor = $colorTextWhite; $btnRefreshLogs.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnRefreshLogs.FlatAppearance.BorderSize = 0; $btnRefreshLogs.Cursor = [System.Windows.Forms.Cursors]::Hand
Set-RoundedCorner $btnRefreshLogs 8
$global:logContainer.Controls.Add($btnRefreshLogs)
$btnRefreshLogs.Add_Click({ $pnlFlowchart.Refresh(); $pnlProgressBar.Refresh(); $global:logContainer.Refresh() })

$btnTab1.Add_Click({
    $btnTab1.BackColor = $colorTabActive; $btnTab1.ForeColor = $colorTextWhite
    $global:btnTab2.BackColor = $colorTabDeact; $global:btnTab2.ForeColor = $colorTextMuted
    $global:logContainer.Visible = $false
    if (-not $global:pnlAddOverlay.Visible) {
        $global:scriptContainer.Visible = $true 
    }
})

$global:btnTab2.Add_Click({
    $global:btnTab2.BackColor = $colorTabActive; $global:btnTab2.ForeColor = $colorTextWhite
    $btnTab1.BackColor = $colorTabDeact; $btnTab1.ForeColor = $colorTextMuted
    $global:scriptContainer.Visible = $false
    $global:pnlAddOverlay.Visible = $false
    $global:logContainer.Visible = $true
    Hide-Badge $global:btnTab2 
})

$btnInnerTab1.Add_Click({
    $btnInnerTab1.BackColor = $colorTabActive; $btnInnerTab1.ForeColor = $colorTextWhite
    $global:btnInnerTab2.BackColor = $colorTabDeact; $global:btnInnerTab2.ForeColor = $colorTextMuted
    $pnlFlowchart.Visible = $true; $pnlProgressBar.Visible = $true; $global:pnlFlowLogTerm.Visible = $false
})

$global:btnInnerTab2.Add_Click({
    $global:btnInnerTab2.BackColor = $colorTabActive; $global:btnInnerTab2.ForeColor = $colorTextWhite
    $btnInnerTab1.BackColor = $colorTabDeact; $global:btnInnerTab1.ForeColor = $colorTextMuted
    $pnlFlowchart.Visible = $false; $pnlProgressBar.Visible = $false; $global:pnlFlowLogTerm.Visible = $true
    Hide-Badge $global:btnInnerTab2
})

# ==========================================
# 5. DYNAMIC SPLIT SCREEN & SCRIPT ROW RESIZE
# ==========================================
$contentPanel.Add_Resize({ 
    $contentPanel.Refresh() 
    
    if (-not $global:scriptContainer -or -not $global:logContainer) { return }

    $margin = 30; $spacing = 30
    $availableWidth = $contentPanel.Width - ($margin * 2)

    if ($form.WindowState -eq 'Maximized') {
        $tabContainer.Visible = $false
        $halfWidth = [int](($availableWidth - $spacing) / 2)
        $dynamicHeight = $contentPanel.Height - 195 - 90 
        
        $global:scriptContainer.Left = $margin
        $global:scriptContainer.Width = $halfWidth
        $global:scriptContainer.Height = $dynamicHeight 

        $global:pnlAddOverlay.Left = $margin
        $global:pnlAddOverlay.Width = $halfWidth
        $global:pnlAddOverlay.Height = $dynamicHeight

        if ($global:pnlAddOverlay.Visible) { $global:scriptContainer.Visible = $false } 
        else { $global:scriptContainer.Visible = $true }
        
        $global:logContainer.Visible = $true
        $global:logContainer.Left = $global:scriptContainer.Right + $spacing
        $global:logContainer.Width = $halfWidth
        $global:logContainer.Height = $dynamicHeight 

        $global:btnInnerTab2.PerformClick()
    } else {
        $tabContainer.Visible = $true
        $tabContainer.Width = $availableWidth
        
        $global:scriptContainer.Left = $margin
        $global:scriptContainer.Width = $availableWidth
        $global:scriptContainer.Height = 620 

        $global:pnlAddOverlay.Left = $margin
        $global:pnlAddOverlay.Width = $availableWidth
        $global:pnlAddOverlay.Height = 620
        
        $global:logContainer.Left = $margin
        $global:logContainer.Width = $availableWidth
        $global:logContainer.Height = 620 
        
        if ($btnTab1.BackColor -eq $colorTabActive) {
            if ($global:pnlAddOverlay.Visible) { $global:scriptContainer.Visible = $false } 
            else { $global:scriptContainer.Visible = $true }
            $global:logContainer.Visible = $false
        } else {
            $global:scriptContainer.Visible = $false; $global:pnlAddOverlay.Visible = $false
            $global:logContainer.Visible = $true
        }
    }
})

$global:scriptContainer.Add_Resize({
    $global:scriptContainer.SuspendLayout()
    $newClientW = $global:scriptContainer.ClientSize.Width - 25 
    foreach ($ctrl in $global:scriptContainer.Controls) {
        if ($ctrl.GetType().Name -eq "Panel") { $ctrl.Width = $newClientW }
    }
    $global:scriptContainer.ResumeLayout()
})

$global:pnlAddOverlay.Add_Resize({
    $global:flpAdd.SuspendLayout()
    $newClientW = $global:flpAdd.ClientSize.Width - 25 
    foreach ($ctrl in $global:flpAdd.Controls) {
        if ($ctrl.GetType().Name -eq "Panel") { $ctrl.Width = $newClientW }
    }
    $global:flpAdd.ResumeLayout()
})

# ==========================================
# 6. LATEST ACTIVITY SCANNER UI & LOGIC
# ==========================================
$pnlTickerOuter = New-Object System.Windows.Forms.Panel
$pnlTickerOuter.Size = New-Object System.Drawing.Size(($contentPanel.Width - 60), 35)
$pnlTickerOuter.Location = New-Object System.Drawing.Point(30, 835) 
$pnlTickerOuter.BackColor = $colorRowBg
$pnlTickerOuter.Anchor = "Bottom, Left, Right"
Set-RoundedCorner $pnlTickerOuter 8
$contentPanel.Controls.Add($pnlTickerOuter)

$lblTickerTitle = New-Object System.Windows.Forms.Label
$lblTickerTitle.Text = "ACTIVITY SCANNER:"
$lblTickerTitle.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$lblTickerTitle.ForeColor = $colorLblDash
$lblTickerTitle.AutoSize = $false
$lblTickerTitle.Size = New-Object System.Drawing.Size(130, 35)
$lblTickerTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblTickerTitle.Location = New-Object System.Drawing.Point(0, 0)
$pnlTickerOuter.Controls.Add($lblTickerTitle)

$global:lblTicker = New-Object System.Windows.Forms.Label
$global:lblTicker.Text = "System Initialized and Ready."
$global:lblTicker.Font = New-Object System.Drawing.Font("Consolas", 10, [System.Drawing.FontStyle]::Regular)
$global:lblTicker.ForeColor = $termCyan
$global:lblTicker.AutoSize = $true
$global:lblTicker.Location = New-Object System.Drawing.Point(140, 8) 
$global:lblTicker.BackColor = [System.Drawing.Color]::Transparent
$pnlTickerOuter.Controls.Add($global:lblTicker)

function Write-Ticker($Message) {
    $global:lblTicker.Text = $Message
    $global:lblTicker.Refresh()
}

# ==========================================
# 7. CORE LOGIC (EXECUTION & FLOWCHART)
# ==========================================
function Write-Console($Message, $Color) {
    Write-LogToFile $Message
    $timestamp = "[{0:yyyy-MM-dd HH:mm:ss}] " -f (Get-Date)
    $rtbFlowLog.SelectionStart = $rtbFlowLog.TextLength
    $rtbFlowLog.SelectionLength = 0; $rtbFlowLog.SelectionColor = $termGray
    $rtbFlowLog.AppendText($timestamp)
    $rtbFlowLog.SelectionStart = $rtbFlowLog.TextLength
    $rtbFlowLog.SelectionLength = 0; $rtbFlowLog.SelectionColor = $Color
    $rtbFlowLog.AppendText($Message + "`r`n")
    $rtbFlowLog.ScrollToCaret()
    $form.Refresh()
}

$pnlFlowchart.add_Paint({
    param($sender, $e)
    $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    if ($global:FlowNodes.Count -lt 2) { return }

    $penStandard = New-Object System.Drawing.Pen($colorArrowIdle, 3); $penStandard.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round
    $penGlow = New-Object System.Drawing.Pen($termGreen, 4); $penGlow.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round
    $penFail = New-Object System.Drawing.Pen($colorFlowFail, 4); $penFail.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round
    $arrowCap = New-Object System.Drawing.Drawing2D.AdjustableArrowCap(5, 5) 
    $penStandard.CustomEndCap = $arrowCap; $penGlow.CustomEndCap = $arrowCap; $penFail.CustomEndCap = $arrowCap

    for ($i = 0; $i -lt ($global:FlowNodes.Count - 1); $i++) {
        $curr = $global:FlowNodes[$i]; $next = $global:FlowNodes[$i+1]
        
        if ($curr.IsDone -eq $true) { $activePen = $penGlow } 
        elseif ($curr.Panel.BackColor -eq $colorFlowFail) { $activePen = $penFail } 
        else { $activePen = $penStandard }
        
        $cx1 = $curr.X + ($curr.Panel.Width / 2); $cy1 = $curr.Y + ($curr.Panel.Height / 2)
        $cx2 = $next.X + ($next.Panel.Width / 2); $cy2 = $next.Y + ($next.Panel.Height / 2)

        if ($next.ID -eq "✔") {
            $p1Y = $curr.Y + $curr.Panel.Height; $p4Y = $next.Y - 2
            $midY = $p1Y + (($p4Y - $p1Y) / 2)
            $points = [System.Drawing.Point[]]@(
                (New-Object System.Drawing.Point($cx1, $p1Y)), (New-Object System.Drawing.Point($cx1, $midY)),
                (New-Object System.Drawing.Point($cx2, $midY)), (New-Object System.Drawing.Point($cx2, $p4Y))
            )
            $g.DrawLines($activePen, $points); continue
        }
        
        if ($curr.Y -eq $next.Y) { 
            if ($cx1 -lt $cx2) { $cx1 += ($curr.Panel.Width / 2); $cx2 -= ($next.Panel.Width / 2 + 5) } 
            else { $cx1 -= ($curr.Panel.Width / 2); $cx2 += ($next.Panel.Width / 2 + 5) }
        } else { 
            $cy1 += ($curr.Panel.Height / 2); $cy2 -= ($next.Panel.Height / 2 + 5) 
        }
        $g.DrawLine($activePen, $cx1, $cy1, $cx2, $cy2)
    }
    $penStandard.Dispose(); $penGlow.Dispose(); $penFail.Dispose()
})

$pnlFlowchart.Add_Resize({
    $endNode = $global:FlowNodes | Where-Object { $_.ID -eq "✔" }
    if ($endNode -and $endNode.Panel) {
        $endNode.X = ($pnlFlowchart.Width - $endNode.Panel.Width) / 2
        $endNode.Panel.Left = $endNode.X
    }
    $pnlFlowchart.Refresh()
})

$pnlProgressBar.add_Paint({
    param($sender, $e)
    $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $percent = $global:ProgressPercentage
    if ($percent -lt 0) { $percent = 0 }; if ($percent -gt 100) { $percent = 100 }
    $fillWidth = [int](($percent / 100) * $sender.Width)
    
    if ($fillWidth -gt 0) {
        $brushProgress = New-Object System.Drawing.SolidBrush($colorFlowSuccess)
        $d = 20 
        if ($fillWidth -ge $d) {
            $path = New-Object System.Drawing.Drawing2D.GraphicsPath
            $path.AddArc(0, 0, $d, $d, 180, 90)
            $path.AddArc($fillWidth - $d, 0, $d, $d, 270, 90)
            $path.AddArc($fillWidth - $d, $sender.Height - $d, $d, $d, 0, 90)
            $path.AddArc(0, $sender.Height - $d, $d, $d, 90, 90)
            $path.CloseFigure()
            $g.FillPath($brushProgress, $path)
            $path.Dispose()
        } else {
            $g.FillRectangle($brushProgress, 0, 0, $fillWidth, $sender.Height)
        }
        $brushProgress.Dispose()
    }
    $text = "$percent%"; $font = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Bold)
    $brushText = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $stringFormat = New-Object System.Drawing.StringFormat
    $stringFormat.Alignment = [System.Drawing.StringAlignment]::Center; $stringFormat.LineAlignment = [System.Drawing.StringAlignment]::Center
    $rectF = New-Object System.Drawing.RectangleF(0, 0, $sender.Width, $sender.Height)
    $g.DrawString($text, $font, $brushText, $rectF, $stringFormat)
    $font.Dispose(); $brushText.Dispose(); $stringFormat.Dispose()
})

function Update-FlowchartNode($ScriptName, $IsSuccess) {
    $allScriptsDone = $true

    foreach ($node in $global:FlowNodes) {
        if ($node.ID -ne "✔") {
            if ($ScriptName -eq $node.Match) {
                if ($IsSuccess) {
                    $node.Panel.BackColor = $colorFlowSuccess; $node.IsDone = $true  
                } else {
                    $node.Panel.BackColor = $colorFlowFail; $node.IsDone = $false 
                }
            }
            if (-not $node.IsDone) { $allScriptsDone = $false }
        }
    }

    $endNode = $global:FlowNodes | Where-Object { $_.ID -eq "✔" }
    if ($endNode) {
        if ($allScriptsDone -and $global:FlowNodes.Count -gt 1) {
            $endNode.Panel.BackColor = $colorFlowSuccess; $endNode.IsDone = $true
        } else {
            $endNode.Panel.BackColor = $colorFlowIdle; $endNode.IsDone = $false
        }
    }

    $totalNodes = $global:FlowNodes.Count
    $completedNodes = ($global:FlowNodes | Where-Object { $_.IsDone -eq $true }).Count
    $global:ProgressPercentage = [math]::Round(($completedNodes / $totalNodes) * 100)
    $pnlFlowchart.Invalidate(); $pnlProgressBar.Invalidate() 
}

function Run-Script($filePath) {
    if ([string]::IsNullOrWhiteSpace($filePath)) {
        $lblStatus.Text = "Status: Error - Script path empty."
        $lblStatus.ForeColor = $colorAccentRed
        Write-Console "ERROR: Attempted to run a script, but path was empty." $colorAccentRed
        Write-Ticker "Script Run Failed: Path Empty."
        return
    }

    $scriptName = Split-Path $filePath -Leaf
    $scriptDir = Split-Path $filePath -Parent 

    $timestamp = Get-Date -f "yyyyMMdd_HHmmss"
    $safeScriptName = $scriptName -replace '[\\/:\*\?"<>\|]', '_'
    $scriptLogPath = Join-Path -Path $global:LogDir -ChildPath "${safeScriptName}_${timestamp}.log"

    $lblStatus.Text = "Status: Executing $scriptName as Admin..."
    $lblStatus.ForeColor = $termCyan
    $lblStatusVal.Text = "BUSY..."
    $lblStatusVal.ForeColor = [System.Drawing.Color]::Yellow
    
    Write-Console "ACTION: Triggered execution of script '$scriptName'" $termWhite
    Write-Console "INFO: Output is being logged to: $scriptLogPath" $termGray
    Write-Ticker "Executing Task: $scriptName"
    $form.Refresh()
    
    $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
    try {
        if ($ext -eq ".ps1") {
            $argString = "-NoProfile -ExecutionPolicy Bypass -NoExit -Command `"Start-Transcript -Path '$scriptLogPath' -Force; & '$filePath'; Stop-Transcript`""
            $process = Start-Process powershell.exe -WorkingDirectory $scriptDir -ArgumentList $argString -Verb RunAs -PassThru -Wait
        } elseif ($ext -eq ".bat") {
            $argString = "-NoProfile -ExecutionPolicy Bypass -Command `"Start-Transcript -Path '$scriptLogPath' -Force; cmd.exe /c '$filePath'; Stop-Transcript`""
            $process = Start-Process powershell.exe -WorkingDirectory $scriptDir -ArgumentList $argString -Verb RunAs -PassThru -Wait
        }
        
        if ($process.ExitCode -eq 0) {
            Update-FlowchartNode $scriptName $true
            $lblStatus.Text = "Status: Script completed successfully."
            $lblStatus.ForeColor = $termGreen
            Write-Console "SUCCESS: $scriptName executed cleanly." $termGreen
            Write-Ticker "Task Completed: $scriptName"
        } else {
            Update-FlowchartNode $scriptName $false
            $lblStatus.Text = "Status: Script returned an error (Code: $($process.ExitCode))."
            $lblStatus.ForeColor = $colorAccentRed
            Write-Console "FAILED: $scriptName exited with errors or was closed prematurely." $colorAccentRed
            Write-Ticker "Task Error: $scriptName (Code $($process.ExitCode))"
        }
    } catch {
        Update-FlowchartNode $scriptName $false
        $lblStatus.Text = "Status: FAILED to launch $scriptName"
        $lblStatus.ForeColor = $colorAccentRed
        Write-Console "ERROR: $_" $colorAccentRed
        Write-Ticker "Execution Failed: $scriptName"
    }
    Start-Sleep -Milliseconds 500
    $lblStatusVal.Text = "ONLINE"
    $lblStatusVal.ForeColor = $termGreen
    
    Show-Badge $global:btnTab2 "!"
    Show-Badge $global:btnInnerTab2 "!"
}

function Load-ScriptButtons($folderPath) {
    $global:scriptContainer.SuspendLayout()
    $global:flpAdd.SuspendLayout()
    $global:scriptContainer.Controls.Clear(); $pnlFlowchart.Controls.Clear(); $global:flpAdd.Controls.Clear()
    $global:FlowNodes = @()
    
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.AutoPopDelay = 5000; $tooltip.InitialDelay = 100; $tooltip.ReshowDelay = 100; $tooltip.ShowAlways = $true
    
    $allScripts = Get-ChildItem -Path $folderPath -Include *.ps1, *.bat -Recurse

    if ($allScripts.Count -eq 0) {
        $lblStatus.Text = "Status: No valid scripts (.ps1, .bat) found in ZIP."
        $lblStatus.ForeColor = $colorAccentRed
        Write-Console "WARNING: Extraction successful, but no valid scripts were found." $colorAccentRed
        Write-Ticker "Warning: No valid scripts found in archive."
        $global:scriptContainer.ResumeLayout(); $global:flpAdd.ResumeLayout()
        return
    }

    # MATCH FIX: Checks for either "Addition Scripts" or "Additional Scripts"
    $addScripts = $allScripts | Where-Object { $_.DirectoryName -match "Addition Scripts" -or $_.DirectoryName -match "Additional Scripts" } | Sort-Object Name
    $mainScripts = $allScripts | Where-Object { $_.DirectoryName -notmatch "Addition Scripts" -and $_.DirectoryName -notmatch "Additional Scripts" } | Sort-Object {
        $numMatch = [regex]::Match($_.Name, '^\d+')
        if ($numMatch.Success) { [int]$numMatch.Value } else { 9999 }
    }, Name

    $i = 0; $nodesPerRow = 3; $boxW = 160; $boxH = 50; $xSpacing = 260; $ySpacing = 80; $startX = 60; $startY = 50
    $rowW = $global:scriptContainer.ClientSize.Width - 25

    # --- 1. BUILD MAIN SCRIPTS ---
    foreach ($script in $mainScripts) {
        $rowPanel = New-Object System.Windows.Forms.Panel
        $rowPanel.Size = New-Object System.Drawing.Size($rowW, 50)
        $rowPanel.BackColor = $colorRowGlass 
        $rowPanel.Margin = New-Object System.Windows.Forms.Padding(11, 5, 0, 5)
        Set-RoundedCorner $rowPanel 8

        $lblName = New-Object System.Windows.Forms.Label
        $lblName.Text = $script.BaseName 
        $lblName.Font = $fontRowText; $lblName.ForeColor = $colorTextWhite
        $lblName.AutoSize = $true; $lblName.Location = New-Object System.Drawing.Point(15, 13) 
        $lblName.BackColor = [System.Drawing.Color]::Transparent
        $rowPanel.Controls.Add($lblName)

        $btnRun = New-Object System.Windows.Forms.Button
        $btnRun.Text = "Run"; $btnRun.Size = New-Object System.Drawing.Size(80, 30)
        $btnRun.Anchor = "Top, Right"
        $btnRun.Location = New-Object System.Drawing.Point(($rowW - 95), 10) 
        $btnRun.Font = $fontSubHeader; $btnRun.BackColor = $colorMainBg
        $btnRun.ForeColor = $colorTextWhite; $btnRun.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnRun.FlatAppearance.BorderSize = 1; $btnRun.FlatAppearance.BorderColor = $colorBtnBorder
        $btnRun.Cursor = [System.Windows.Forms.Cursors]::Hand
        Set-RoundedCorner $btnRun 5
        
        $btnRun.Tag = $script.FullName
        $btnRun.Add_Click({ Run-Script $this.Tag })
        $rowPanel.Controls.Add($btnRun); $global:scriptContainer.Controls.Add($rowPanel)

        $row = [math]::Floor($i / $nodesPerRow)
        $col = $i % $nodesPerRow
        if ($row % 2 -ne 0) { $col = ($nodesPerRow - 1) - $col } 
        
        $cleanName = $script.BaseName -replace '^\d+\s*-\s*', ''
        $shortName = if ($cleanName.Length -gt 22) { $cleanName.Substring(0, 19) + "..." } else { $cleanName }
        
        $global:FlowNodes += [pscustomobject]@{ 
            ID = ($i + 1).ToString(); Name = $cleanName; ShortName = $shortName; Match = $script.Name; 
            X = $startX + ($col * $xSpacing); Y = $startY + ($row * $ySpacing); 
            Panel = $null; Lbl = $null; IsDone = $false 
        }
        $i++
    }

    # --- 2. ADD BUTTON & BUILD ADDITION SCRIPTS ---
    if ($addScripts.Count -gt 0) {
        $btnOpenAdd = New-Object System.Windows.Forms.Button
        $btnOpenAdd.Text = "Open Addition Scripts ($($addScripts.Count))"
        
        # CHANGED: Makes the button width match the script rows dynamically
        $btnOpenAdd.Size = New-Object System.Drawing.Size($rowW, 45)
        $btnOpenAdd.Anchor = "Top, Left, Right"
        
        $btnOpenAdd.Margin = New-Object System.Windows.Forms.Padding(11, 25, 0, 15)
        $btnOpenAdd.Font = $fontMenuBold
        $btnOpenAdd.BackColor = $colorTabDeact     # Matches the dark inactive tabs
        $btnOpenAdd.ForeColor = $termCyan          # Makes the text pop in cyan
        $btnOpenAdd.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btnOpenAdd.FlatAppearance.BorderSize = 1      # Adds a subtle outline
        $btnOpenAdd.FlatAppearance.BorderColor = $colorGroupBorder
        $btnOpenAdd.Cursor = [System.Windows.Forms.Cursors]::Hand
        Set-RoundedCorner $btnOpenAdd 8
        $btnOpenAdd.Add_Click({
            $global:scriptContainer.Visible = $false
            $global:pnlAddOverlay.Visible = $true
            $global:pnlAddOverlay.BringToFront()
        })
        $global:scriptContainer.Controls.Add($btnOpenAdd)

        foreach ($addScript in $addScripts) {
            $rowPanel = New-Object System.Windows.Forms.Panel
            $rowPanel.Size = New-Object System.Drawing.Size($rowW, 50)
            $rowPanel.BackColor = $colorRowGlass
            $rowPanel.Margin = New-Object System.Windows.Forms.Padding(0, 5, 0, 5)
            Set-RoundedCorner $rowPanel 8

            $lblName = New-Object System.Windows.Forms.Label
            $lblName.Text = $addScript.BaseName
            $lblName.Font = $fontRowText; $lblName.ForeColor = $colorTextWhite
            $lblName.AutoSize = $true; $lblName.Location = New-Object System.Drawing.Point(15, 13)
            $lblName.BackColor = [System.Drawing.Color]::Transparent
            $rowPanel.Controls.Add($lblName)

            $btnRun = New-Object System.Windows.Forms.Button
            $btnRun.Text = "Run"; $btnRun.Size = New-Object System.Drawing.Size(80, 30)
            $btnRun.Anchor = "Top, Right"
            $btnRun.Location = New-Object System.Drawing.Point(($rowW - 95), 10)
            $btnRun.Font = $fontSubHeader; $btnRun.BackColor = $colorMainBg
            $btnRun.ForeColor = $colorTextWhite; $btnRun.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $btnRun.FlatAppearance.BorderSize = 1; $btnRun.FlatAppearance.BorderColor = $colorBtnBorder
            $btnRun.Cursor = [System.Windows.Forms.Cursors]::Hand
            Set-RoundedCorner $btnRun 5

            $btnRun.Tag = $addScript.FullName
            $btnRun.Add_Click({ Run-Script $this.Tag })
            $rowPanel.Controls.Add($btnRun); $global:flpAdd.Controls.Add($rowPanel)
        }
    }

    # --- 3. BUILD FLOWCHART LOGIC ---
    $maxRow = if ($i -gt 0) { [math]::Floor(($i - 1) / $nodesPerRow) } else { 0 }
    $finalY = $startY + (($maxRow + 1) * $ySpacing)
    $minFinalY = $pnlFlowchart.Height - $boxH - 15
    if ($finalY -lt $minFinalY) { $finalY = $minFinalY }

    $global:FlowNodes += [pscustomobject]@{ 
        ID = "✔"; Name = "Installation Completed"; ShortName = "✔ Complete"; Match = ""; 
        X = ($pnlFlowchart.Width - $boxW) / 2; Y = $finalY; 
        Panel = $null; Lbl = $null; IsDone = $false 
    }

    foreach ($node in $global:FlowNodes) {
        $nodePnl = New-Object System.Windows.Forms.Panel
        $nodePnl.Size = New-Object System.Drawing.Size($boxW, $boxH)
        $nodePnl.Location = New-Object System.Drawing.Point($node.X, $node.Y)
        $nodePnl.BackColor = $colorFlowIdle
        Set-RoundedCorner $nodePnl 8
        
        $nodeLbl = New-Object System.Windows.Forms.Label
        $nodeLbl.Text = $node.ShortName; $nodeLbl.Font = $fontFlowText
        $nodeLbl.ForeColor = $colorTextWhite; $nodeLbl.Dock = 'Fill'
        $nodeLbl.TextAlign = 'MiddleCenter'
        
        $tooltip.SetToolTip($nodePnl, $node.Name); $tooltip.SetToolTip($nodeLbl, $node.Name)
        $nodePnl.Controls.Add($nodeLbl); $pnlFlowchart.Controls.Add($nodePnl)
        $node.Panel = $nodePnl; $node.Lbl = $nodeLbl
    }
    
    $pnlFlowchart.Invalidate()
    $global:scriptContainer.ResumeLayout(); $global:flpAdd.ResumeLayout()
    $lblStatus.Text = "Status: Successfully loaded $($mainScripts.Count) core scripts."
    $lblStatus.ForeColor = $termGreen
    Write-Console "SUCCESS: Loaded $($allScripts.Count) total scripts into the dashboard." $termGreen
    Write-Ticker "Loaded $($allScripts.Count) Scripts into UI."
}

# ==========================================
# ACTION LISTENERS
# ==========================================

$btnServerInfo.Add_Click({
    $sysInfoScriptPath = Join-Path -Path $workingDir -ChildPath "System Information Report PS Script.ps1"
    if (Test-Path $sysInfoScriptPath) {
        Write-Console "ACTION: Executing System Information Report script..." $termCyan
        Write-Ticker "Generating System Information Report..."
        try {
            Start-Process powershell.exe -WorkingDirectory $workingDir -ArgumentList "-ExecutionPolicy Bypass -File `"$sysInfoScriptPath`"" -Verb RunAs
            Write-Console "SUCCESS: System Information Report script launched successfully." $termGreen
            Write-Ticker "System Information Report Generation Complete."
        } catch {
            Write-Console "ERROR: Failed to launch System Information script. Details: $_" $colorAccentRed
            Write-Ticker "Error: Failed to Generate System Report."
        }
    } else {
        Write-Console "ERROR: 'System Information Report PS Script.ps1' not found in $workingDir" $colorAccentRed
        [System.Windows.Forms.MessageBox]::Show("The script could not be found.", "File Not Found", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    }
    
    Show-Badge $global:btnTab2 "!"
    Show-Badge $global:btnInnerTab2 "!"
})

$btnSwitchHotfix.Add_Click({
    # 1. Ask for confirmation
    $confirmMsg = "Are you sure you want to switch to the Hotfix Update Dashboard?`n`nBefore proceeding, make sure you have saved all your work."
    $confirmResult = [System.Windows.Forms.MessageBox]::Show($confirmMsg, "Confirm Switch", [System.Windows.Forms.MessageBoxButtons]::OKCancel, [System.Windows.Forms.MessageBoxIcon]::Warning)

    # 2. Check if user clicked OK
    if ($confirmResult -eq [System.Windows.Forms.DialogResult]::OK) {
        
        # 3. Construct the path to the Hotfix executable
        $hotfixExePath = Join-Path -Path $workingDir -ChildPath "Hotfix update Dashboard\InstallationMasterToolv8.45.exe"
        
        # 4. Verify the executable actually exists before closing the current app
        if (Test-Path $hotfixExePath) {
            Write-LogToFile "ACTION: User confirmed switch to Hotfix Dashboard. Initiating transition..."
            
            # Disable the button so it can't be clicked twice during fade
            $btnSwitchHotfix.Enabled = $false 

            # 5. Smooth Transition (Fade out the current dashboard)
            while ($form.Opacity -gt 0) {
                $form.Opacity -= 0.05
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 20
            }
            
            # 6. Launch the Hotfix Dashboard and close the current one
            try {
                Start-Process -FilePath $hotfixExePath
                Write-LogToFile "SUCCESS: Hotfix Dashboard launched. Closing Main Dashboard."
                $form.Close()
            } catch {
                # Fallback if execution fails at the last second
                $form.Opacity = 1
                [System.Windows.Forms.MessageBox]::Show("Failed to launch the Hotfix Dashboard.`n`nError: $_", "Execution Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
                $btnSwitchHotfix.Enabled = $true
            }
            
        } else {
            # File not found warning
            Write-LogToFile "ERROR: Attempted to switch to Hotfix Dashboard, but EXE was not found at $hotfixExePath"
            [System.Windows.Forms.MessageBox]::Show("Could not locate the Hotfix Dashboard executable.`n`nPlease ensure 'InstallationMasterToolv8.45.exe' is inside the 'Hotfix update Dashboard' folder.", "File Not Found", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        }
    } else {
        # User cancelled
        Write-Console "INFO: Switch to Hotfix Dashboard cancelled by user." $termWhite
        Write-Ticker "Switch to Hotfix Dashboard aborted."
    }
})

$btnDownloadMaster.Add_Click({
    $btnDownloadMaster.Enabled = $false
    $url = "https://drive.google.com/uc?export=download&id=1ZxgNccN8eawRLe0ZgzWFA0OwdWfN-iXT"
    $destPath = Join-Path -Path $workingDir -ChildPath "MasterFile.zip"

    Write-Console "ACTION: Initiating download from Google Drive..." $termCyan
    Write-Ticker "Downloading Master File, please wait..."
    $lblStatus.Text = "Status: Downloading..."
    $lblStatus.ForeColor = $termCyan
    $form.Refresh() 

    try {
        Invoke-WebRequest -Uri $url -OutFile $destPath -UseBasicParsing
        
        Write-Console "SUCCESS: File downloaded successfully to $destPath" $termGreen
        Write-Ticker "Download Complete."
        $lblStatus.Text = "Status: Download Successful."
        $lblStatus.ForeColor = $termGreen
        
        [System.Windows.Forms.MessageBox]::Show("Download completed successfully!`n`nSaved to: $destPath", "Download Complete", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    } catch {
        Write-Console "ERROR: Download failed. Details: $_" $colorAccentRed
        Write-Ticker "Error: Download Failed."
        $lblStatus.Text = "Status: Download Error."
        $lblStatus.ForeColor = $colorAccentRed
        
        [System.Windows.Forms.MessageBox]::Show("Failed to download the file.`n`nError: $_", "Download Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    }
    
    $btnDownloadMaster.Enabled = $true
    Show-Badge $global:btnTab2 "!"
    Show-Badge $global:btnInnerTab2 "!"
})

$btnCheckUpdate.Add_Click({
    $btnCheckUpdate.Enabled = $false
    Write-Console "ACTION: Checking for updates..." $termCyan
    Write-Ticker "Checking latest version online..."

    # Define your current version here. (Update this in the code whenever you release a new version)
    $currentVersionStr = "6.0.1" 
    
    # Direct Download Links for Google Drive
    $versionFileUrl = "https://drive.google.com/uc?export=download&id=1OFO1562an1B_XhOIITMn3z-t_AL8Kk75" # Director.txt
    $zipDownloadUrl = "https://drive.google.com/uc?export=download&id=1VXTM-ufOPBfFbyHpY1HH1G3zoLXf-k0f" # The Dashboard ZIP

    try {
        # 1. Check Version Status
        $latestVersionStr = Invoke-RestMethod -Uri $versionFileUrl -UseBasicParsing -TimeoutSec 10
        $latestVersionStr = $latestVersionStr.Trim()
        
        $currentVer = [version]$currentVersionStr
        $latestVer = [version]$latestVersionStr
        
        if ($latestVer -gt $currentVer) {
            Write-Console "UPDATE AVAILABLE: Version $latestVersionStr is out!" $termGreen
            Write-Ticker "Update Available: v$latestVersionStr. Waiting for user..."
            
            $confirmMsg = "Version $latestVersionStr is available!`n`nWould you like to download and install it now? This will close your current session."
            $confirmResult = [System.Windows.Forms.MessageBox]::Show($confirmMsg, "Update Available", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
            
            if ($confirmResult -eq [System.Windows.Forms.DialogResult]::Yes) {
                
                $lblStatus.Text = "Status: Downloading Update... Please wait."
                $lblStatus.ForeColor = $termCyan
                Write-Ticker "Downloading payload..."
                $form.Refresh()

                # 2. Setup Temp Directories
                $tempZipPath = Join-Path -Path $env:TEMP -ChildPath "PhoenixUpdate_$latestVersionStr.zip"
                $tempExtractPath = Join-Path -Path $env:TEMP -ChildPath "PhoenixUpdateExtracted"
                $targetScript = "DB Script V ${latestVersionStr}.ps1"
                
                if (Test-Path $tempExtractPath) { Remove-Item -Path $tempExtractPath -Recurse -Force }
                
                # 3. Download the ZIP Payload
                Write-Console "ACTION: Downloading payload from Google Drive..." $termWhite
                Invoke-WebRequest -Uri $zipDownloadUrl -OutFile $tempZipPath -UseBasicParsing

                # --- ERROR CATCH: Check if Google Drive blocked the download ---
                $zipSize = (Get-Item $tempZipPath).Length
                if ($zipSize -lt 2000) {
                    throw "Google Drive blocked the download (File too small: $zipSize bytes). Ensure the file is set to 'Anyone with the link'."
                }

                # 4. Extract the ZIP Payload
                Write-Console "SUCCESS: Payload downloaded ($zipSize bytes). Extracting..." $termGreen
                Expand-Archive -Path $tempZipPath -DestinationPath $tempExtractPath -Force

                # --- ERROR CATCH: Check if extraction contained the expected file ---
                $expectedFilePath = Join-Path -Path $tempExtractPath -ChildPath $targetScript
                if (-not (Test-Path $expectedFilePath)) {
                    throw "Extraction finished, but '$targetScript' was NOT found inside the zip file! Ensure you zipped the FILE directly, not the FOLDER."
                }

                Write-Console "SUCCESS: Verified '$targetScript' is ready. Staging background updater..." $termGreen

                # 5. Create the Background Updater Batch Script
                $updaterBatPath = Join-Path -Path $env:TEMP -ChildPath "PhoenixUpdater.bat"
                
                $batContent = @"
@echo off
title Phoenix Auto-Updater
echo Updating Installation Dashboard to v$latestVersionStr... 
echo Please wait 3 seconds for the dashboard to close completely...
timeout /t 3 /nobreak >nul

echo.
echo Copying new files...
xcopy "$tempExtractPath\*" "$workingDir\" /s /e /y

echo.
:: Using 'cd /d' fixes Windows pathing bugs if your folder has spaces
cd /d "$workingDir"

:: Verify the file actually made it to the directory before launching
if exist "$targetScript" (
    echo SUCCESS: File found! Launching $targetScript...
    start powershell.exe -ExecutionPolicy Bypass -File "$targetScript"
    
    :: Clean up temp extraction folder and zip
    rmdir /s /q "$tempExtractPath"
    del "$tempZipPath"
    
    :: Delete this temporary updater script
    del "%~f0"
) else (
    color 0C
    echo ===================================================
    echo UPDATE ERROR: COULD NOT LAUNCH THE NEW DASHBOARD!
    echo ===================================================
    echo The updater looked for: "$workingDir\$targetScript"
    echo But the file was not found. 
    echo.
    echo The copy process may have been blocked by Windows.
    echo.
    pause
)
"@
                Set-Content -Path $updaterBatPath -Value $batContent
                
                Write-LogToFile "SUCCESS: Update staged. Launching background updater and exiting."
                
                # 6. Launch the Auto-Updater and Close the Current Dashboard
                Start-Process -FilePath $updaterBatPath
                $form.Close()
            } else {
                Write-Console "INFO: Update cancelled by user." $termWhite
                Write-Ticker "System Update Aborted."
            }
        } else {
            Write-Console "INFO: Dashboard is up to date (v$currentVersionStr)." $termWhite
            Write-Ticker "System is up to date."
            [System.Windows.Forms.MessageBox]::Show("You are running the latest version ($currentVersionStr).", "Up to Date", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        }
    } catch {
        # --- ERROR CATCH: Main script failure pop-up ---
        Write-Console "ERROR: Update process failed. Details: $_" $colorAccentRed
        Write-Ticker "Error: Update process failed."
        [System.Windows.Forms.MessageBox]::Show("The update process encountered an error:`n`n$_", "Update Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    }
    
    $btnCheckUpdate.Enabled = $true
})

$btnCheckSftp.Add_Click({
    $btnCheckSftp.Enabled = $false
    Write-Console "--- Starting System Diagnostics (Background) ---" $termWhite
    Write-Ticker "Running Background SFTP Network Diagnostics..."
    $lblStatus.Text = "Status: Running Diagnostics. Please wait (up to 1 min)..."
    $lblStatus.ForeColor = $termCyan
    $form.Refresh()

    $jobScript = {
        $ipResult = "Failed"
        try {
            $ipResult = (Invoke-RestMethod -Uri "https://api.ipify.org" -UseBasicParsing -TimeoutSec 5)
        } catch { }

        $sftpResult = $false
        try {
            $test = Test-NetConnection -ComputerName "sftp.prophoenix.com" -Port 25544 -WarningAction SilentlyContinue
            $sftpResult = $test.TcpTestSucceeded
        } catch { }

        return @{ IP = $ipResult; SFTP = $sftpResult }
    }

    $global:sftpJob = Start-Job -ScriptBlock $jobScript
    $global:sftpJobStartTime = Get-Date

    $global:sftpTimer = New-Object System.Windows.Forms.Timer
    $global:sftpTimer.Interval = 1000 
    
    $global:sftpTimer.Add_Tick({
        $elapsed = (Get-Date) - $global:sftpJobStartTime
        
        if ($global:sftpJob.State -eq 'Completed') {
            $global:sftpTimer.Stop()
            $result = Receive-Job -Job $global:sftpJob
            Remove-Job -Job $global:sftpJob

            if ($result.IP -ne "Failed") { Write-Console "VERIFIED: External Public IP = $($result.IP)" $termGreen }
            else { Write-Console "FAILED: Could not retrieve Public IP." $colorAccentRed }

            if ($result.SFTP) { Write-Console "VERIFIED: SFTP Port 25544 is OPEN and reachable." $termGreen }
            else { Write-Console "FAILED: Could not connect to sftp.prophoenix.com on Port 25544." $colorAccentRed }

            Write-Console "--- Diagnostics Complete ---" $termWhite
            $lblStatus.Text = "Status: Ready."
            $lblStatus.ForeColor = $colorTextMuted
            Write-Ticker "SFTP Diagnostics Completed."
            
            $btnCheckSftp.Enabled = $true
            Show-Badge $global:btnTab2 "1"
            Show-Badge $global:btnInnerTab2 "1"
        }
        elseif ($elapsed.TotalSeconds -ge 60) {
            $global:sftpTimer.Stop()
            Stop-Job -Job $global:sftpJob
            Remove-Job -Job $global:sftpJob
            
            Write-Console "FAILED: Diagnostics timed out after 60 seconds." $colorAccentRed
            Write-Console "--- Diagnostics Aborted ---" $termWhite
            Write-Ticker "Error: SFTP Diagnostics Timed Out."
            
            $lblStatus.Text = "Status: Ready (SFTP Check Timed Out)."
            $lblStatus.ForeColor = $colorAccentRed
            
            $btnCheckSftp.Enabled = $true
            Show-Badge $global:btnTab2 "1"
            Show-Badge $global:btnInnerTab2 "1"
        }
    })
    
    $global:sftpTimer.Start()
})

$btnLoadZip.Add_Click({
    $extractPath = Join-Path -Path $workingDir -ChildPath "Dashboard_ExtractedScripts"
    
    $scriptsExist = $false
    if (Test-Path $extractPath) {
        $existingScripts = Get-ChildItem -Path $extractPath -Include *.ps1, *.bat -Recurse
        if ($existingScripts.Count -gt 0) { $scriptsExist = $true }
    }

    if ($scriptsExist) {
        if ($sender -ne $null) {
            [System.Windows.Forms.MessageBox]::Show("The New Server Installation master file is already available and loaded.", "Scripts Available", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        }
        
        $lblStatus.Text = "Status: Loaded existing extracted scripts."
        $lblStatus.ForeColor = $termGreen
        Write-Console "INFO: Using existing extracted scripts. Skipped ZIP extraction." $termCyan
        Load-ScriptButtons $extractPath
        return
    }

    $availableZips = Get-ChildItem -Path $workingDir -Filter "*.zip" | Sort-Object LastWriteTime -Descending

    if ($availableZips.Count -eq 0) {
        $lblStatus.Text = "Status: Error - No valid ZIP file found."
        $lblStatus.ForeColor = $colorAccentRed
        Write-Console "ERROR: No ZIP files found in $workingDir." $colorAccentRed
        Write-Ticker "Extraction Failed: Source Archive Missing."
        $form.Refresh()
        return
    }

    $targetZip = $availableZips[0]
    $zipPath = $targetZip.FullName

    if ($availableZips.Count -gt 1) {
        Write-Console "WARNING: Multiple ZIP files detected. Using the newest one: $($targetZip.Name)" [System.Drawing.Color]::Yellow
    }

    $lblStatus.Text = "Status: Extracting $($targetZip.Name)..."
    $lblStatus.ForeColor = $colorTextWhite
    Write-Console "ACTION: Extracting '$($targetZip.Name)'..." $termWhite
    Write-Ticker "Extracting Scripts from Archive..."
    $form.Refresh()
    
    try {
        if (Test-Path $extractPath) { Remove-Item -Path $extractPath -Recurse -Force }
        New-Item -ItemType Directory -Path $extractPath -Force | Out-Null
        Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force
        
        Write-Console "SUCCESS: Extraction complete." $termGreen
        Load-ScriptButtons $extractPath
    } catch {
        $lblStatus.Text = "Status: Error extracting ZIP - $_"
        $lblStatus.ForeColor = $colorAccentRed
        Write-Console "ERROR: Failed to extract ZIP. Details: $_" $colorAccentRed
        Write-Ticker "Error: Extraction Failed."
    }
})

$form.Add_Shown({
    $btnLoadZip.PerformClick()
})

# ==========================================
# COPYRIGHT FOOTER & CUSTOM REPAINTS
# ==========================================
$lblCopyright = New-Object System.Windows.Forms.Label
$lblCopyright.Text = "© 2026, ProPhoenix Corporation, All Rights Reserved"
$lblCopyright.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
$lblCopyright.ForeColor = [System.Drawing.Color]::FromArgb(255, 120, 135, 150) 
$lblCopyright.AutoSize = $false
$lblCopyright.Size = New-Object System.Drawing.Size(980, 20)
$lblCopyright.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblCopyright.Location = New-Object System.Drawing.Point(0, 875)
$lblCopyright.Anchor = "Bottom, Left, Right"
$lblCopyright.BackColor = [System.Drawing.Color]::Transparent
$contentPanel.Controls.Add($lblCopyright)

$sidebar.Add_Resize({ $sidebar.Refresh() })

$preloader.Close()
$preloader.Dispose()

$form.ShowDialog() | Out-Null